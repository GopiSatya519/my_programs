#include<stdio.h>
#include<stdlib.h>
struct node
{
     int data;
     struct node *left;
     struct node *right;

};
struct node *root=NULL;
void append()
{
   struct node *temp;
   temp=(struct node*)malloc(sizeof(struct node));
   printf("enter the data to node:");
   scanf("%d",&temp->data);
   temp->right=NULL;
   if(root==NULL)
   {
      root=temp;
   }
   else
   {
   struct node *p=root;
   while(p->right!=NULL)
   {
    p=p->right;
   }
   p->right=temp;
   temp->left=p;
   }
}
void addatbegin()
{
   struct node *temp;
   temp=(struct node*)malloc(sizeof(struct node));
   printf("enter the data to node:");
   scanf("%d",&temp->data);
   temp->right=NULL;
   if(root==NULL)
   {
      root=temp;
   }
   else
   {
      temp->right=root;
      root->left=temp;
      root=temp;
   }
   }
int length()
{
   struct node *p=root;
   int count=0;
   while(p!=NULL)
   {
      count++;
      p=p->right;
   }
   return count;
}
void addatafter()
{
  int loc,len,i=1;
  len=length();
  printf("\n Enter position:");
  scanf("%d",&loc);
  struct node *temp;

   if(root==NULL)
   {
      root=temp;
   }
   else
   {
   temp=(struct node*)malloc(sizeof(struct node));
   printf("enter the data to node:");
   scanf("%d",&temp->data);
   temp->right=NULL;
   struct node *p=root;
   while(i<loc)
   {
   p=p->right;
   i++;
   }
   temp->right=p->right;
   p->right->left=temp;
   temp->left=p;
   p->right=temp;
   }
}
void display()
{
    struct node *p=root;
    while(p!=NULL)
    {

        printf("%d  ",p->data);
        p=p->right;
    }
}
void delete()
{
    struct node *temp=root;
    int loc,len;
    len=length();
    printf("\n enter the location:");
    scanf("%d",&loc);
    if(loc>len)
    {
    printf("\n invalid position");

    }
    else if(loc==1)
    {
       temp=root;
       root=temp->right;
       root->left=NULL;
       free(temp);
    }
    else if(loc==len)
    {
       temp=root;
       while(temp->right!=NULL)
       {
          temp=temp->right;
       }
       temp->left->right=NULL;
       temp->left=NULL;
       free(temp);
    }
    else
    {
       struct node *p=root,*q;
       int i=1;
       while(i<loc-1)
       {
          p=p->right;
          i++;
       }
       q=p->right;
       p->right=q->right;
       q->right->left=p;
       free(q);
    }

}
int main()
{
   int ch,len;
   while(1)
   {
    printf("\n1.APPEND");
    printf("\n2.ADD AT BEGIN");
    printf("\n3.ADD AT SPECIFIC POSITION");
    printf("\n4.LENGHT");
    printf("\n5.DISPLAY");
    printf("\n6.DELETE");
    printf("\n7.EXIT");
    printf("\nemter u r choice:");
    scanf("%d",&ch);
    switch(ch)
    {
       case 1:append();
               break;
       case 2:addatbegin();
               break;
       case 3:addatafter();
              break;
       case 4:len=length();
              printf("\nlenght of double linked  list is %d",len);
               break;
       case 5:display();
              break;
       case 6:delete();
              break;
       case 7:exit(1);
              break;
       default:printf("\n invalid choice");
   }
   }
}

