#include<stdio.h>
int main()
{
   int a[10],mid,start,end,i,n,key;
   printf("enter number of elements u want to entered:");
   scanf("%d",&n);
   printf("enter the elements in sorted order: ");
   for(i=0;i<n;i++)
   {
       scanf("\n%d",&a[i]);
   }
   printf("\n enter the ele which u want to search: ");
   scanf("%d",&key);
   start=0;
   end=n-1;
   while(start<=end)
   {
       mid=(start+end)/2;
       if(key==a[mid])
       {
       printf("\nelement is found");
       break;
       }
       else if(a[mid]<key)
       {
          start=mid+o1;
       }
       else if(a[mid]>key)
       {
          end=mid-1;
       }
   }
   if(start>end)
   {
     printf("\nelement is not found:");
   }
}
