#include<stdio.h>
int binarysearch(int lb,int up)
{
    int mid=floor((lb+up)/2);
    return mid;
}
int main()
{
    int a[20],i,first=0,last,n,mid,key;
    printf("\nenter how many elements u want to enter:");
    scanf("%d",&n);
    printf("\nenter elements to the array");
    for(i=0;i<n;i++)
    {
       scanf("%d",&a[i]);
    }
    printf("\nenter element which u want to search:");
    scanf("%d",&key);
    last=n;
    mid=binarysearch(first,last);
    while(first<last)
    {

        if(a[mid]==key)
        {
            printf("\n element is found at %d position",mid+1);
        }
        else if(a[mid]<key)
        {
            mid=binarysearch(first=mid+1,last);
        }
        else if(a[mid]>key)
        {
            mid=binarysearch(first,last=mid-1);
        }
        else
        {
            printf("\nelement is not found");
        }
        i++;

    }
}
