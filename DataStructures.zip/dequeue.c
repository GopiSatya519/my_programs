#include<stdio.h>
#define max 5
int queue[max];
int rear=-1,front=-1;
void insert(int ele)
{
   if(front==0&&rear==max-1)
   printf("queue is full");
   else if(front==-1&&rear==-1)
   {
      front=rear=0;
      queue[rear]=ele;
   }
   else if(front==0)
   {
      rear++;
      queue[rear]=ele;
   }
   else if(rear==max-1)
   {
      front--;
      queue[front]=ele;
   }
   else
   {
      int  ch;
      printf("\n 1.left side insertion");
      printf("\n2.right side insertion");
      scanf("%d",&ch);
      if(ch==1)
      {
        front--;
        queue[front]=ele;
      }
      else
      {
        rear++;
        queue[rear]=ele;
      }
   }
}
   void delete()
   {
       if(front==-1&&rear==-1)
       {
         printf("\ndouble ended queue is empty ");
       }
       else if(front==rear)
       {
          printf("\nelement deleted is: %d",queue[rear]);
          front=rear=-1;
       }
       else
       {
          int ch;
          printf("\n 1.left side deletion");
          printf("\n 2.right side deletion");
          scanf("%d",&ch);
          if(ch==1)
          {
             printf("\nelement deleted is %d",queue[front]);
             front++;
          }
          else
          {
             printf("\n elements deleted is %d",queue[rear]);
             rear--;
          }
       }
       }
void display()
{
  int i;
  if(front==-1&&rear==-1)
  {
     printf("\ndouble ended queue is empty");
  }
  else
  {
     for(i=front;i<=rear;i++)
     printf("%d \t",queue[i]);
  }
}
int main()
{
   int ch,ele;
   while(1)
   {
       printf("\n1.insert\n2.delete\n3.display\n4.exit\n");
       printf("enter u r choice:");
       scanf("%d",&ch);
       switch(ch)
       {
           case 1: printf("enter a data:");
                   scanf("%d",&ele);
                   insert(ele);
                   break;
           case 2: delete();
                  break;
           case 3:display();
                  break;
           case 4:exit(0);
                  break;

       }
    }
}
