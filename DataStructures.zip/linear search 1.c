#include<stdio.h>
int main()
{
   int a[20],i,n,count=0,key;
   printf("enter number of elements:");
   scanf("%d",&n);
   printf("\nenter the elements:");
   for(i=0;i<n;i++)
   {
       scanf("%d",&a[i]);
   }
   printf("\nenter a element which u want search:\n");
   scanf("%d",&key);
   for(i=0;i<n;i++)
   {
      if(a[i]==key)
      {
         printf("\nthe element is found at %d position",i+1);
         count++;
      }
   }
   if(count==0)
   {
      printf("\nelement is not found");
   }
}
