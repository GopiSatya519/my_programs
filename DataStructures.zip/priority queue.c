#include<stdio.h>
#include<stdlib.h>
struct node
{
    int data;
    int priority;
    struct node *link;
    };
struct node *front=NULL;
void insert()
{
    struct node *temp;
    temp=(struct node*)malloc(sizeof(struct node));
    printf("enter data to the node:");
    scanf("%d",&temp->data);
    printf("enter the priority:");
    scanf("%d",&temp->priority);
    if(front==NULL)
      front=temp;
    else if((temp->priority)<(front->priority))
    {
       temp->link=front;
       front=temp;
    }
    else
    {
        struct node *q=front;
        while(q->link!=NULL &&(q->link->priority)<=temp->priority)
        {
           q=q->link;
        }
        temp->link=q->link;
        q->link=temp;
    }

}
void delete()
{
   struct node *p=front;
   front=p->link;
   p->link=NULL;
   free(p);
}
void display()
{
   struct node *p=front;
   while(p!=NULL)
   {
      printf("%d ",p->data);
      p=p->link;
   }
}
int main()
{
   int ch;
   while(1)
   {
   printf("1.insert\n2.delete\n3.display\n4.exit\n");
   printf("enter u r choice:");
   scanf("%d",&ch);
   switch(ch)
   {
        case 1:insert();
               break;
        case 2:delete();
               break;
        case 3:display();
               break;
        case 4:exit(0);
               break;
   }
   }
   }
