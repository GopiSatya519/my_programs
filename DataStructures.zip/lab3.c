#include<stdio.h>
#include<stdlib.h>
struct node
{
   int data;
   struct node *right;
   struct node *left;
};
struct node *root=NULL;
int main()
{
    int ch,num,n;
    do
    {

        printf("\nemter choice:");
        scanf("%d",&ch);
        if(ch!=-1)
        {
        struct node *temp;
        temp=(struct node*)malloc(sizeof(struct node));
        temp->right=NULL;
        temp->left=NULL;
        printf("\nenter data:");
        scanf("%d",&temp->data);
        if(root==NULL)
        {
           root=temp;
        }
        else
        {
            struct node *p=root;
            while(p->right!=NULL)
            {
               p=p->right;
            }

            p->right=temp;
             temp->left=p;
        }
        }

   }while(ch!=-1);
   struct node *q=root;
   while(q!=NULL)
   {
      printf("%d  ",q->data);
      q=q->right;
   }
   printf("\neneter number:");
   scanf("%d",&num);
   struct node *r=root;
   while(r!=NULL)
   {
       if(r->data==num)
       {
           printf("\nelement is found");
           n=r->right->data;
           r->right->data=r->left->data;
           r->left->data=n;
           struct node *s=r;
           while(s->left!=NULL)
           {
               s=s->left;
               printf("%d ",s->data);

           }
           struct node *t=r;
           while(t!=NULL)
           {
              printf("%d  ",t->data);
               t=t->right;
           }
           break;

       }
       r=r->right;

   }

}
