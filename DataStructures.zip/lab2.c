#include<stdio.h>
#include<stdlib.h>
#define CAPACITY 10
int stack[CAPACITY];
int top=-1;
void push(int ele)
{
   if(top==CAPACITY-1)
   {
     printf("fdgfhgjk");
   }
   else
   {
      top++;
      stack[top]=ele;
   }
}
void pop(int n)
{
   if(top==-1)
   {
     printf("\nempty");
   }
   else
   {
      int i;
     /* for( i=0;i>3;i++)
      {

         printf("\n deleted ele:%d\n",stack[top]);
         top--;
      }*/
      for(i=0;i<n;i++)
       printf("\n deleted ele:%d\n",stack[top--]);
   }
}
void traverse()
{
    if(top==-1)
    {

    printf("\nstack is empty");
    }
    else
    {
      /* int i;
       printf("\nstack elements are:\n");
       for(i=top;i<=0;i--)
       {
          printf("%d\n",stack[i]);
       }*/
        int i;
       printf("\nstack elements are:\n");
       for(i=top;i>=0;i--)
       {
          printf("stack[%d]=%d\n",i,stack[i]);
       }
    }
}
int main()
{
int ch,ele,del;
   while(1)
   {
      printf("1.push\n");
      printf("2.pop\n");
      printf("3.display");
      printf("\n4.exit");
      printf("\nenter choice:");
      scanf("%d",&ch);
      switch(ch)
      {
      case 1:printf("enter a number:");
             scanf("%d",&ele);
             push(ele);
             break;
      case 2:pop(3);
             break;
      case 3:traverse();
             break;
      case 4:exit(0);
             break;
      }
   }
   return 0;
}
