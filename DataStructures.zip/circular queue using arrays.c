#include<stdio.h>
#define max 5
int queue[max];
int front=-1;
int rear=-1;
void insert(int ele)
{
   if(front==-1&&rear==-1)
   {
    front=rear=0;
    queue[rear]=ele;
    }
    else if((front==0&&rear==max-1)||front==rear+1)
    {
      printf("\n queue is full\n");
    }
    else if(front!=0&&rear==max-1)
    {
       rear=0;
       queue[rear]=ele;
    }
    else
    {
      rear++;
      queue[rear]=ele;
    }
}
void delete()
{
    if(front==-1&&rear==-1)
    {
        printf("queue is empty\n");
    }
    else if(front==max-1)
    {
        front=0;
    }
    else if(front==rear)
    {
        front=rear=-1;
    }
    else
    front++;
}
void display()
{

   if(front==-1&&rear==-1)
   printf("\n queue is empty:");
   else if(front<rear)
    {
          int i;
         for(i=front;i<=rear;i++)
         printf("%d\t",queue[i]);
    }
    else
      {
          int i;
          for(i=front;i<max;i++)
          printf("%d\t",queue[i]);
          for(i=0;i<=rear;i++)
          printf("%d\t",queue[i]);
      }
   }

void peek()
{
    printf("\n the top of the element:%d",queue[front]);
}
int main()
{
   int ch,ele;
    while(1)
    {
       printf("\n1.enqueue\n2.dequeue\n3.display\n4.peek\n5.exit\n");
       printf("\n enter u r choice:");
       scanf("%d",&ch);
       switch(ch)
       {
          case 1:printf("\nenter the element:");
                 scanf("%d",&ele);
                 insert(ele);
                 break;
          case 2:delete();
                 break;
          case 3:display();
                 break;
          case 4:peek();
                 break;
          case 5:exit(0);
                 break;
       }
}
}
