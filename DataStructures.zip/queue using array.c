#include<stdio.h>
#define max 5
int queue[max];
int front=-1;
int rear=-1;
void enqueue(int ele)
{
   if(rear==max-1)
   {
      printf("\nqueue is full\n");
   }
   else if(front==-1&&rear==-1)
   {
   front++;
   rear++;
   queue[rear]=ele;
   }
   else
   {
     rear++;
     queue[rear]=ele;
   }
}
void dequeue()
{
    if(rear==-1&&front==-1)
    {
      printf("\n queue is empty\n");
    }
    else if(rear==0&&front==0)
    {
       rear--;
       front--;
    }
    else
    {
       front++;
    }
}
void display()
{
if(front==-1&&rear==-1)
{
   printf("\n no elements in queue\n");
}
else
{
    int i;
    for(i=front;i<=rear;i++)
    printf("%d\t",queue[i]);
}
}
void peek()
{
    if(front==-1&&rear==-1)
    {
        printf("\n no elements in queue\n");
    }
    else
    {
       printf("the top elements %d",queue[front]);
    }
}
int main()
{
    int ch,ele;
    while(1)
    {
       printf("\n1.enqueue\n2.dequeue\n3.display\n4.peek\n");
       printf("\n enter u r choice:");
       scanf("%d",&ch);
       switch(ch)
       {
          case 1:printf("\n enter an element: ");
                 scanf("%d",&ele);
                 enqueue(ele);
                 break;
          case 2:dequeue();
                 break;
          case 3:display();
                 break;
          case 4:peek();
                 break;
          case 5:exit(0);
                 break;
       }
    }

}
