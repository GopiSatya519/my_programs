#include<stdio.h>
int quicksort(int a[100],int lb,int ub)
{
    int loc;
    if(lb<ub)
    {
    loc=partition(a,lb,ub);
    quicksort(a,lb,loc-1);
    quicksort(a,loc+1,ub);
    }
}
int partition(int a[100],int lb,int ub)
{
   int pivot,start,end;
   pivot=a[lb];
   start=lb;
   end=ub;
   while(start<end)
   {
      while(a[start]<=pivot&&start<=ub)
      {
        start++;
      }
      while(a[end]>pivot)
      {
         end--;
      }
      if(start<end)
      {
         int temp=a[start];
         a[start]=a[end];
         a[end]=temp;
      }
   }
   if(start>end)
   {
       int temp=a[lb];
       a[lb]=a[end];
       a[end]=temp;
       }
       return end;
}
main()
{
    int a[100],i,n;
    printf("enter the number of elements of the array:\n");
    scanf("%d",&n);
    printf("enter the elements of the array:\n");
    for(i=0;i<n;i++)
    {scanf("%d",&a[i]);}
    quicksort(a,0,n-1);
    printf("\nsorted array:");
    for(i=0;i<n;i++)
    {
    printf("%d\t",a[i]);
    }
}
