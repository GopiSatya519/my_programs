#include<stdio.h>
int a[100],b[100],k;
void mergesort(int *,int,int,int);
void merge(int *a,int lb,int ub)
{
    int mid;
    if(lb<ub)
    {
       mid=(lb+ub)/2;
       merge(a,lb,mid);
       merge(a,mid+1,ub);
       mergesort(a,lb,mid,ub);
    }
}
void mergesort(int *a,int lb,int mid,int ub)
{
    int i=lb,j=mid+1,b[100],k=lb;
    while(i<=mid&&j<=ub)
    {
       if(a[i]<a[j])
       {
          b[k]=a[i];
          k++;
          i++;
       }
       else
       {
          b[k]=a[j];
          k++;
          j++;
       }
    }
       if(i>mid)
       {
          while(j<=ub)
          {
             b[k]=a[j];
             k++;
             j++;
          }
       }
       else
       {
          while(i<=mid)
          {
             b[k]=a[i];
             k++;
             i++;
          }
       }
       for(i=lb;i<k;i++)
       {
           a[i]=b[i];
       }
}
main()
{
   int i,n,lb,ub;
   printf("enter the number of elements of a array:");
   scanf("%d",&n);
   printf("enter the elements:\n");
   for(i=0;i<n;i++)
   {
      scanf("%d",&a[i]);
   }
   lb=0;
   ub=n-1;
   merge(a,lb,ub);
   printf("\n elements in the sorted array:\n");
   for(i=0;i<n;i++)
   {
      printf("%d\t",a[i]);
   }

}
