#include<stdio.h>
#include<stdlib.h>
struct node
{
  int data;
  struct node *link;
};
struct node *top=NULL;
void push()
{
    struct node *temp;
    temp=(struct node*)malloc(sizeof(struct node));
    printf("enter the node data:");
    scanf("%d",&temp->data);
    temp->link=top;
    top=temp;
}
void pop()
{
   struct node *temp;
   temp=top;
   if(temp==NULL)
   {
     printf("no nodes to delete\n");
   }
   else
   {
      printf("element delete is :%d\n",temp->data);
      top=top->link;
      temp->link=NULL;
      free(temp);
   }
}
int length()
{
    int count=0;
   struct node *temp=top;
   while(temp!=NULL)
   {

       count++;
       temp=temp->link;
   }
   return count;
}
void traverse()
{

    struct node *temp;
    if(top==NULL)
    {
        printf("\n stack is empty");
    }
    else{

        temp=top;
        while(temp!=NULL)
        {

            printf("%d ",temp->data);
            temp=temp->link;
        }
    }
}
void peek()
{

    struct node *temp=top;
    if(top==NULL)
    {
        printf("\n no nodes to display");
    }
    else
        {
        printf("\n element at the top=%d\n",temp->data);
    }
}
int main()
{
    int ch,len;
    while(1)
    {

        printf("\n1.push\n");
        printf("2.pop\n");
        printf("3.peek\n");
        printf("4.traverse\n");
        printf("5.length\n");
        printf("6.exit\n");
        printf("enter u r choice");
        scanf("%d",&ch);
        switch(ch)
        {

            case 1:push();
                   break;
            case 2:pop();
                   break;
            case 3:peek();
                   break;
            case 4:traverse();
                   break;
            case 5:len=length();
                   printf("\n length of the stack :%d \n",len);
                   break;
            case 6:exit(0);
                   break;
    }

}
}
