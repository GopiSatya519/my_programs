#include<stdio.h>
#include<stdlib.h>
#define capacity 5
int stack[capacity];
int top=-1;
int isfull()
{
   if(top==capacity-1)
   {
      return 1;
   }
   else
   {
      return 0;
   }
}
int isempty()
{
    if(top==-1)
    return 1;
    else
    return 0;
}
void push(int ele)
{
     if(isfull())
     {
        printf("\n stack is full\n");
     }
     else
     {
        top++;
        stack[top]=ele;
     }
}
int pop()
{
   if(isempty())
   {
      return 0;
   }
   else
   {
      return stack[top--];
   }
}
void peek()
{
    if(isempty())
    printf("\nstack is empty");
    else
    printf("\nelement at the top:%d\n",stack[top]);
}
void traverse()
{
    if(isempty())
    printf("\nstack is empty");
    else
    {
       int i;
       printf("\nstack elements are:\n");
       for(i=0;i<=top;i++)
       {
          printf("stack[%d]=%d\n",i,stack[i]);
       }
    }
}
int main()
{
   int ch,ele,del;
   while(1)
   {
      printf("1.push\n");
      printf("2.pop\n");
      printf("3.peek\n");
      printf("4.traverse\n");
      printf("5.quit\n");
      printf("enter the choice:");
      scanf("%d",&ch);
      switch(ch)
      {
      case 1:printf("enter a number:");
             scanf("%d",&ele);
             push(ele);
             break;
      case 2:del=pop();
             if(del==0)
             printf("stack is full\n");
             else
             printf("stack element deleted is:%d\n",del);
             break;
      case 3:peek();
             break;
      case 4:traverse();
             break;
      case 5:exit(0);
             break;
      }
   }
   return 0;
}
