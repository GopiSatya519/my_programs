#include<stdio.h>
struct node
{
int data;
struct node *left;
struct node *right;
};
struct node *root=NULL;
int main()
{
   void append();
   void display();
   append();
   append();
   display();
}
void append()
{
struct node *temp;
temp=(struct node*)malloc(sizeof(struct node));
printf("\nenter data to the node:");
scanf("%d",&temp->data);
if(root==NULL)
{
    root=temp;
}
else
{
     struct node *s=root;
     while(s->right!=NULL)
     {
       s=s->right;
     }
     s->right=temp;
     temp->right=s;
}
}
void display()
{
   struct node *p=root;
   while(p!=NULL)
   {
      printf(" %d ",p->data);
      p=p->right;
   }


}
