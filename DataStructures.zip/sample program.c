#include<stdio.h>
#include<stdlib.h>
struct node
{
    int data;
    struct node *link;
};
struct node *root=NULL;
main()
{
   void append();
   void adding();
   //void posiadd();
   int ch;
   printf("1.append\n2.adding\n3.adding at specific position\n4.exit\n");
   while(1)
   {
   printf("\nenter u r choice");
   scanf("%d",&ch);
   switch(ch)
   {
       case 1:append();
              break;
       case 2:adding();
              break;
       case 3:exit(1);
              break;
       default:printf("\ninvalid position");

   }
   }
   }
   void append()
   {
       struct node *temp;
       temp=(struct node*)malloc(sizeof(struct node));
       temp->link=NULL;
       if(root==NULL)
       {
           root=temp;
       }
       else
       {
           struct node *p;
           p=root;
           while(p->link!=NULL)
           {
               p=p->link;
            }
           p->link=temp;
        }
        }


