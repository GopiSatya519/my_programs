#include<stdio.h>
#include<stdlib.h>
struct node
{
    int data;
    struct node* link;
};
struct node *root=NULL;
void apend()
{
    struct node *temp;
    temp=(struct node*)malloc(sizeof(struct node));
    printf("\nenter a node data:");
    scanf("%d",&temp->data);
    temp->link=NULL;
    if(root==NULL)
    {
        root=temp;
    }
    else
    {
        struct node *s;
        s=root;
        while(s->link!=NULL)
        {
           s=s->link;
        }
        s->link=temp;
    }
}
void addatbegin()
{
    struct node *temp;
    temp=(struct node*)malloc(sizeof(struct node));
    printf("\nenter a node data:");
    scanf("%d",&temp->data);
    temp->link=NULL;
    if(root==NULL)
    {
        root=temp;
    }
    else
    {
        temp->link=root;
        root=temp;
    }}
int length()
{
   int count=1;
   struct node *p;
   p=root;
   while(p->link!=NULL)
   {
      count++;
      p=p->link;
   }
   return count;
}
void atafter()
{
    int len,pos,i=1;
    struct node *temp;
    temp=(struct node*)malloc(sizeof(struct node));
    printf("\nenter a node data:");
    scanf("%d",&temp->data);
    temp->link=NULL;
    len=length();
    printf("\nenter position value where to be inserted: ");
    scanf("%d",&pos);
    if(pos>len)
    {
       printf("\n invalid position:");

    }
    else
    {
         struct node *s;
         s=root;
         while(i<pos)
         {
            s=s->link;
            i++;
         }
         temp->link=s->link;
         s->link=temp;
    }
}
void display()
{
    struct node *t;
    t=root;
    if(t==NULL)
    {
        printf("\n no nodes to diplay");
    }
    else
        {
          while(t!=NULL)
           {
             printf("\n%d ",t->data);
             t=t->link;
           }
        }
}
void delete()
{
    int loc,len;
    struct node *p;
    p=root;
    len=length();
    printf("\nenter position value where to be deleted: ");
    scanf("%d",&loc);
    if(loc>len)
    {
    printf("\n invalid position");
    }
    else if(loc==1)
    {
       root=p->link;
       p->link=NULL;
       free(p);

    }
    else
    {
       int i=1;
       struct node *x;
        if(i<loc-1)
        {
           p=p->link;
           i++;
        }
        x=p->link;
        p->link=x->link;
        x->link=NULL;
        free(x);
}
    }
int main()
{
  int ch,len;
  while(1)
  {
    printf("\n1.APPEND");
    printf("\n2.ADD AT BEGIN");
    printf("\n3.ADD AT SPECIFIC POSITION");
    printf("\n4.LENGHT");
    printf("\n5.DISPLAY");
    printf("\n6.DELETE");
    printf("\n7.EXIT");
    printf("\nemter u r choice:");
    scanf("%d",&ch);
    switch(ch)
    {
       case 1:apend();
               break;
       case 2:addatbegin();
               break;
       case 3:atafter();
              break;
       case 4:len=length();
              printf("\nlenght of linked list is %d",len);
               break;
       case 5:display();
              break;
       case 6:delete();
              break;
       case 7:exit(1);
              break;
       default:printf("\n invalid choice");
   }
 }

}

