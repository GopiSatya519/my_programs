#include<stdio.h>
#include<stdlib.h>
struct node
{
     int data;
     struct node *link;
};
struct node *front=NULL;
struct node *rear=NULL;
void insert()
{
   struct node *temp;
   temp=(struct node*)malloc(sizeof(struct node));
   printf("\nenter the data to node:");
   scanf("%d",&temp->data);
   temp->link=NULL;
   if(front==NULL&&rear==NULL)
   {
      front=rear=temp;
   }
   else
   {
      rear->link=temp;
      rear=temp;
   }
}
void delete()
{
     struct node *temp=front;
     if(front==NULL&&rear==NULL)
     {
         printf("\n queue is empty");
     }
     else
     {
         front=temp->link;
         temp->link=NULL;
         free(temp);
     }
}
void display()
{
   if(front==NULL&&rear==NULL)
   {
      printf("\n queue is empty\n");
   }
   else
   {
      struct node *temp=front;
      while(temp!=NULL)
      {
          printf("%d\t",temp->data);
          temp=temp->link;
      }
   }
}
void peek()
{
    printf("\nthe top element is %d",front->data);
}
int main()
{
       int ch,ele;
    while(1)
    {
       printf("\n1.enqueue\n2.dequeue\n3.display\n4.peek\n5.exit\n");
       printf("\n enter u r choice:");
       scanf("%d",&ch);
       switch(ch)
       {
          case 1:insert();
                 break;
          case 2:delete();
                 break;
          case 3:display();
                 break;
          case 4:peek();
                 break;
          case 5:exit(0);
                 break;
       }
}}
