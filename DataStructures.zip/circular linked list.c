#include<stdio.h>
#include<stdlib.h>
struct node
{
    int data;
    struct node *link;
};
struct node *root=NULL;
void append()
{
 struct node *temp;
 temp=(struct node*)malloc(sizeof(struct node));
 temp->link=NULL;
 printf("\nenter node data:");
 scanf("%d",&temp->data);
 if(root==NULL)
 {
    root=temp;
    temp->link=root;
 }
 else
 {
    struct node *p;
    p=root;
    while(p->link!=root)
    {
       p=p->link;
    }
    temp->link=root;
    p->link=temp;
 }
}
void addatbegin()
{
  struct node *temp;
  temp=(struct node*)malloc(sizeof(struct node));
  temp->link=NULL;
  printf("\nenter data to node:");
  scanf("%d",&temp->data);
  if(root==NULL)
  {
     root=temp;
     temp->link=root;
  }
  else
  {
     struct node *s;
     s=root;
     while(s->link!=root)
     {
        s=s->link;
     }
     s->link=temp;
     temp->link=root;
     root=temp;
  }
}

int length()
{
  int count=1;
    struct node *r=root;
    while(r->link!=root)
    {
       count++;
       r=r->link;
    }
return count;
}
void display()
{
    if(root==NULL)
    {
       printf("\n there is no elements to display");
    }
    else
    {
    struct node *x=root;
    while(x->link!=root)
    {
       printf("%d ",x->data);
       x=x->link;
    }
    printf(" %d",x->data);
    }
}
void atafter()
{
  struct node *temp;
  temp=(struct node*)malloc(sizeof(struct node));
  temp->link=NULL;

  if(root==NULL)
  {
     root=temp;
     temp->link=root;
  }
  else
  {
      int len,pos;
      printf("\nenter the position where u want to append:");
      scanf("%d",&pos);
       printf("\nenter data to node:");
       scanf("%d",&temp->data);
       len=length();
       if(pos>len)
       {
         printf("\n invalid location");
       }
       else
       {
           struct node *a=root;
           int i=1;
           while(i<pos)
           {
           a=a->link;
           i++;
           }
           temp->link=a->link;
           a->link=temp;
       }
    }
}
void delete()
{
      int len,pos;
      printf("\nenter the position where u want to append:");
      scanf("%d",&pos);
      struct node *p=root;
      struct node *temp;
      temp=root;
      while(temp->link!=root)
      {
         temp=temp->link;
      }
      if(pos==1)
      {
        root=p->link;
        temp->link=root;
        p->link=NULL;
        free(p);
      }
      else
      {
      struct node *q,*x=root;
      int i=1;
      while(i<pos-1)
      {
         x=x->link;
         i++;
      }
      q=x->link;
      x->link=q->link;
      q->link=NULL;
      free(q);
      }
}
int main()
{
 int len,ch;
 while(1)
  {
    printf("\n1.APPEND");
    printf("\n2.ADD AT BEGIN");
    printf("\n3.ADD AT SPECIFIC POSITION");
    printf("\n4.LENGHT");
    printf("\n5.DISPLAY");
    printf("\n6.DELETE");
    printf("\n7.EXIT");
    printf("\nemter u r choice:");
    scanf("%d",&ch);
    switch(ch)
    {
       case 1:append();
               break;
       case 2:addatbegin();
               break;
       case 3:atafter();
              break;
       case 4:len=length();
              printf("\nlenght of circular list is %d",len);
               break;
       case 5:display();
              break;
       case 6:delete();
              break;
       case 7:exit(1);
              break;
       default:printf("\n invalid choice");
   }
 }

}

