#include<stdio.h>
int main()
{
    int a[25];
    int i,j,temp=0,n,min=0;
    printf("\nenter no of elements u want to entered ?:");
    scanf("%d",&n);
    printf("\nenter elements:");
    for(i=0;i<n;i++)
        scanf("%d",&a[i]);
    for(i=0;i<n-1;i++)
    {
       min=i;
       for(j=i+1;j<n;j++)
       {
            if(a[j]<a[min])
            {
                min=j;
            }
       }
            temp=a[min];
            a[min]=a[i];
            a[i]=temp;
    }
    printf("\nsorted elements are:");
    for(i=0;i<n;i++)
    {
       printf("%d ",a[i]);
    }

}
