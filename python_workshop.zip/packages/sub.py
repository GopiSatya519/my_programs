def sub(a,b):
    c= a-b
    return c
