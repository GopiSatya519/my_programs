def mul(a,b):
    c=a*b
    return c 