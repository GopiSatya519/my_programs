#include<iostream>
using namespace std;
template <class t>
 void show(t a)
 {
    cout<<"\na= "<<a;
 }
int main()
{
    cout<<"NAME:G SATYA \n ID NO:S170487\n";
   int a=20;
   float b=20.2;
   char c='S';
   show(a);
   show(b);
   show(c);
}
