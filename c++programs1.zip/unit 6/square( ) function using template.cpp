#include<iostream>
using namespace std;
template <class t>
class square
{
   public:
   square(t a)
   {
       cout<<"\nsquare of a "<<a<<" is "<<a*a;
   }
};
int main()
{
    cout<<"NAME:G.SATYA\nID NUM:S170487";
    square <int> a(10);
     square <float> b(10.2);

}
