#include<iostream>
using namespace std;
#include<stdlib.h>
template <class t>
class node
{
   public:
   t data;
   node *link;
node *root=NULL;
void append()
{
   node *temp;
   temp=(node*)malloc(sizeof(node));
   cout<<"enter node data:";
   cin>>temp->data;
   temp->link=NULL;
   if(root==NULL)
   {
     root=temp;
   }
   else
   {
      node *p=root;
      while(p->link!=NULL)
      {
         p=p->link;
      }
      p->link=temp;
   }
}
void display()
{
   if(root==NULL)
   {
      cout<<"\nstack is empty..";
   }
   else
   {
     cout<<"\nelements in stack are:";
     node *s=root;
     while(s!=NULL)
     {
         cout<<" "<<s->data;
         s=s->link;
     }
   }
}
};
int main()
{
   cout<<"NAME:G SATYA \nID NUM:S170487\n";
   node <int> p;
    int ch;
   cout<<"\nLinked list operations:";
   cout<<"\n1.APPEND";
   cout<<"\n2.DISPLAY";
   cout<<"\n3.exit";
   while(1)
   {
   cout<<"\nEnter your choice:";
   cin>>ch;
   switch(ch)
   {
      case 1:p.append();
             break;
      case 2:p.display();
             break;
      case 3:exit(1);
             break;
      default:cout<<"\nINVALID CHOICE";
   }
   }

}
