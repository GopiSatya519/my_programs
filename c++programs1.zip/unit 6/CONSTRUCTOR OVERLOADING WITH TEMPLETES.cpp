#include<iostream>
using namespace std;
template <class t>
class num
{
public:
  num(t a)
  {

     cout<<"a="<<a<<" and size of a="<<sizeof(a)<<"\n";
  }
};
int main()
{cout<<"NAME:G SATYA \n ID NO:S170487\n";
   num <int> a(10);
   num <double> b(10.45);
   num <char> c('A');
}
