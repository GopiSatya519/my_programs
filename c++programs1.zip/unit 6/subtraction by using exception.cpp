#include<iostream>
using namespace std;
int sub(int x,int y)
{
     int j;
     j=x>y? 0:1;
     try
     {
       if(j==0)
       {
          cout<<"\nsubtraction of (x-y):"<<x-y;
       }
       else
       {
           throw 1;
       }
     }
     catch(int a)
     {
        cout<<"\nsubtraction is not done because j=1";
     }
}
int main()
{
    cout<<"NAME:G SATYA \n ID NUM:S170487";
    sub(2,3);
    sub(4,2);
}
