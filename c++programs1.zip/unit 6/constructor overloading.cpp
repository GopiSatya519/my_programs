#include<iostream>
using namespace std;
class num
{
   public:
   num(int a)
   {
      cout<<"int a="<<a<<endl;

   }
   num(double a)
   {
      cout<<"float a="<<a<<endl;

   }
   num(char a)
   {
      cout<<"char a="<<a;
   }
};
int main()
{
    cout<<"NAME:G SATYA \n ID NO:S170487\n";
   num a(10);
   num b(10.2);
   num c('A');
}
