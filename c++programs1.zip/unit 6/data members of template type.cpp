#include<iostream>
using namespace std;
template <class t>
class num
{
public :
num(t a)
{
   cout<<"a= "<<a;
}
void show(t b)
{
  cout<<"\nb= "<<b;

}
};
int main()
{
   cout<<"NAME:G SATYA \n ID NO:S170487\n";
  num <int> a(10);
  a.show(20);
}
