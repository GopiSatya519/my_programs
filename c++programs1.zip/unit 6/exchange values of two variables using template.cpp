#include<iostream>
using namespace std;
template <class t1>

void show(t1 &a,t1 &b)
{
   t1 c;
   c=a;
   a=b;
   b=c;

}
int main()
{cout<<"NAME:G.SATYA\nID NUM:S170487";
   int a=10,b=20;
   cout<<"\nBefore exchanging X="<<a<<" y="<<b;
   show(a,b);
    cout<<"\nAfter exchanging X="<<a<<" y="<<b;
}
