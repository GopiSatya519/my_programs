#include<iostream>
using namespace std;
int satya(int x)
{
    try
    {
    if(x==0) throw x;
    else if(x>0) throw 'x';
    else throw 1.1;
    }
    catch (int y)
    {
       cout<<"\n null value";
    }
    catch(char y)
    {
       cout<<"\npositive value";
    }
    catch(double y)
    {
       cout<<"\nnegTIVE value:";
    }
    cout<<"\n...*******...";

}
int main()
{
        cout<<"NAME:G SATYA \n ID NUM:S170487";

   satya(0);
   satya(34);
   satya(-20);
}
