#include<iostream>
using namespace std;
template <class a,class b,class c>
void show(a x,b y,c z)
{
   cout<<"\nx="<<x<<" y="<<y<<" z="<<z;
}
int main()
{
   show(10,10.2,'S');
   show(20,20.4,'K');
   show(30,30.6,'P');
   show(40,40.8,'S');
}
