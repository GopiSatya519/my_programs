#include<iostream>
# include <process.h>
# include <stdlib.h>
 # include <assert.h>
using namespace std;

template <class O>

void display (O d)
{
    cout<<(float) (rand( )%(d*d))<<"\n";
    assert(d!=1);
    display(--d);

}

int main ( )
 {  cout<<"NAME:G.SATYA\nID NUM:S170487";
      int x=10;
      display(x);

      }
