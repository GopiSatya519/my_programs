#include<stdio.h>

int main(void)
{
    int upper = 0, lower
}
