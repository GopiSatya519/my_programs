#include<iostream>
using namspace std;
template <class t>
void show(t a)
{
cout <<"\n Template variable a= "<<a;
}
void show(int a)
{
 cout <<"\n Integer variable i = "<<a;
}
int main()
{
cout<<"NAME:G.SATYA\nID NUM:S170487";
  show(10.2);
  show(19);
  show('s');
}
