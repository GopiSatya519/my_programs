#include<stdio.h>
int main()
{
int i;
    double abc[5]={1.1,2.3,3.6};
    for(i=0;i<5;i++)
    {
       printf("%f  ",abc[i]);
    }
}
