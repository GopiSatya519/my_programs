#include<iostream>
using namespace std;
template <class t1,class t2>
class num{
public:
void show(t1 a,t2 b)
{
     cout<<"\ninteger array="<<a<<" floating array="<<b;
}
};
int main()
{ cout<<"NAME:G.SATYA\nID NUM:S170487";
   int a[10]={1,2,3,4,5,6,7,8,9,10};
   float b[10]={1.1,2.1,3.1,4.1,5.1,6.1,7.1,8.1,9.1,10.1};
   num <int,float> s;
   int i;
   for(i=0;i<10;i++)
   {
     s.show(a[i],b[i]);
   }
}
