#include<iostream>
using namespace std;
template <class t>
class num{
 public:
   num (t a);
};
template <class t>
num<t>::num(t a)
{
  cout<<"\nout of the declaration a="<<a;
}
int main()
{
cout<<"NAME:G.SATYA\nID NUM:S170487";
  num <int> i(10);
  num <float> j(10.3);
  num <char> k('S');
}
