#include<iostream>
using namespace std;
template <class t1, class t2>
class num
{
public:
num(t1 a,t2 b)
{
   cout<<"\n a="<<a<<" b="<<b;
}
};
int main()
{
cout<<"NAME:G.SATYA\nID NUM:S170487";
  num <int,float> a(10,20.4);
  num <float,char> b(1.3,'A');
  num <char,int> c('S',19);
}
