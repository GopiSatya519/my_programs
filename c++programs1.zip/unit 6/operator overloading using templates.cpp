#include<iostream>
using namespace std;
template <class t>
class num{
 t number;
  public:
  num()
  {
    number=0;
  }
  void input( )
  {
     cout<<"\n enter a number:";
     cin>>number;
  }
  num operator + (num);
  void show()
  {
     cout<<"number="<<number;
  }
};
template <class t>
num <t> num <t>:: operator + (num <t> b)
{
   num <t> tem;
   tem.number=number+b.number;
   return tem;
}
int main()
{
    cout<<"NAME:G.SATYA\nID NUM:S170487";
   num <int> a,b,c;
   a.input();
   b.input();
   c=a+b;
   c.show();
}
