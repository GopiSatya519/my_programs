#include<stdio.h>
#include<string.h>
#define MAXSIZE 100
char stack[MAXSIZE];
int top=-1;
void push(char item)
{
    if(top>MAXSIZE-1)
    {
        printf("stack overflow.");
    }
    else
    {
        stack[++top]=item;
    }

}
char pop()
{
    char item;
    item=stack[top];
    top--;
    return item;
}
int is_operator(char item)
{
    if(item=='^'||item=='%'||item=='+'||item=='*'||item=='-'||item=='/')
    {
        return 1;
    }
    else
        return 0;
}
int precedence(char item)
{
    if(item=='^')
        return 3;
    else if(item=='*'||item=='/')
        return 2;
    else if(item=='+'||item=='-')
        return 1;
    else
        return 0;
}
int main()
{
    char infix[MAXSIZE],postfix[MAXSIZE],item,temp;
    int i=0,j=0;
    printf("enter the infix expression:");
    gets(infix);
    while(infix[i]!='\0')
    {
        item=infix[i];
        if(item=='(')
        {
            push(item);
        }
        else if((item>='A'&&item<='Z')||(item>='a'&&item<='z')||(item>='0'&&item<='9'))
        {
            postfix[j]=item;
            j++;
        }
        else if(is_operator(item)==1)
        {
            temp=pop();
            while(is_operator(temp)==1&&(precedence(temp)>=precedence(item)))
            {
                postfix[j]=temp;
                j++;
                temp=pop();
            }
            push(temp);
            push(item);

        }
        else if(item==')')
        {
            temp=pop();
            while(temp!='(')
            {
                postfix[j]=temp;
                j++;
                temp=pop();
            }
        }
        else
        {
            printf("invalid expression.");
        }
        i++;

    }
    while(top>-1)
    {
     postfix[j]=pop();
     j++;
    }
    postfix[j]='\0';
    printf("postfix expression:");
    puts(postfix);
  return 0;
}
