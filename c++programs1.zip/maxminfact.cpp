#include<iostream>
using namespace std;
int main()
{
int a[]={1,2,3,4,5,6,7};
int min,max,fact=1,num;
min=a[0],max=a[0];
for(int i=0;i<7;i++)
{
   if(min>a[i])
   {
     min=a[i];
    }
}
for(int i=0;i<7;i++)
{
   if(max<a[i])
   {
     max=a[i];
    }
}
cout<<"max="<<max<<"min"<<min;
num=max-min;
for(int i=num;i>0;i--)
{
    fact=fact*i;
}
cout<<"\nfact="<<fact;

}
