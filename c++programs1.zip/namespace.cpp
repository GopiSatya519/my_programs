#include<iostream>
using namespace std;
int a=20;
 namespace n1
{
   int a=10;
}
int main()
{
     int a;
     a=30;
     cout<<a<<" "<<::a<<" "<<n1::a;
}
