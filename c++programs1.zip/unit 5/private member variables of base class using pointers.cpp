#include<iostream>
using namespace std;
class a
{
    int x;
    int y;
    public:
    a()
    {
      x=1;
      y=2;
    }
};
class b:private a
{
    public:
    int z;
    b()
    {
       z=3;
    }

};
int main()
{
    cout<<"NAME:G SATYA \nID NUM:S170487";
    b s;
    int *p;
    p=&s.z;
    cout<<"\naddress of z="<<(unsigned)p<<" "<<"value of z="<<*p;
    p--;
     cout<<"\naddress of y="<<(unsigned)p<<" "<<"value of y="<<*p;
     p--;
      cout<<"\naddress of x="<<(unsigned)p<<" "<<"value of x="<<*p;

}
