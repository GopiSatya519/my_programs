#include<iostream>
using namespace std;
class a
{
public:
int a;
};
class b :public a
{
public:
int b;
};
class c:public b
{
     public:
     int c;
     void get()
     {
     cout<<"\nenter a b and c values:";
     cin>>a>>b>>c;
     }
     void show()
     {
     cout<<"\na="<<a<<" b="<<b<<" c="<<c;
     }
};
int main()
{
    cout<<"NAME:G SATYA \n ID NUM:S170487";
     c s;
     s.get();
     s.show();
}
