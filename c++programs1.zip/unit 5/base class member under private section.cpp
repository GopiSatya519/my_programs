#include<iostream>
using namespace std;
class a
{
    int x;
    public:
    a()
    {
       x=10;
    }
    void show()
    {
       cout<<"\n x="<<x;
    }
};
class b: public a
{ int y;
    public:
    b()
    {
    y=20;
    }
    void showy()
    {
        show();
        cout<<"\n y="<<y;
    }
};
int main()
{
    cout<<"NAME:G SATYA \n ID NUM:S170487";
   b s;
   s.showy();
}
