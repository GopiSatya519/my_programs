# include <iostream>
using namespace std;


class A1
{
  public  :
   char name[15];
     int age;
};


class A2 : public A1
{
 private :
  A1 a;
  float height;
  float weight;
   public :


A2( )

{
 cout <<"Access Using Scope Access operator\n";

cout <<"Name    : "; cin>>A1::name;
cout <<"Age      : "; cin>>A1::age;
cout <<"Access Using object of the class\n";
cout <<"Name   : "; cin >>a.name;
cout <<"Age       : "; cin >>a.age;
cout <<"Access Using direct member variables\n";
cout <<"Name   : "; cin >>name;
cout <<"Age      : "; cin >>age;
cout <<"Height  : "; cin >>height;
cout <<"Weight : "; cin >>weight;
  }
 ~A2( )
 {
 cout <<"\nDisplay using Scope Access operator\n";
 cout <<"\nName  : " <<A1::name;
 cout <<"\nAge     : " <<A1::age;
 cout <<"\nDisplay Using object of the class\n";
 cout <<"\nName  : " <<a.name;       cout <<"\nAge     : " <<a.age;
 cout <<"\nAccess Using direct member variables\n";
 cout <<"\nName  : " <<name;       cout <<"\nAge     : " <<age;
 cout <<"\nHeight  : " <<height;       cout <<"\nWeight : " <<weight;   } };


int main( )
 {
 cout<<"NAME:G SATYA \nID NUM:S170487\n";
 A2 x;
  }
