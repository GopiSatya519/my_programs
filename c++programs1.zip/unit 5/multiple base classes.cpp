#include<iostream>
using namespace std;
class a
{
   public:
   int a;
};
class b
{
  public:
  int b;
};
class c
{
    public:
    int c;
};
class d:public a,b,c
{
public:
    int d;
void get()
{
    cout<<"\n enter a,b,c and d values:";
    cin>>a>>b>>c>>d;
}
void put()
{
  cout<<"\na="<<a<<" b="<<b<<" c="<<c<<" d="<<d;
}
};
int main()
{
    cout<<"NAME:G SATYA \n ID NUM:S170487";
 d s;
 s.get();
 s.put();
}
