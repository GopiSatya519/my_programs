#include<iostream>
using namespace std;
class a
{
   protected:
   int x;
};
class b:private a
{
int y;
    public:
    b()
    {
    y=20;
    x=10;
    }
    void show()
    {
        cout<<"\n x="<<x;
        cout<<"\n y="<<y;
    }
};
int main()
{cout<<"NAME:G SATYA \n ID NUM:S170487";
  b s;
  s.show();
}
