#include<iostream>
using namespace std;
class a
{
   public:
   int x;
};
class b:public a
{
   public:
   int y;
};
int main()
{
  cout<<"NAME:G SATYA \n ID NUM:S170487";
   b s;
   s.x=10;
   s.y=20;
   cout<<"\nclass a x="<<s.x;
   cout<<"\nclass b y="<<s.y;
}
