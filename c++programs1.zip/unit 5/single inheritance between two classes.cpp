#include<iostream>
using namespace std;
class stu
{
protected:
  char name[10];
  int age;
};
class det:public stu
{
    private:
    int height;
     int weight;
    public:
    void get()
    {
    cout <<"\n Enter Name and Age : ";
    cin >>name>>age;
    cout <<"\n Enter Height and Weight : ";
    cin >>height >>weight;
    }
    void show()
    {
    cout <<"\n Name and Age : "<<name<<" "  <<age;
    cout <<"\n  Height and Weight : "<<height <<" "<<weight;
    }
};
int main()
{
    cout<<"NAME:G SATYA \n ID NUM:S170487";
   det s;
   s.get();
   s.show();
}
