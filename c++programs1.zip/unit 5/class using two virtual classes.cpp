#include<iostream>
using namespace std;
class a
{
   protected:
   int a1;
};
class b:public virtual a
{
  protected:
  int a2;
};
class c:public virtual a
{
protected:
int a3;
};
class d:public b,c
{
   public:
       int a4;
   void get()
   {
       cout<<"\nenter the values of a1,a2,a3 and a4  :";
       cin>>a1>>a2>>a3>>a4;

   }
   void put()
   {
     cout<<"\nvalues of a1 a2 a3 and a4:"<<a1<<" "<<a2<<" "<<a3<<" "<<a4;
   }
};
int main()
{
    cout<<"NAME:G SATYA \nID NUM:S170487";
   d s;
   s.get();
   s.put();
}
