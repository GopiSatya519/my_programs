#include<iostream>
using namespace std;
class a
{
   public:
   void show()
   {
      cout<<"\nIt is show() fun of base class";
   }
};
class b:public a
{
   public:
   void show()
   {
     cout<<"\n It is show() function of derived class";
   }
};
int main()
{
   cout<<"NAME:G SATYA \nID NUM:S170487";
   a s;
   b p;
   s.show();
   p.show();
   p.a::show();
   }
