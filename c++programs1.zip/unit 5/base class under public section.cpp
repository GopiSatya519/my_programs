#include<iostream>
using namespace std;
class a
{
  public:
  int x;
};
class b:private a
{
    int y;
    public:
    b()
    {
    x=10;
    y=20;
    }
     void show()
     {
        cout<<"\n x="<<x<<" y="<<y;
     }
};
int main()
{
    cout<<"NAME:G SATYA \n ID NUM:S170487";
   b s;
   s.show();

}
