#include<iostream>
using namespace std;
class I
{
    public:
    int a;
    I()
    {
       cout<<"\nIN constructor of I";
       a=20;
    }
};
class II
{
    public:
    int b;
    I s;
    II()
    {
        cout<<"\nconstructor of class II";
        b=30;
    }
    void show()
    {
        cout<<"\na="<<s.a<<" b="<<b;
    }
};
int main()
{
   cout<<"NAME:G SATYA \nID NUM:S170487";
   II t;
   t.show();
}
