#include<iostream>
using namespace std;
class a
{
   public:
   a()
   {}
   int x;
   class b
   {
     public:
     b()
     {}
     int y;
   };
};
class c:public a,a::b
{
    public:
    int z;
    c(int i,int j,int k)
    {
       x=i;
       y=j;
       z=k;
       cout<<"\nx="<<x<<" y="<<y<<" z="<<z;
    }
};
int main()
{
   cout<<"NAME:G SATYA \nID NUM:S170487";
   c s(1,2,3);

}
