#include<iostream>
using namespace std;
class a
{
    protected:
    int x;
    int y;
};
class b: private a
{
    int z;
    public:
    b()
    {
       x=1;
       y=4;
       z=12;
       cout<<"\nx="<<x<<" y="<<y<<" z="<<z;
    }
};
int main()
{
    cout<<"NAME:G SATYA \nID NUM:S170487";
   b s;
}
