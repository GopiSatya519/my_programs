#include<iostream>
using namespace std;
class num
{
   public:
   int x,y;
   num()
   {
   }
   num(int j,int k)
   {
      x=j;
      y=k;
   }
   void show()
   {
      cout<<"x="<<x<<"y="<<y<<endl;
   }
};
int main()
{
   num a(1,2),b(3,4),c;
   a.show();
   b.show();
   c.x=a.x+b.x;
   c.y=a.y+b.y;
   c.show();
}
