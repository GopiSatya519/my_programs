#include<iostream>
using namespace std;
class num
{
   float a;
   public:
   num(float i)
   {
      a=i;
   }
   num operator ++ (int)
   {
     a++;
   }
   void show()
   {
      cout<<"a="<<a;
   }
};
int main()
{
   num x(2.4);
   x++;
   x.show();
}
