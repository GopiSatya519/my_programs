#include<iostream>
using namespace std;
class num
{
   int a;
   public:
   num(int i)
   {
      a=i;
   }
   num operator -- ()
   {
       --a;
   }
   void show()
   {
      cout<<"a="<<a;
   }
};
int main()
{
   num x(2);
   --x;
   x.show();
}
