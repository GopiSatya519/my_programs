#include<iostream>
using namespace std;
class num
{
   int x,y;
   public:
   num()
   { }
   num(int i,int j)
   {
     x=i;
     y=j;
   }
   num operator / (num D)
   {
      num T;
      T.x=x/D.x;
      T.y=y/D.y;
      return T;
   }
   void show()
   {
       cout<<"x="<<x<<"y="<<y<<endl;
   }
};
int main()
{
   num a(4,6),b(2,2),c;
   a.show();
   b.show();
   c=a/b;
   c.show();

}
