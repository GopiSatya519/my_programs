import java.lang.*;
import java.util.*;
class Student{

    String name;
    String id;
    float per;
    void read(){
     Scanner s=new Scanner(System.in);
     System.out.println("enter name:");
     name=s.nextLine();
     System.out.println("enter id:");
     id=s.nextLine();
     System.out.println("percentage:");
     per=s.nextFloat();
     if(per<0 || per>100)
{
       System.out.println("invalid");
       System.out.println("percentage:");
     per=s.nextFloat();

}

   }
    void display(){
     System.out.println("name"+name);
     System.out.println("id:"+id);
     System.out.println("percentage:"+per);
     System.out.print("grade is ");
     grade(per);

}
void grade(float p){

    if(p>90)
{
    System.out.println("Ex");

}
  else if(p>80)
    System.out.println("A");
  else if(p>70)
{
   System.out.println("B");

}
   else if(p>60)
     System.out.println("C");
   else if(p>50)
     System.out.println("D");
   else()
     System.out.println("F");
}
}
class Student1{

 public static void main(String args[]){

       Student st=new Student();
        st.read();
        st.display();
         }
}

