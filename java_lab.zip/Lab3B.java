import java.lang.*;
import java.util.*;
class Outer{
    int a=5;
    static int b=10;
    void outer()
{
    System.out.println("outer class method called");
}
static void outer1()
{
    System.out.println("static outer class method called");
}
static class Nested{
    
  void inner()
{
    Outer p=new Outer();
    p.outer();
    System.out.println("nested class method called");
}
static void inner1()
{    Outer p1=new Outer();
     p1.outer1();
    System.out.println("static nested class method called");
}
}
Nested n=new Nested();


}
class Lab3B{
    public static void main(String args[])
{
   Outer o=new Outer();
   o.n.inner();
   o.n.inner1();
  
}

}