import java.lang.*;
import java.util.*;
abstract class Animal{
   
    abstract void sound();
    void print()
{
  System.out.println("Animal class");
}
}
class Dog extends Animal{
  void sound()
{
  System.out.println("Dog barking");
}
}
class Cat extends Animal{
   void sound()
{
  System.out.println("Cat mue");
}
}
class Lab5A{
public static void main(String args[])
{
     Animal a;
     a=new Dog();
     a.sound();
     a=new Cat();
     a.sound();
}
}