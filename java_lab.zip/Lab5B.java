import java.lang.*;
import java.util.*;
interface Exam
{
   void subject();
}
class Exam1 implements Exam{
   public void subject(){
    System.out.println("Its OOPs exam");
}
}
class Exam2 implements Exam{
   public void subject(){
     System.out.println("Its DAA exam");
}
}
class Lab5B{
   
   public static void main(String args[])
{
     Exam e;
     e=new Exam1();
     e.subject();
     e=new Exam2();
     e.subject();
}

}
