import java.io.*;
public class Assig2
{
   public static void main(String args[]) throws Exception
{
    FileInputStream fis=new FileInputStream("characterfile.txt");
    FileOutputStream fos=new FileOutputStream("without_dup.txt");
    FileOutputStream fos1=new FileOutputStream("with_dup.txt");
    byte[] b=new byte[fis.available()];
    char[] ch=new char[b.length];
    char[] ch1=new char[b.length];
    fis.read(b);
    for (int k=0;k<b.length ;k++ )
    {
     ch[k]=(char)b[k];
    }
    
    for (int k=0;k<ch.length ;k++ )
    {
      int c=0;
     for(int i=k+1;i<ch.length;i++)
     {
       if(ch[k]==ch[i]&&ch[k]!='\0')
       {
         ch[i]='\0';
         c++;
       }
     }
     if(c!=0&&ch[k]!='\0')
    {
       fos1.write(ch[k]);
     }
    }
    System.out.println("\n");
   for (int k=0;k<ch.length ;k++ )
  {
    if(ch[k]!='\0')
      fos.write(ch[k]);
  }
    

}
}