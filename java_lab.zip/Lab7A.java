import java.util.*;
import java.lang.*;
class Lab7A
{
   static int marks[]=new int[6];
   public static void main(String args[])
  {
       Scanner sc=new Scanner(System.in);
     try{
       System.out.println("ennter your all 6 subjects marks");
       for(int i=0;i<6 ;i++ )
     {
       marks[i]=sc.nextInt();
       
      
     }
      System.out.println("Array value marks[7]"+marks[7]);
      System.out.println("Division:"+(marks[1]/0));
     
 }
      
catch(ArithmeticException ae)
{
System.out.println("Denominator should not be zero");
}
catch(ArrayIndexOutOfBoundsException e)
{
System.out.println("please enter valid subject number");
}
catch(Exception j)
{
System.out.println("Error occured while running the program");
}
}
}