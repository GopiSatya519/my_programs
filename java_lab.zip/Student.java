import java.lang.*;
import java.util.*;
class Student{

    String name;
    String id;
    float per;
    read();
    display();
    void read(){
     Scanner s=new Scanner(System,in);
     System.out.println("enter name:");
     name=nextLine();
     System.out.println("enter id:");
     id=nextLine();
     System.out.println("percentage:");
     per=nextFloat();

   }
    void display(){
     System.out.println("name"+name);
     System.out.println("id:"+id);
     System.out.println("percentage:"+per);
     System.out.println("grade"+grade(per));

}
void grade(float p){

    if(p>90)
{
    System.out.println("Ex");

}
  if(p>80)
    System.out.println("A");
  if(p>70)
{
   System.out.println("B");

}
   if(p>60)
     System.out.println("C");
   if(p>50)
     System.out.println("D");
   if(p<=50)
     System.out.println("F");
}
}
class Student1{

 public static void main(String args[]){

       Student st=new Student();
        st.read();
        st.display();
         }
}

