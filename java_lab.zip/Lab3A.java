import java.lang.*;
import java.util.*;
class Outer{
   static int x=10;
   static void outer()
{
    System.out.println("outer method called");
   
}
   class Inner{

     void inner()
{
    //static int y=11;
   System.out.println("inner method called");
   
    System.out.println("Outer class x value:"+x);
   outer();
}
}
}
class Lab3A{
   public static void main(String args[])
{
   Outer i=new Outer();
   Outer.Inner i1=i.new Inner();
   i1.inner();
}

}
