
class Display
{
public static synchronized void show(String name)
{
for(int i=0;i<5;i++)
{
synchronized(Display.class)
{
System.out.print("good afternoon:");
try{
Thread.sleep(2000);
}
catch(Exception e)
{
}
System.out.println(name);
}
}
}
};

class Cse extends Thread
{
Display d;
String name;
Cse(Display d,String name)
{
this.d=d;
this.name=name;
}
public void run()
{
d.show(name);
}
};
class Lab9A
{
public static void main(String args[])throws Exception
{
Display d1=new Display();
Display d2=new Display();
Cse c1=new Cse(d1,"jk");
Cse c2=new Cse(d2,"daddy");
c1.start();
c2.start();
}
}