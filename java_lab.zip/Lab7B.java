import java.util.*;
public class Lab7B extends Throwable
{
      Lab7B(String s)
      {
           super(s);
      }
      public static void main(String args[])
      {
             Scanner sc=new Scanner(System.in);
             try{
             System.out.println("enter name:");
             String name=sc.nextLine();
              System.out.println("enter rool number:");
             String roll=sc.nextLine();
             System.out.println("enter your ds marks:");
             int marks=sc.nextInt();
             
             if(marks<50)
             { 
                   throw new Lab7B("marks must be greater than 50 to enter into next sem");
             }
             if(roll.length()!=7)
             { 
                   throw new Lab7B("enter roll number correctly");
             }
             System.out.println("name is:"+name);
             System.out.println("roll number is:"+roll);
         
            }
           catch(Lab7B ude)
           {
                 System.out.println(ude.getMessage());
           }
           catch(Throwable e)
           {
                 System.out.println("exception raised");
           }
      }
}