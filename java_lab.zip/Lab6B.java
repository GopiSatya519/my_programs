import java.io.*;
class Lab6B{
     public static void main(String args[]) throws Exception
{
   byte [] array={1,2,3,4,5,6,7,8,9};
   ByteArrayInputStream bais=new ByteArrayInputStream(array);
   for(int i=0;i<array.length;i++)
{
    int data=bais.read();
    bais.skip(2);
    if(data==-1)
{
   break;
}
  System.out.println(data);
}
   FileOutputStream f1=new FileOutputStream("abc.txt",true);
   FileOutputStream f2=new FileOutputStream("def.txt",true);
   FileOutputStream f3=new FileOutputStream("xyz.txt",true);
   ByteArrayOutputStream baos= new ByteArrayOutputStream();
   baos.write('s');
   baos.writeTo(f1);
   baos.writeTo(f2);
   baos.writeTo(f3);
   baos.flush();
   baos.close();

}


}