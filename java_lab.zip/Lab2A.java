import java.util.*;
class IntStr{
	String onetoten[]={"zero","one","two","three","four","five","six","seven","eight","nine"};
	String tentotwenty[]={"ten","eleven","twelve","thirteen","fourteen","fifteen","sixteen","seventeen","eighteen","ninteen"};
	String tenmultiples[]={"","","twenty","thirty","forty","fifty","sixty","seventy","eighty","ninety"};
	void text(int temp)
	{
		if(temp/10>0)
		{
			text(temp/10);
		}
		System.out.print(onetoten[temp%10]+" ");
	}

	void word(int temp)
	{
		if(temp>=1000)
		{
			System.out.print(onetoten[temp/1000]+" thousand ");
			temp %=1000;
		}
		if(temp>=100)
		{
			System.out.print(onetoten[temp/100]+" hundred ");
			temp %=100;
		}
		if(temp>=20)
		{
			System.out.print(tenmultiples[temp/10]+" ");
			temp %=10; 
		}
		if(temp>=10)
		{
			System.out.print(tentotwenty[temp%10]+" ");
			temp=0;
		}
		if(temp>=1)
		{
			System.out.print(onetoten[temp%10]+" ");
		}
	}
}
class Lab2A{
	public static void main(String args[])
	{
		int number;
		Scanner s=new Scanner(System.in);
		System.out.print("Enter a number less than 10,000 :");
		number =s.nextInt();
		IntStr o=new IntStr();
		if(number<10000)
		{
			System.out.print("\nText format "+number+" - ");
			o.text(number);

			System.out.print("\nWord format "+number+" - ");
			o.word(number);
		}
		else
			System.out.print("Sorry invalid input... please enter in between(0 to 10000)");

	}
}
