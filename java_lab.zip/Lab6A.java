import java.io.*;
import java.util.*;
import java.lang.*;
class Lab6A{
    public static void main(String args[]) throws Exception
{
 
    FileReader fr=new FileReader("lab3.txt");
    BufferedReader br=new BufferedReader(fr);
  String s=br.readLine();
   System.out.println(s);
   
  
    FileWriter fw=new FileWriter("lab3.txt",true);
     BufferedWriter bw=new BufferedWriter(fw);
    bw.write("deepthi");
    bw.newLine();
    bw.write("satya");
    
    PrintWriter pw=new PrintWriter(bw);
     bw.newLine();
    pw.println(100);
    pw.println(10.3f);
    
    pw.flush();
    
   
    
}

}