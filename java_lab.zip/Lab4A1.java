import java.lang.*;
import java.util.*;
class BaseClass
{
     int x=10;
     void fun()
    {
  System.out.println("base class function is called");
    }

}
class SingleInheritance extends BaseClass{
    void single(){
    System.out.println("SingleInheritance class function is called");
    System.out.println("Base class x value:"+x);
    fun();
}
}
class MultilevelInheritance extends SingleInheritance{
     void multiLevel(){
     single();
     System.out.println("MultilevelInheritance class is called");
    } 
}
class derivedcls2 extends BaseClass {
     void derived2()
{
   System.out.println("DerivedClass2 function is called");
    System.out.println("Base class x value:"+x);
    fun(); 
}
}
class hybrid1 extends SingleInheritance{
     void hyb1(){
     System.out.println("hybrid Inheritance 1");
     single();
}
}
class hybrid2 extends SingleInheritance{
void hyb2(){
     System.out.println("hybrid Inheritance 2");
     single();
}
}
class Lab4A1{
  
    public static void main(String args[])
{
    SingleInheritance si=new SingleInheritance();
   System.out.println("---Single inheritance---");
   si.single();
    MultilevelInheritance mi=new MultilevelInheritance();
   System.out.println("---Single MultilevelInheritance---");
    mi.multiLevel();
   derivedcls2 d3=new derivedcls2();
   System.out.println("---Single heirarical inheritance---");
   d3.derived2();
   System.out.println("---Single hybrid inheritance---");
   hybrid1 h1=new hybrid1();
   hybrid2 h2=new hybrid2();
   h1.hyb1();
   h2.hyb2();
    

}
}