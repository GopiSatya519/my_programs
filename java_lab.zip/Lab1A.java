import java.lang.*;
import java.util.*;
class Details{
  String name,gender,branch,id;
  int age,marks;
  void details()
{
    Scanner s=new Scanner(System.in);
    System.out.println("Enter your Id:");
     id=s.nextLine();
    System.out.println("Enter your name:");
     name=s.nextLine();
    System.out.println("Enter your branch:");
     branch=s.nextLine();
    System.out.println("enter your age:");
      age=s.nextInt();
    System.out.println("Enter your gender(male/female/other):");
     gender=s.nextLine();
    System.out.println("Enter your marks in percentage of E1-sem2:");
     marks=s.nextInt();
     }
void display()
{
    System.out.println("Welcome to "+id+" java course");
    System.out.println("Name:"+name);
    System.out.println("Branch:"+branch);
    System.out.println("Age:"+age);
    System.out.println("Gender:"+gender);
    System.out.println("Marks in DS % of E1-Sem2:"+marks); 
}
}
class Lab1A{

public static void main(String args[])
{
    Details d=new Details();
    d.details();
    d.display();
}
}





