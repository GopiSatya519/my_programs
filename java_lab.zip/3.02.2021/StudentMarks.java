import java.lang.*;
import java.util.*;
class Student
{
   void assign()
{
   int a[]=new int[6];
   Scanner s=new Scanner(System.in);
   System.out.println("enter 6 subject marks:");
   for(int i=0;i<6;i++)
{
    a[i]=s.nextInt();
}
   calculate(a);

}
void calculate(int a[])
{
  int sum=0,per;
    for(int i=0;i<6;i++)
{
    sum=sum+a[i];
}
System.out.println("sum of total marks "+sum);
per=(sum*100)/600;
System.out.println("percentage :"+per+"%");
}

}
class StudentMarks
{
   public static void main(String args[])
{
   Student p=new Student();
   p.assign(); 
}
}
