import java.lang.*;
import java.util.*;
class Students
{
   void assign(int n)
{
   int a[][]=new int[n][6];
   Scanner s=new Scanner(System.in);
   for(int i=0;i<n;i++)
{
    System.out.println("enter the marks for each subject");
    for(int j=0;j<6;j++)
{
    a[i][j]=s.nextInt();
}
}
calculate(a,n);
}
void calculate(int a[][],int n)
{
  
    for(int i=0;i<n;i++)
{
int sum=0,per;
   for(int j=0;j<6;j++)
    {
sum=sum+a[i][j];
}
System.out.println("sum of total marks "+sum);
per=(sum*100)/600;
System.out.println("percentage :"+per+"%");
}
}

}
class StudentDetails
{
   public static void main(String args[])
{
  Scanner t=new Scanner(System.in);
  System.out.println("enter number of students ");
int n=t.nextInt();
  Students s=new Students();
  s.assign(n);

}
}
