import java.lang.*;
import java.util.*;
class Program3
{
public static void main(String args[])
{
    Scanner s=new Scanner(System.in);
    int r;
    System.out.println("enter radius of the circle");
    r=s.nextInt();
    System.out.println("area of circle "+3.14*r*r);
}
}
