import java.lang.*;
class Program2
{
    public static void main(String args[])
{
   long c=186000*24*60*60*1;
     System.out.println(" no of miles light travels per day"+c);
}
}