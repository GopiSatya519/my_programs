import java.lang.*;
import java.util.*;
class Calculater1
{
  void assign()
{
   Scanner s=new Scanner(System.in);
  System.out.println("enter first operend");
   int p1=s.nextInt();
  System.out.println("enter second operand");
   int p2=s.nextInt();
   System.out.println("1.addition");
   System.out.println("2.subtraction");
   System.out.println("3.multiplication");
   System.out.println("4.division");
   System.out.println("5.modulus");
  System.out.println("6.exit");
while(true)
{
   System.out.println("enter u r choice");
   int a=s.nextInt();
  switch(a)
{
    case 1:System.out.println("addition "+(p1+p2));
             break;
    case 2:System.out.println("subtraction "+(p1-p2));
             break;
    case 3:System.out.println("multiplication "+(p1*p2));
            break;
    case 4:if(p2==0)
             System.out.println(" exception caught ");
             else
             System.out.println("division "+(p1/p2));
              break;
    case 5 :System.out.println("modulo division "+(p1%p2));
              break;
    case 6 :System.exit(0);
              break; 

}
}
}
}
class Calculater
{
    public static void main(String args[])
{
   Calculater1 p=new Calculater1();
   p.assign(); 
}

}