import java.lang.*;
import java.util.*;
class Program4
{
    public static void main(String s[])
{
     int m=Integer.parseInt(s[0]);
     int y=Integer.parseInt(s[1]);
     if((m==1)||(m==3)||(m==5)||(m==7)||(m==8)||(m==10)||(m==12))
{
     System.out.println("number of days in "+m+" in year "+y+" is: 31");
}
else if((m==4)||(m==6)||(m==9)||(m==11))
{
   System.out.println("number of days in "+m+" month in year "+y+" is: 30");
}
else
{
   if((y%4==0) && (y%100!=0))
{
   System.out.println("number of days in "+m+" month in year "+y+" is: 29");
}
else
{
   System.out.println("number of days in "+m+" month in year "+y+" is: 28");
}
}
}
}
