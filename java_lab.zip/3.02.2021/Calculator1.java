import java.lang.*;
import java.util.*;
class Calc
{
       void assign()
       {
              while(true)
              {
              Scanner s=new Scanner(System.in);
              System.out.println("enter first operand:");
              int op1=s.nextInt();
             System.out.println("1.addition 2.subtraction 3.multiplication 4.division 5.modulus 6.exit");
             System.out.println("enter operaor:");
             int op=s.nextInt();
             System.out.println("enter second operand:");
             int op2=s.nextInt();
             System.out.println("enter 1 to calculate :");
             int c=s.nextInt();
            if(c==1)
           {
            switch(op)
            {
                    case 1:System.out.println("addition of numbers is:"+(op1+op2));
                     break;
                   case 2:System.out.println("difference between numbers is:"+(op1-op2));
                     break;
                   case 3:System.out.println("product of numbers is:"+(op1*op2));
                     break;
                  case 4:
                 if(op2==0)
                   System.out.println("can't divide by zero");
                  else
                   System.out.println("division of numbers is:"+(op1/op2));
                 break;
                 case 5:System.out.println("modulus of numbers is:"+(op1%op2));
                 break;
                 case 6:System.exit(1);
                 default:System.out.println("wrong choice");
            }
       }
  }
}
}
class Calculator1
{
     public static void main(String s[])
     {
           Calc c=new Calc();
          c.assign();
     }
}