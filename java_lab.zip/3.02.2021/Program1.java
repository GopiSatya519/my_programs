import java.lang.*;
import java.util.*;
class Program1
{
    public static void main(String args[])
{
    System.out.println("Welcom to Cse Department");
}
}
