import java.lang.*;
import java.util.*;
class Roots
{
   void assign()
{
    Scanner s=new Scanner(System.in);
    System.out.println("enter x^2 coefficent");
    int a=s.nextInt();
    System.out.println("enter x  coefficent");
    int b=s.nextInt();
    System.out.println("enter constant");
    int c=s.nextInt();
    int d=(b*b)-4*a*c;
    if(d>0)
{
      double root1=(-b+Math.sqrt(d))/(2*a);
      double root2=(-b-Math.sqrt(d))/(2*a);
     System.out.println("root1 "+root1+" root2 "+root2);
}
else if(d==0)
{
    int root1=(-b)/(2*a);
    System.out.println("root1=root2 "+root1);
}
else
{
   System.out.println(-b/(2*a)+"+"+ Math.sqrt(-d) / (2 * a)+"i");
  System.out.println(-b/(2*a)+"-"+ Math.sqrt(-d) / (2 * a)+"i");
  
}
}   
}
class Quadratic
{
   public static void main(String args[])
{
   Roots r=new Roots();
    r.assign();
}

}