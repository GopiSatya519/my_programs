import java.lang.*;
import java.util.*;
class Distance
{
   
    Scanner sc=new Scanner(System.in);

    System.out.println("enter the no.of days");
    int n=sc.nextInt();
    
    long y;
    void display()
   {
    y=n*24*60*60*186000;
    System.out.println("light travels in"+n+"days is"+y);
   }
}
class Lighttravel
{
   public static void main(String args[])
   {
     Distance d=new Distance();
     d.display();
   }
}