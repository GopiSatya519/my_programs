import java.lang.*;
import java.util.*;
class Roots1
{
   void assign()
{
  
    Scanner s=new Scanner(System.in);
  System.out.println("enter number of equations");
  int n=s.nextInt();
int x=0,y=0,z=0;
   for(int i=0;i<n;i++)
 {
    System.out.println("enter x^2 coefficent");
    int a=s.nextInt();
    System.out.println("enter x  coefficent");
    int b=s.nextInt();
    System.out.println("enter constant");
    int c=s.nextInt();
    System.out.println("equation is "+a+"x^2+"+b+"x+"+c);
   x=x+a;
   y=y+b;
   z=z+c;
 }
 System.out.println("Sum of all equation is "+x+"x^2+"+y+"x+"+z);
}   
}
class QuadraticEqua
{
   public static void main(String args[])
{
   Roots1 r=new Roots1();
    r.assign();
}

}