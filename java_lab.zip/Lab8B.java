
package com.javatpoint; 
class Lab8B{  
public static void main(String[] args){    
Student3 s=new Student3();   
s.setName("vijay");  
System.out.println(s.getName());  
}  
}  

