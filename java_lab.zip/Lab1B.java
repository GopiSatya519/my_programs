import java.lang.*;
import java.util.*;
class Super{
    int x,y,z=10;
    Super()
   {
    this(20);
    System.out.println("This is Super class constructor");
    
    }
   Super(int a)
   {

    System.out.println("Super class value of a="+a);
   }
}
class Derive extends Super{
   int x,y;
   Derive()
   {
    super();
    System.out.println("This is Derived class constructor");
   }

   void fun(int x,int y)
{
     this.x=x;
     this.y=y;
     
}
void print()
{
System.out.println("base class Z value through super keyword:"+super.z);
System.out.println("derived class A value using this keyword:"+x);
System.out.println("derived class A value using this keyword:"+y);
}

}
class Lab1B{
public static void main(String args[])
{
    Derive d=new Derive();
    d.fun(20,30);
    d.print();
}

}