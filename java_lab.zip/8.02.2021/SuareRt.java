import java.lang.*;
import java.util.*;
class Square
{
    float fun(int i,float sum,int n)
{
      sum=(i+sum)/2;
      if(sum*sum<n)
{
     return sum;
}
else 
{
    return fun(i,sum,n);
}
}

}
class SuareRt{

     public static void main(String args[])
{
     Square p=new Square();
     Scanner s=new Scanner(System.in);
     System.out.println("enter a val");
     int n=s.nextInt();
     int i=1,c=0;
    float sum;
     while(i*i<=n)
   {
    if(i*i==n)
   {
    System.out.println("square root"+i);
     c++;
    break; 
   }
  else 
  i++;
  }
if(c==0)
{
    sum=i;
    i=i-1;
    sum=(sum+i)/2;
    if(sum*sum>n)
   {
     System.out.println("square root"+p.fun(i,sum,n));
   }
   else
   System.out.println("square root"+sum);
}

}

}