import java.lang.*;
import java.util.*;
class SinInvX
{
    float pow(float x,int i)
       {
               float p=1;
               while(i>=0)
               {
                      p=p*x;
                      i--;
               }
             return p;
       }
      void sinx()
{
     Scanner s=new Scanner(System.in);
     System.out.println("enter value to get sin-1(x):");
     float x=s.nextFloat();
     float sum=0,p=1,t;
     int i;
     for(i=2;i<=30;i=i+2)
{
     p=p*(float)(i-1)/i;
     t=pow(x,i+1)/(i+1);
     sum=sum+p*t;

}
System.out.println("Degrees "+(sum*57.296));
}
}
class SinInverse
{
public static void main(String args[])
{
   SinInvX p=new SinInvX();
   p.sinx(); 
}
}