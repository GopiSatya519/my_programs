import java.util.*;
import java.lang.*;
class SquareRoot
{
     public static void main(String args[])
{
      Scanner s= new Scanner(System.in);
      double n=Math.pow(5,1/2);
      System.out.println(n);
}

}