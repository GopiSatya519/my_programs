import java.lang.*;
import java.util.*;
class Random1
{
   void positive(int p)
{
    if(p==1)
     System.out.println("Very Good!!! ");
    else if(p==2)
     System.out.println("Excellent ");
    else if(p==3)
     System.out.println("nice work..");
    else
     System.out.println("keep it up ");
      
}
  void negative(int p)
{
    if(p==1)
     System.out.println("No, please try again ");
    else if(p==2)
     System.out.println("Sorry, wrong answer, try again ");
    else if(p==3)
     System.out.println("Wrong, Try once more ");
    else
     System.out.println("Don’t lose hope, keep trying");
       
}

}
class Operation
{
    public static void main(String args[])
{
  Random1 t=new Random1();
  Scanner s=new Scanner(System.in);
  Random r= new Random();
  int c1=0,c2=0,c3=0,c4=0,c5=0,p1=0,p2=0,p3=0,p4=0,l1=0,l2=0,l3=0,l4=0;
while(true)
{
System.out.println("***************************");
System.out.println("1.Addition");
System.out.println("2.Subtraction");
System.out.println("3.Multiplication");
System.out.println("4.Division");
System.out.println("5.summery");
System.out.println("6.Exit");
System.out.println("***************************");
System.out.println("Enter u r choice");
int ch=s.nextInt();
switch(ch)
{
  case 1:int r1=r.nextInt(100);
         int r2=r.nextInt(100);
         int r3;
         c5++;
         l1++;
         System.out.println("------------");
         while(true)
        {
           System.out.println("How much is addition of "+r1+" and "+r2+"?:");
           r3=s.nextInt();
           c1++;
           if((r1+r2)==r3)
           {
             int c=r.nextInt(4);
             t.positive(c);
             break;  
           }
           else
          {
            int c=r.nextInt(4);
            t.negative(c);
           }
        }
        if(c1==1)
         p1++;
         c1=0;
        break;
 case 2:int r4=r.nextInt(100);
         int r5=r.nextInt(100);
         int r6;
         l2++;
         c5++;
          System.out.println("------------");
         while(true)
       {
           System.out.println("what is the value when "+r4+" is subtracted from "+r5+"?");
           r6=s.nextInt();
           c2++;
           if((r4-r5)==r6)
           {
             int c=r.nextInt(4);
             t.positive(c);
             break;  
           }
           else
          {
            int c=r.nextInt(4);
            t.negative(c);
           }

       }
       if(c2==1)
         p2++;
         c2=0;
     break;
case 3:int r7=r.nextInt(100);
         int r8=r.nextInt(100);
         int r9;
         c5++;
         l3++;
         System.out.println("------------");
         while(true)
       {
           System.out.println(" multiplication of"+ r7+"and"+r8+" is?");
           r9=s.nextInt();
           c3++;
           if((r7*r8)==r9)
           {
             int c=r.nextInt(4);
             t.positive(c);
             break;  
           }
           else
          {
            int c=r.nextInt(4);
            t.negative(c);
           }

       }
     if(c3==1)
         p3++;
         c3=0;
     break;
case 4:  int a1=r.nextInt(100);
         int a2=r.nextInt(100);
         int a3;
          c5++;
          l4++;
          System.out.println("------------");
         while(true)
       {
          if(a2!=0)
          {
           System.out.println(" multiplication of"+ a1+"and"+a2+" is?");
           a3=s.nextInt();
           c4++;
           if((a1/a2)==a3)
           {
             int c=r.nextInt(4);
             t.positive(c);
             break;  
           }
           else
          {
            int c=r.nextInt(4);
            t.negative(c);
           }
         }
         else
         {
          System.out.println("the number cannot divisible by 0");
         }

       }
     if(c4==1)
         p4++;
         c4=0;
     break;
case 5:
{
System.out.println("***************************");
System.out.println(" your performane in addition "+(p1*100/l1)+"%");
System.out.println(" your performane in subtraction "+(p2*100/l2)+"%");
System.out.println(" your performane in multiplication "+(p3*100/l3)+"%");
System.out.println(" your performane in division "+(p4*100/l4)+"%");
int x=(p1+p2+p3+p4)*100/c5;
System.out.println("***************************");
System.out.println("your performance is"+ x +" %") ;
}
       break;
case 6:System.exit(0);
       break;
}
}

}

}