import java.lang.*;
import java.util.*;
class Sine
{      float pow(float x,int i)
       {
               float p=1;
               while(i>=0)
               {
                      p=p*x;
                      i--;
               }
             return p;
       }
       void inverse()
       {
     float x,sum,p=1,t;
     System.out.println("enter the value of x:");
    Scanner s=new Scanner(System.in);
    x=s.nextFloat();
    int i;
    sum=x;
    for(i=2;i<=300;i=i+2)
    {
     p=p*(float)(i-1)/i;
     t=pow(x,i+1)/(i+1);
     sum+=p*t;
    }
    System.out.println(" degrees is:"+(sum*57.296));
       }
}
class SineInverse1
{
      public static void main(String a[])
     {
            Sine s=new Sine();
           s.inverse();
     }
}