import java.lang.*;
import java.util.*;
class Combinations
{
    static int fact(int n)
{
    if(n==1)
       return 1;
    else
       return n*fact(n-1);
}
void combination()
{
Scanner s=new Scanner(System.in);
int val1,val2,digit,i,j,k,num;
System.out.println("enter initial and ending value");
val1=s.nextInt();
val2=s.nextInt();
System.out.println("enter length of digit");
digit=s.nextInt();
num=fact(val2)/(fact(val2-digit)*fact(digit));
System.out.println("the number of combinations "+num);
System.out.println("the combonitions are");
for(i=val1;i<val2;i++)
{
for(j=i+1;j<=val2;j++)
{
   for(k=j+1;k<=val2;k++)
{
   System.out.println(i+" "+j+" "+k);
}
}

}

}
}
class Combo
{
    public static void main(String args[])
{
   Combinations t=new Combinations();
   t.combination();

}

}