import java.lang.*;
import java.util.*;
class Logx1
{
   void log()
{
   Scanner s=new Scanner(System.in);
   System.out.println("enter x value in degrees ");
   double x=s.nextDouble();
   System.out.println("enter n value");
   int n=s.nextInt();
   double r=x-1;
   System.out.println(r);
   double sum=r;
  int i,sign=-1;
   for(i=2;i<=n;i++)
{
     sum=sum+sign*(Math.pow(r,i)/i);
     sign=sign*-1;
     System.out.println(sum);
}
System.out.println("log("+x+")="+sum);
   
}

}
class Logx
{
public static void main(String args[])
{
     Logx1 p=new Logx1();
    p.log();
}

}