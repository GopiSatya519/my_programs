import java.lang.*;
class Sinx1{ 
   void cal_sin(float n)  
   {      
    float accuracy = (float) 0.0001, denominator, sinx, sinval;  
      
    n = n * (float)(3.142 / 180.0);  
  
    float x1 = n;   
    sinx = n;          
    sinval = (float)sin(n);      
    int i = 1;  
    do
    {  
        denominator = 2 * i * (2 * i + 1);  
        x1 = -x1 * n * n / denominator;  
        sinx = sinx + x1;  
        i = i + 1; 
        System.out.println("denominator="+deneminator);
         System.out.println("x1="+x1);
         System.out.println("sinx="+sinx);
         System.out.println("sinval - sinx="+(sinval-sinx));
    } while (accuracy <= sinval - sinx);  
       System.out.println(sinx);  
} 
}
class Sinx 
{

  public static void main(String args[])
{
    Sinx1 t=new Sinx();
float n=90;
    t.cal_sin(n);

}
}