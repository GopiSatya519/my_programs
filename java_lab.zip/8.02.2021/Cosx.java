import java.lang.*;
import java.util.*;
class Cos
{
   void cosx()
{
   Scanner s=new Scanner(System.in);
   System.out.println("enter x value in degrees ");
   double x=s.nextDouble();
   System.out.println("enter n value");
   int n=s.nextInt();
   double r= x*(3.14/180.0);
   double sum=1;
  int fact=1,i,sign=-1;
   for(i=2;i<=n;i=i+2)
{
     fact=fact*i*(i-1);
     sum=sum+sign*(Math.pow(r,i)/fact);
      sign=sign*-1;
     System.out.println(sum);
}
System.out.println("cos("+x+")="+sum);
   
}

}
class Cosx
{
public static void main(String args[])
{
     Cos p=new Cos();
    p.cosx();
}

}