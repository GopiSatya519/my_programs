import java.lang.*;
import java.util.*;
class Tan
{
   double powerofnum(double m,int n)
   {
    double t=1;
    while(n!=0)
    {
     t=t*m;
    n--;
   }
  return t; 
  }
  int fact(int z)
{
  int f=1;
  while(z>0)
  {
   f=f*z;
   z--;
  }
  return f;
}
  void expansion(int n,double x)
  {
    int i;
if(x<=-1)
  {
         double sum=(-3.14/2),s=-1;
         for(i=1;i<=n;i=i+2)
         {
                sum+=(s)*(1/(i*powerofnum(x,i)));
                s=s*-1;
         }
System.out.println("result="+(sum*57.296));
  }
else if(x<1)
  {
    double sum=x,s=-1;
   for(i=3;i<=n;i=i+2)
   {
      sum+=s*(powerofnum(x,i)/i);
     s=s*-1;
   }
System.out.println("result="+(sum*57.296));
  }
 else if(x>=1)
  {
         double sum=(3.14/2),s=-1;
         for(i=1;i<=n;i=i+2)
         {
                sum+=(s)*(1/(i*powerofnum(x,i)));
                s=s*-1;
         }
System.out.println("result="+(sum*57.296));
  }
}
};
class TanFunctionX
{
  public static void main(String k[])
  {
     int n=300;
    double x; 
    System.out.println("enter value of x");
    Scanner sc=new Scanner(System.in);
    x=sc.nextDouble();
    Tan o=new Tan();
    o.expansion(n,x);
    }
}