import java.util.*;
class WordRank 
{
   static int factorial(int n) 
 {
  return (n<=2)?n:n*factorial(n-1);
 }
 static int calRank(String str,int n) 
{
  int rank=1;
  for (int i=0;i<n;i++) 
  {
    int c=0;
     for (int j=i+1;j<=n;j++) 
      {
        if(str.charAt(i)>str.charAt(j))
        c++;
       }
      rank+=c*factorial(n-i);
  }
  return rank;
 }
 public static void main(String[] args) 
{
  Scanner sd=new Scanner(System.in);
  System.out.println("Enter the string");
  String str=sd.nextLine();
  int n=str.length();
  System.out.print("The rank of the given string is: " +calRank(str,n-1));
 }
}