import java.lang.*;
import java.util.*;
class Log
{
   double pow(double m,int n)
   {
    double t=1;
    while(n!=0)
    {
     t=t*m;
    n--;
   }
  return t; 
  }
  int fact(int z)
{
  int f=1;
  while(z>0)
  {
   f=f*z;
   z--;
  }
  return f;
}
  void logarithm(int n,double x)
  {
    int i;
   double sum=0,s=-1;
   if(x>0)
   {
       sum=(x-1)/(x+1);
       for(i=3;i<=n;i=i+2)
   {
      sum+=(1/i)*(pow(((x-1)/(x+1)),i));
   }
  System.out.println("res="+(2*sum));     
   }
  else if(x>1/2)
   {
       for(i=1;i<=n;i=i+2)
   {
      sum+=(1/i)*(pow(((x-1)/(x)),i));
   }
  System.out.println("res="+(sum));     
   }
  else
{
   for(i=2;i<=n;i++)
   {
      sum+=s*(pow((x-1),i)/i);
     s=s*-1;
   }
  System.out.println("res="+(sum));
  }
}
}
class Logarithm
{
  public static void main(String k[]) 
  {
     int n=10;
    double x; 
    System.out.println("enter value of x");
    Scanner sc=new Scanner(System.in);
    x=sc.nextDouble();
    Log o=new Log();
    o.logarithm(n,x);
    }
}