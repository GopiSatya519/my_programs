import java.util.*;
import java.lang.*;
class TanInverse
{
    double pow(double x,int i)
       {
               double p=1;
               while(i>=0)
               {
                      p=p*x;
                      i--;
               }
             return p;
       }
    void taninverse()
  {
    Scanner s=new Scanner(System.in);
    System.out.println("enter a value to get tan inverse when |x|<1 ");
    double x=s.nextDouble();
    int i;
   if(x>=1)
   {
    double sum,sign=-1;
    sum= 3.141/2;
    for(i=1;i<=300;i=i+2)
   {
      sum=sum+(sign)*1/(i*pow(x,i));
      sign=sign*-1;
  }
    System.out.println("degrees "+(sum*57.296));
}
  else if(x<1)
    {
         double sum=(3.14/2),sign=-1;
         for(i=1;i<=300;i=i+2)
         {
                sum+=(sign)*(1/(i*pow(x,i)));
                sign=sign*-1;
         }
System.out.println("result="+(sum*57.296));

}
else if(x<=-1)
  {

         double sum=(-3.14/2),sign=-1;
         for(i=1;i<=300;i=i+2)
         {
                sum+=(sign)*(1/(i*pow(x,i)));
                sign=sign*-1;
         }
System.out.println("result="+(sum*57.296));
  }
}

}
class  TanInverseX
{
    public static void main(String args[])
{
     TanInverse p= new TanInverse();
     p.taninverse();
}
}