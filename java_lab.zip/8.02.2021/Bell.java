import java.lang.*;
import java.util.Scanner;
class BellTriangle
{
  void bellTriangle()
{
   int i,j,n;
   System.out.println("enter number of elements");
   Scanner sc=new Scanner(System.in);
   n=sc.nextInt();
   System.out.println("bell triangle is");
   int a[][]=new int[n][n];
   a[0][0]=1;
   System.out.println(a[0][0]);
   for(i=1;i<n;i++)
   {
     for(j=0;j<=i;j++)
     {
       if(j==0)
       {
       a[i][j]=a[i-1][i-1];
       System.out.print(a[i][j]+"\t");
       }
       else
       {
        a[i][j]=a[i][j-1]+a[i-1][j-1];
        System.out.print(a[i][j]+"\t");
       }
     }
     System.out.print("\n");
   }
  System.out.print("number of equivalence realtions from a"+n+"element set is"+(a[n-1][n-1]));
}
}
class Bell
{
  public static void main(String k[])
  {
   BellTriangle m=new BellTriangle();
   m.bellTriangle();
  }
}