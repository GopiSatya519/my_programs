import java.lang.*;
import java.util.*;
class BaseClass{
     int x;
     void fun()
{
  System.out.println("base class function is called");
}

}
//single inheritance
class SingleInheritance extends BaseClass{
    void single(){
    System.out.println("SingleInheritance class function is called");
    System.out.println("Base class x value:"+x);
    fun();
}
}
//multiLevel inheritance
class MultipleInheritance extends SingleInheritance{
     void multiLevel(){
     single();
     System.out.println("MultipleInheritance class is called");
    } 
}
//heirarical inheritance
class derivedcls2 extends BaseClass {
     void derived2()
{
   System.out.println("DerivedClass2 function is called");
    System.out.println("Base class x value:"+x);
    fun(); 
}
class derivedcls3 extends BaseClass{
     void derived3()
{
   System.out.println("DerivedClass3 function is called");
    System.out.println("Base class x value:"+x);
    fun(); 
}
//hybrid inheritance
class hybrid1 extends SingleInheritance{
     void hyb1(){
     System.out.println("hybrid Inheritance 1");
     single();
}
}
class hybrid2 extends SingleInheritance{
void hyb2(){
     System.out.println("hybrid Inheritance 2");
     single();
}
}
class Lab4A{
  
    public static void main(String args[])
{
    SingleInheritance si=new SingleInheritance();
     MultipleInheritance mi=new MultipleInheritance();
     derivedcls3 d3=new derivedcls3();
     hybrid1 h1=new hybrid1();
     hybrid2 h2=new hybrid2();
     si.single();
     mi.multiLevel();
     d3.derived3();
     h1.hyb1();
     h2.hyb2();
}
}}
}

