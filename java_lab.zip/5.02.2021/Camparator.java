import java.lang.*;
import java.util.*;
class Comparator4
{

  void comparator()
 {
   Scanner s=new Scanner(System.in);
   System.out.println("enter a value");
   int a=s.nextInt();
   System.out.println("enter b value");
   int b=s.nextInt();
   int d[]=new int[4];
    int e[]=new int[4];
    int p,pp;
    int i=3,temp=a,temp2=b;
   if((a>=0 &&a<=15) && (b>=0&&b<=15))
  {
    while(temp!=0 && temp2!=0)
    {
     p=temp%2;
     pp=temp2%2;
     d[i]=p;
     e[i]=pp;
     i--;
     temp=temp/2;
     temp2=temp2/2;
   }
   int k=0,f=0;
   while(k>4)
{
    if(d[k]==e[k])
{
   k++;  
}
else if(d[k]>e[k])
{
    f=1;
   break;
}
else
{
   f=2;
   k++;
}
}
if(f==2)
 System.out.println(b+" is bigger ");
else
 System.out.println(a+" is bigger ");
}
else
{
  System.out.println("out of range");
}

}
}
class Camparator
{
  public static void main(String args[])
 {
   Comparator4 t=new Comparator4();
   t.comparator();
 }
}