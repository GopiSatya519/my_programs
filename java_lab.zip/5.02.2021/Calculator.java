import java.lang.*;
import java.util.*;
class Calc
{
       void assign()
       {
              Scanner s=new Scanner(System.in);
              System.out.println("enter first operand:");
              int op1=s.nextInt(),op2=0;
              System.out.println(!(Character.isDigit(op1)));
              if((Character.isDigit(op1))!=true)
             {
                while(true)
              {
             System.out.println("1.addition 2.subtraction 3.multiplication 4.division 5.modulus 6.calculate 7.exit");
             System.out.println("enter operaor:");
             int op=s.nextInt();
            if(op<=5)
            {
              System.out.println("enter second operand:");
             op2=s.nextInt();
             if((Character.isDigit(op2))!=false)
              System.exit(0);
             }
            switch(op)
            {
                    case 1:op1=op1+op2;
                     break;
                   case 2:op1=op1-op2;
                     break;
                   case 3:op1=op1*op2;
                     break;
                  case 4:
                 if(op2==0)
                   System.out.println("can't divide by zero");
                  else
                   op1=op1/op2;
                 break;
                 case 5:op1=op1%op2;
                 break;
                 case 6:System.out.println("operation is:"+op1);
                 break;
                 case 7:System.exit(1);
                 default:System.out.println("wrong choice");
            }
  }
}
else
System.exit(0);
}
}
class Calculator
{
     public static void main(String s[])
     {
           Calc c=new Calc();
          c.assign();
     }
}