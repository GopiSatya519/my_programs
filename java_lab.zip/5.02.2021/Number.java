import java.lang.*;
import java.util.*;
class Number1
{
Scanner s=new Scanner(System.in);
    void fib()
  {
   int a,b,c;
   System.out.println("enter initial value");
   a=s.nextInt();
   System.out.println("enter second initial value");
   b=s.nextInt();
   System.out.println("Enter n value");
   int n=s.nextInt();
   System.out.print(a+"  "+b+" ");
   for(int i=b+1;i<n;i++)
   {
     c=a+b;
     System.out.print(c+"  ");
     a=b;
     b=c;
  }
    
}
 void factorial()
{
  System.out.println("enter a value to get factorial ");
   int n=s.nextInt();
    int res=1;
    for(int i=1;i<=n;i++)
{
    res*=i;
}
    System.out.println(res);
}
  void armstrong()
{
   System.out.println("enter a num to check whether it is armstrong or not ");
   int a=s.nextInt();
    int temp=a,res=0,rem;
    while(temp!=0)
{
     rem=temp%10;
     res+=rem*rem*rem;
     temp=temp/10;
}
     if(a==res)
{
     System.out.println("Given number is Armstrong.");
}
else
{
     System.out.println("Given number is not a Armstrong.");
}
}
void palindrome()
{
   System.out.println("enter a number to check whether it is palindrome or not ");
   int n=s.nextInt();
   int res=0,rem,temp=n;
   while(n!=0)
{
   rem=n%10;
   res=res*10+rem;
   n/=10;
}
if(res==temp)   
{
   System.out.println("Given number is palindrome.");
}
else
{
   System.out.println("Given number is not a palindrome.");
}
}

void prime()
{
   System.out.println("enter a value to check whether it is prime or not");
   int n=s.nextInt();
   int c=0;
   for(int i=2;i<n;i++)
{
    if(n%i==0)
      c++;
} 
if(c==0)
  System.out.println("prime number");
else
  System.out.println("not a prime number");
} 
}
class Number
{
public static void main(String args[])
{
   
   Number1 a=new Number1();
   a.fib();
   a.factorial();
   a.palindrome();
   a.armstrong();
   a.prime();

}
}