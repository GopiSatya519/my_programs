import java.lang.*;
import java.util.*;
class Letter
{
  void print(int n)
{
    for(int i=0;i<n;i++)
{
    for(int j=0;j<n;j++)
{
   
   if(i==0 || i==n-1)
    System.out.print(" * ");
   else if(i>0 &&i<(n/2) && j==0)
      System.out.print(" * ");
   else if(i==(n/2))
        System.out.print(" * ");
   else if((i>(n/2)&&i<n)&& j==n-1)
       { for(int k=0;k<n-1;k++)
         System.out.print("   ");
        System.out.print(" * ");
      }
}
System.out.println("\n");
}
}
}
class Name
{
public static void main(String arg[])
{
Scanner s=new Scanner(System.in);
System.out.println("\nEnter n val:");
int n=s.nextInt();
Letter p=new Letter();
p.print(n);

}
}