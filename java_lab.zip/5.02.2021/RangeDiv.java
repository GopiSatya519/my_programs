import java.lang.*;
import java.util.*;
class Array
{
    void range()
{
   Scanner s= new Scanner(System.in);
   System.out.println("enter initial val");
   int p=s.nextInt();
    System.out.println("enter n val");
    int n=s.nextInt();
     System.out.println("enter divisor num");
    int t=s.nextInt();
   int k=0;
   int [] a=new int [20];
   for(int i=p;i<=n;i++)
  {
    if(i%t==0)
    {
      a[k]=i;
      k++;
    }
  }
 System.out.println("elements which is divisible by "+t+" in range from "+p+" to "+n);
    for(int j=0;j<k;j++ )
       System.out.print(a[j]+"  ");
}
}

class RangeDiv
{
   public static void main(String args[])
{
    Array b=new Array();
    b.range();
}
}