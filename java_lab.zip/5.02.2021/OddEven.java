import java.lang.*;
import java.util.*;
class EvenOddPnt
{    Scanner s=new Scanner(System.in);
   void evenOdd()
{

    System.out.println("enter num of elements");
    int n=s.nextInt();
    int a[]=new int[n];
    System.out.println("enter elements");
    for(int i=0;i<n;i++)
      a[i]=s.nextInt();
    for(int i=0;i<n;i++)
     { if(a[i]%2!=0)
         System.out.print(a[i]+"  ");}
    for(int i=0;i<n;i++)
     { if(a[i]%2==0)
         System.out.print(a[i]+"  ");}
    
}

}
class OddEven
{
public static void main(String args[])
{
  EvenOddPnt t = new EvenOddPnt();
  t.evenOdd();
} 
}