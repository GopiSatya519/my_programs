import java.lang.*;
import java.util.*;
class Array{
   float marks[]=new float[6];
   float sum=0.0f;
   float percentage;
Scanner s=new Scanner(System.in);

   void input()
{
    System.out.println("Eneter your 6 subject marks");
    for(int i=0;i<6;i++)
   {
    marks[i]=s.nextFloat();
    if(marks[i]<=100 || marks[i]>=0){
    sum+=marks[i];
    }
    else{
    System.out.println("plaese enter marks in between 0 to 100 only");
}
   }
     
}
void display()
{
    System.out.println("Total marks:"+sum);
    System.out.println("Total percentage:"+(sum/600)*100);
}
}
class Lab2B{
   public static void main(String args[])
   {
      Array ob=new Array();
      ob.input();
      ob.display();
}

}
