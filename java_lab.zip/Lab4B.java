import java.lang.*;
import java.util.*;
class Base{
  
    void print()
{
   System.out.println("Base class print function is called");
}
}
class Derived1 extends Base{
     void print()
{
   System.out.println("Derived1 class print function is called");
}
}
class Derived2 extends Base{
  void print()
{
   System.out.println("Derived2 class print function is called");
}
}

class Lab4B{
    public static void main(String args[])
{
     Base b;
     b=new Derived1();
     b.print();
     b=new Derived2();
     b.print();
}
}