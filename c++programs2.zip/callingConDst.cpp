#include<iostream>
using namespace std;
class satya
{
   public:
   satya()
   {
       cout<<"\nsatya constructor";
   }
   ~satya()
   {
       cout<<"\nsatya destructor";
   }
};
int main()
{
    satya s;
    satya();
    s.satya::~satya();

}
