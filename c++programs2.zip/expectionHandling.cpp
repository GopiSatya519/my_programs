#include<iostream>
using namespace std;
int main()
{
   int x,y,j;
   cout<<"\nenter the values of x and y:";
   cin>>x>>y;
   j=(x>y)?0:1;
   try
   {
      if(j==0)
      {
         cout<<"\nsubtraction of x and y:"<<x-y;
      }
      else
      {
         throw(j);
      }
   }
   catch(int k)
   {
      cout<<"\nexception caught";
      cout<<"\nplease enter x value greater than y";
   }
}
