#include<iostream>
using namespace std;
class s
{
   public:
   void show()
   {
      cout<<"\nshow()";
   }
};
int main()
{
s a[10];
for(int i=0;i<10;i++)
  a[i].show();
}
