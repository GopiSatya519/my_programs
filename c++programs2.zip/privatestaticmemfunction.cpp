#include<iostream>
using namespace std;
class s
{
   static int a;
   static void show1()
   {
     ++a;
      cout<<"a="<<a;
   }
   public:
   static void show()
   {
      show1();
   }

};
int s :: a=1;
int main()
{
    s b;
    b.show();
    s::show();
}
