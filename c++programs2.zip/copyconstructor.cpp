#include<iostream>
using namespace std;
class num
{
  int n;
  public:
  num(){}
  num(int k)
  {
     n=k;
  }
  num(num &j)
  {
     n=j.n;
  }
  void show()
  {
     cout<<"\n n="<<n;
  }
};
int main()
{
  num s(50);
  num t=s;
  num k(t);
  num p;
  p=k;
  s.show();
  t.show();
  k.show();
  p.show();
}
