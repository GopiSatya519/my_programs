#include<iostream>
using namespace std;
int main()
{
   int *a=new int(25);
   cout<<"*a="<<*a<<endl;
   cout<<"value of a in address "<<a<<endl;
   delete a;
   cout<<*a<<endl;
   cout<<a;


}
