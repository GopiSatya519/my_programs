#include<iostream>
using namespace std;
enum week{sunday,monday,tuesday,wednesday,thursday=6,friday,saturday};
int main()
{
  week day;
  day=thursday;
  cout<<"day num:"<<day+1;
}
