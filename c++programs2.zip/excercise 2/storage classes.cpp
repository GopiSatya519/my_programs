#include<iostream>
using namespace std;
int static a=5;
void autostorage()
{
   auto int a=10;
   auto float b=20.5;
   auto char c='a';
   auto char d[20]="satyaisbadgirl";
   cout<<a<<endl;
   cout<<b<<endl;
   cout<<c<<endl;
   cout<<d<<endl;
}
void static_class()
{
    for(int i=a;i>0;i--)
        cout<<i<<endl;
    a=30;
}
void externstorage()
{
    extern int a;
    cout<<"extern variable value is"<<a<<endl;
    a=100;
    cout<<"after changing tha 'a' value:"<<a<<endl;
}
int main()
{
  autostorage();
  static_class();
  cout<<a<<endl;
  externstorage();
  cout<<a<<endl;
}
