#include<iostream>
using namespace std;
int call_value(int a)
{
    a=20;
}
int call_address(int &a)
{
    a=30;
}
int call_reference(int *a)
{
    *a=40;
}

int main()
{
    int a=20;
    call_value(a);
    cout<<"\ncall by value of a="<<a;
    call_address(a);
    cout<<"\ncall by address value of a="<<a;
    call_reference(&a);
    cout<<"\ncall by reference value of a="<<a;

}
