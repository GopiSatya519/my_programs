#include<iostream>
using namespace std;
class satya
{
   static int a;
    public:
     void show()
    {
   ++a;
   cout<<"a="<<a;

    }
};
int satya :: a=0;


int main()
{
   satya s,s1,s2;
   s.show();
   s1.show();
   s2.show();
}
