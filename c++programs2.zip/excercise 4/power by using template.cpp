#include<iostream>
#include<cmath>
using namespace std;
template<typename T>
T pow1(T a,T b)
{
    return(pow(a,b));
}
int main()
{    int base;
     int deg;
     cout<<"enter the base and degree value:";
     cin>>base>>deg;
     //res=pow1(base,degree);
     //res1=pow1<float>(2.5,2);
     //cout<<"\n power="<<res1;
     cout<<"\n power="<<pow1(base,deg);
}
