#include<iostream>
using namespace std;
template <class T>
T swap(T *a,T *b)
{
   T temp;
   temp=*a;
   *a=*b;
   *b=temp;

}
int main()
{  int a;
   int b;
   cout<<"enter any two values";
   cin>>a>>b;
   swap(&a,&b);
    cout<<"a= "<<a<<" b= "<<b;

}
