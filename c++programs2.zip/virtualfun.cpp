#include<iostream>
using namespace std;
class x
{
   public:
      void show()
     {
        cout<<"\n in class x";
     }
};
class y: public x
{
   public:
   void show()
   {
     cout<<"\n in class y";
   }
};
int main()
{
   x a,*p;
   p=&a;
   p->show();
   y b;
   p=&b;
   p->show();
}
