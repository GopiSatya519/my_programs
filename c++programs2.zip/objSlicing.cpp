#include<iostream>
using namespace std;
class A
{
   public:
       int x;
   A(int k)
   {
      x=k;
   }
   virtual void show()
   {
     cout<<"\n x="<<x;
   }
};
class B : public A
{
   int y;
   public:
   B(int l,int m):A(l)
   {
      y=m;

   }
   void show()
   {
      cout<<"\nx,y="<<x<<" "<<y;
   }
};
int main()
{
   A a(10),*p;
   B b(4,5);
   A &c=b;
   c.show();
   b.show();
}
