#include<iostream>
using namepsace std;
class distance
{
    public:
    int feet,inches,dis;
    void input();
    void output();
    void add(distance a,distance b);
};
void distance::input()
{
    cout<<"enter a feet and inches:";
    cin>>feet>>inches;
}
void distance::add(distance a,distance b)
{
   dis_f=a.feet+b.feet;
   dis_i=a.inches+b.inches;

}
void distance::output()
{
    cout<<"distance of feet="<<dis_1;
    cout<<"distance of inches="<<dis_i;
}
int main()
{
   distance a,b;
   a.input();
   b.input();

}
