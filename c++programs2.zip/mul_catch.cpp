#include<iostream>
using namespace std;
void num(int m)
{
    try
    {
       if(m==0)
       {
          throw m;
       }
       else if(m>0)
       {
          throw 'a';
       }
       else
       {
          throw .0;
       }
    }
    catch(char i)
    {
       cout<<"\ncaught positive value";
    }
    catch(float k)
    {
       cout<<"\ncaught negative value";
    }
    catch(int p)
    {
       cout<<"\ncaught null value";
    }
}
int main()
{
  num(0);
  num(1);
  num(-1);
}
