#include<iostream>
using namespace std;
class num
{
   private:
   int a,b;
   protected:
   int c,d;
   public:
   int e,f;
   num(int a,int b,int c,int d,int e,int f)
   {
    (*this).a=a;
    (*this).b=b;
    (*this).c=c;
    (*this).d=d;
     this->e=e;
     this->f=f;
   }
   void show()
   {
      cout<<"a="<<a<<" b="<<b<<" c="<<c<<" d="<<d<<" e="<<e<<" f="<<f;

   }
};
int main()
{
  num a(1,2,3,4,5,6);
  a.show();
}
