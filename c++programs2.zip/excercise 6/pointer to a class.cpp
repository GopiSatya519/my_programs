#include<iostream>
using namespace std;
class num
{
  private:
  int a;
  protected:
  int b;
  public:
  int c;
  void input();
  void show();
  };
void num::input()
  {
      cout<<"enter the values of a,b and c:";
      cin>>a>>b>>c;

}
void num::show()
{cout<<"a="<<a<<" b="<<b<<" c="<<c;
}

int main()
{
   num *a=new num;
   a->input();
   a->show();
}
