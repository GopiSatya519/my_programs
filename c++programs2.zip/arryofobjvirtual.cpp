#include<iostream>
using namespace std;
class A
{
   public:
     virtual void show()
     {
        cout<<"\nin A";
     }
};
class B:public A
{
   public:
     void show()
     {
     cout<<"\nin B";
     }
};
class C:public A
{
   public:
     void show()
     {
     cout<<"\nin C";
     }
};
class D:public A
{
   public:
     void show()
     {
     cout<<"\nin D";
     }
};
int main()
{
   A a;
   B b;
   C c;
   D d;
   A *p[]={&a,&b,&c,&d};
   for(int i=0;i<4;i++)
     p[i]->show();
}
