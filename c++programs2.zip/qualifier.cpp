#include<iostream>
using namespace std;
class p
{
    public:
       int x;
      class q
      {
         public:
         void show(int k)
         {
             p c;
            c.x=k;
            cout<<"\nx="<<c.x;
         }
      };
};
int main()
{
    p::q a;
    a.show(10);
}
