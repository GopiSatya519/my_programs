#include<iostream>
using namespace std;
class s
{
    public:
      void sum(int *a,int *b)
      {
         *a=10;
         *b=20;
         cout<<" \n a="<<(unsigned)a<<"  b="<<(unsigned)b;
      }
};
int main()
{
    int a=20,b=10;
     s t1;
     cout<<"a="<<a<<"b="<<b<<"\n";
     cout<<"\na="<<(unsigned)&a<<"  b="<<(unsigned)&b;
     t1.sum(&a,&b);
     cout<<"\n  a="<<a<<" b="<<b<<"\n";
}
