#include<iostream>
using namespace std;
int main()
{
    int input();
    void display(int=input());
    display(20);
    display();
}
int input()
{
   return 10;
}
void display(int k)
{
   cout<<"\nk="<<k;
}
