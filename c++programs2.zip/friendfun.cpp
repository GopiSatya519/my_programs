#include<iostream>
using namespace std;
class f
{
   char name[15];
   int act;
   int bal;
   public:
     void get()
     {
    cout<<"\nenter namd,act,bal:";
       cin>>name;
       cin>>act;
       cin>>bal;
     }
     friend void show(f);
};
void show(f s)
{
   cout<<"\nname:"<<s.name;
   cout<<"\nact:"<<s.act;
   cout<<"\nbal:"<<s.bal;
}
int main()
{
   f p;
   p.get();
   show(p);
}
