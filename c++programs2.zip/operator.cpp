#include<iostream>
using namespace std;
class opt
{
  int x,y;
   public:
   opt(int k)
   {
      x=k;
   }
    opt operator +(opt p)
    {
       y=x+p.x;
    }
    void show()
    {
       cout<<"\y="<<y;
    }
    void operator ++()
    {
        ++x;
        cout<<"\nx="<<x;
    }
};
int main()
{
   opt t(10);
   opt v(20);
   opt l=t+v;
   l.show();
   ++t;

}
