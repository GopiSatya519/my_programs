#include<iostream>
using namespace std;
class s
{
   int mfy;
   int epy;
   int y;
   public:
   void values()
   {
      mfy=2020;
      epy=2024;
   }
   void difference(s);
   void difference1(s *p)
   {
       y=p->epy-p->mfy;
       cout<<"\ndifference1="<<y;
   }

};
void s:: difference(s y1)
{
   y=y1.epy-y1.mfy;
   cout<<"difference="<<y;
}
int main()
{
  s a;
  a.values();
  a.difference(a);
  s b;
  b.values();
  b.difference1(&b);
}
