#include<iostream>
using namespace std;
int intrest(int p,int r,int t=2)
{
   int intrest=(p*t*r)/100;
   return intrest;
}
int main()
{
int p,t,s_i;
cout<<"enter the principle and rate: ";
cin>>p>>t;
s_i=intrest(p,t);
cout<<"\n SIMPLE INTREST: "<<s_i;

}
