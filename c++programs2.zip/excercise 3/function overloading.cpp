#include<iostream>
using namespace std;
int sum1(int a,int b)
{
    return a+b;
}
int sum1(int a,float c)
{
    return a+c;
}
int main()
{  int a,b,sum;
   float c,sumf;
   cout<<"enter any two numbers and float value:";
   cin>>a>>b>>c;
   sum=sum1(a,b);
   sumf=sum1(a,c);
   cout<<"sum of two integers :"<<sum<<endl;
   cout<<"sum of int and float :"<<sumf<<endl;
}
