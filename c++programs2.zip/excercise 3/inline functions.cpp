#include<iostream>
using namespace std;
inline void sum(int a, int b)
{
    cout<<"sum by using inline function="<<a+b;
}

int main()
{
  int a=10,b=20;
  sum(a,b);
}

