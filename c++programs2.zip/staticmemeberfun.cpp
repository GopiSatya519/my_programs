#include<iostream>
using namespace std;
class s
{
   static int a;
   public:
   static void show()
   {
      ++a;
      cout<<"a="<<a;
   }

};
int s :: a=1;
int main()
{
    s b;
    b.show();
    s::show();
}
