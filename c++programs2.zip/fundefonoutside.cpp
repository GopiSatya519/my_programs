#include<iostream>
using namespace std;
class satya
{
   public:
    void show();
};
void satya :: show()
{
   cout<<"show()";
}
int main()
{
   satya s;
   s.show();
}
