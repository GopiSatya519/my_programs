#include<iostream>
using namespace std;
class s
{
    public:
      void sum(int &a,int &b)
      {
         a=10;
         b=20;
      }
};
inline int cube(int a)
{
    return a*a*a;
}
int main()
{
    int a=20,b=10,c;
     s t1;
     cout<<"a="<<a<<"b="<<b<<"\n";
     t1.sum(a,b);
     cout<<"a="<<a<<"b="<<b<<"\n";
     c=cube(a);
     cout<<"\nc="<<cube(a);
}
