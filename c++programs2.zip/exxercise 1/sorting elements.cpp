#include<iostream>
using namespace std;
int main()
{
   int a[20],n,i,temp,j,min1;
   cout<<"enter number of elements entered";
   cin>>n;
   cout<<"\n enter the elements:";
   for(i=0;i<n;i++)
   {
      cin>>a[i];
   }
   for(i=0;i<n;i++)
   {
      min1=i;
      j=i+1;
      while(a[j]<a[min1])
      {
         min1=j;
         j++;
      }
      temp=a[i];
      a[i]=a[min1];
      a[min1]=temp;

   }
   cout<<"\nsorted elemets are: ";
   for(i=0;i<n;i++)
   {
      cout<<a[i]<<" ";
   }

}
