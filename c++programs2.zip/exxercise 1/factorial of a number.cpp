#include<iostream>
using namespace std;
int fact(int s)
{
    if(s==1)
    {
       return 1;
    }
    else
    {
       return s*fact(s-1);
    }
}
int main()
{
    int n,a;
    cout<<"enter a number to get factorial:";
    cin>>n;
    a=fact(n);
    cout<<"\nfactorial of a number "<<n<<" is "<<a;
}
