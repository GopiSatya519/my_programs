#include<iostream>
#include<math.h>
using namespace std;
int main()
{
   int a,b,c;
   cout<<"enter a,b&c values to find the roots"<<endl;
   cin>>a>>b>>c;
   if((b*b-4*a*c)>0)
   {
       cout<<"roots are:";
       cout<<b+sqrt(b*b-4*a*c)/(2*a)<<endl;
       cout<<b-sqrt(b*b-4*a*c)/(2*a)<<endl;
   }
   else
   {
   cout<<"imaginary roots";
   }
}
