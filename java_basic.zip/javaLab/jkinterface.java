interface Vehicle
{
void seatcapacity();
void ac();// public abstract
}
class lorry implements Vehicle
{
public void seatcapacity()
{
System.out.println(" seat capacity is 3");
}
public void ac()
{
System.out.println(" Ac not required to lorry");
}
};
abstract class bus implements Vehicle
{
public void seatcapacity()
{
System.out.println(" seat capacity is 46");
}
public abstract void ac();
};
class nonac extends bus
{
public void ac()
{
System.out.println(" Ac not required to Non ac buses");
}
};
class acbus extends bus
{
public void ac()
{
System.out.println(" Ac required to ac buses");
}
};
class jkinterface
{
public static void main(String args[])
{
//lorry l=new lorry();
Vehicle l=new lorry();
l.seatcapacity();
l.ac();
bus n=new nonac();
n.seatcapacity();
n.ac();
bus a=new acbus();
a.seatcapacity();
a.ac();
}
};