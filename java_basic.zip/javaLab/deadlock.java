class cse
{
public synchronized void cfirst(ece e)
{
System.out.println("thread starts execution of cse first()");
try{
Thread.sleep(2000);
}
catch(Exception l)
{
}
System.out.println("thread trying to call ece last()");
try{
Thread.sleep(2000);
}
catch(Exception l)
{
}
e.last();//ece
}
public synchronized void last()
{
System.out.println("last method of cse class");
}
}
class ece
{
public synchronized void efirst(cse c)
{
System.out.println("thread starts execution of ece first()");
try{
Thread.sleep(2000);
}
catch(Exception k)
{
}
System.out.println("thread trying to call cse last()");
c.last();
}
public synchronized void last()
{
System.out.println("last method of ece class");
}
};
class Lab9B extends Thread
{
cse c=new cse();
ece e=new ece();
public void jk()
{
this.start();
c.cfirst(e);
}
public void run()
{
e.efirst(c);
}
public static void main(String args[])
{
Lab9B d=new Lab9B();
d.jk();
}
};