import java.io.*;
public class BFile
{
public static void main(String args[]) throws Exception
{
FileReader fr=new FileReader("Add.java");
BufferedReader br=new BufferedReader(fr);//passing writer object
int i=0;
while((i=br.read())!=-1)
{
System.out.print((char)i);
System.out.print("---");
}
String line=br.readLine();
while(line!=null)
{

System.out.print(line);
System.out.print("---");
line=br.readLine();
}
br.close();
fr.close();
FileWriter fw=new FileWriter("Add.java");
BufferedWriter bw=new BufferedWriter(fw);
bw.write(100);
bw.newLine();
bw.write('d');
bw.newLine();
//bw.write(10.5);
//bw.write("\n");
bw.newLine();
bw.write("cse welcomes you");
bw.newLine();
bw.write("cse measns computer....");
char[] ch={'r','g','u','k','t'};
bw.write(ch);
bw.flush();
//FileWriter fw=new FileWriter("Add.java",true);//Append
FileWriter fw2=new FileWriter("Add.java");
PrintWriter pw=new PrintWriter(fw2);
pw.println("mec");
pw.flush();
System.out.print("successfully completed");
}
}