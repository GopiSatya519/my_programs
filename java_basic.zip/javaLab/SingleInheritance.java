import java.lang.*;
class c1
{
     int a=12,b=45;
     void d()
     {
          System.out.println("method of base class");
     }
};
class c2 extends c1
{
            int c=99;
           void d2()
          {
               System.out.println("method of derived class");
         }
};
class SingleInheritance
{
    public static void main(String s[])
    {
          c2 o=new c2();
          System.out.println("a value is"+o.a);
           System.out.println("c value is"+o.c);
           System.out.println("b value is"+o.b);
         o.d2();
         o.d();
        c1 o1=new c1();
       o1.d();
      // o1.d2();
    }
};