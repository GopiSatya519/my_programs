import java.lang.*;
//Run time polymorphism
class Figure
{
double dim1;
double dim2;
Figure(double a,double b)
{
dim1=a;
dim2=b;
}
double area()//compile
{
System.out.println("area of Figure undefine:");
return 0;
}
};
class Rectangle extends Figure
{
Rectangle(double a,double b)
{
super(a,b);
}
double area()//runtime
{
System.out.println("area of rectangle:");
return dim1*dim2;
}
};
class Triangle extends Figure
{
//dim1,dim2
Triangle(double a,double b)
{
super(a,b);
}
double area()
{
System.out.println("area of Triangle:");
return dim1*dim2/2;
}
};
//Square
class FindArea
{
public static void main(String k[])//program driver
{
System.out.println("main method starts execution");

/*Triangle t=new Triangle(10,8);
System.out.println(t.area());;
Rectangle r=new Rectangle(9,5);
System.out.println(r.area());;
//Is it a polymorphism?-->No*/
//Dynamic method dispatch
Figure f;//reference object
f=new Rectangle(9,5);
System.out.println(f.area());
f=new Triangle(10,8);
System.out.println(f.area());
}
}