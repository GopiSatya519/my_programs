import java.lang.*;
import java.util.*;
class Lab8A  
{  
String name;  
int rool ;   
StudentDetails(String name1, int rool1)  
{  
name =name1;  
roll = roll1;  
}  
public void display()  
{  
System.out.print("Student Id = "+name + "  " + " roll number = "+roll);  
System.out.println();  
}  
}  
public class Lab8A  
{  
public static void main(String args[])  
{     
StudentDetails [] obj = new StudentDetails [5] ;   
obj[0] = new StudentDetails ("satya",1);  
obj[1] = new StudentDetails ("ausha",2);  
obj[2] = new StudentDetails ("nandhini",3);  
obj[3] = new StudentDetails ("durga",4);  
obj[4] = new StudentDetails ("kathu",5);  
System.out.println("StudentDetails  Object 1:");  
obj[0].display();  
System.out.println("StudentDetails  Object 2:");  
obj[1].display();  
System.out.println("StudentDetails  Object 3:");  
obj[2].display();  
System.out.println("StudentDetails  Object 4:");  
obj[3].display();  
System.out.println("StudentDetails  Object 5:");  
obj[4].display();  
}  
}   
