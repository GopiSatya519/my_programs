import java.util.*;
public class UserDefinedException extends Throwable
{
      UserDefinedException(String s)
      {
           super(s);
      }
      public static void main(String args[])
      {
             Scanner sc=new Scanner(System.in);
             try{
             System.out.println("enter age:");
             int age=sc.nextInt();//NumberFormatException
             System.out.println("enter roll number:");
             String rno=sc.next();//NumberFormatException
             if(age<19)
             { 
                   throw new UserDefinedException("age must be greater than 19");//thrown to catch block
             }
             if(rno.length()!=7)
             { 
                   throw new UserDefinedException("enter roll number correctly");
             }
             System.out.println("age is:"+age);
             System.out.println("roll number is:"+rno);
            }
           catch(UserDefinedException ude)
           {
                 System.out.println(ude.getMessage());
           }
           catch(Throwable e)
           {
                 System.out.println("exception raised");
           }
      }
}