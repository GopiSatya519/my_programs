import java.lang.*;
class String1
{
   public static void main(String args[])
{
   System.out.println("main method starts executing");
  String s="cse";
  String s1="csE welcomes";
  String s2="cse";
   
   System.out.println("string constant pool is checking:"+(s==s2));
   System.out.println("string constant pool is checking:"+(s1==s2));
   String s3=new String();
   String s4=new String("cse");
   String s5=new String("cse");
   System.out.println("heap is checking:"+(s4==s5));
   char a[]={'s','a','t','y','a'};
   String s6=new String(a,0,5);
   System.out.println("s6 character array: "+s6);
   String s7=new String(a);
   String s8=new String("cse welcomes you");
   String s9=new String("rgukt welcomes you");
   System.out.println("s7 character array:"+s7);
   System.out.println("s1 string charat(1):"+(s1.charAt(1)));
   char p[]=new char[10];
    
   System.out.println("s & s1 to check content is equal using equals():",+(s.equals(s1)));
   System.out.println("s & s1 to check content is equal using equalsIgnoreCase():",+(s.equalsIgnoreCase(s1)));

   System.out.println("regionMatches():",+(s8.regionMatches(False,4,s9,6,7)));
   System.out.println("startsWith():",+(s9.startsWith("rgukt")));
   System.out.println("endsWith():",+(s9.endssWith("you")));
   System.out.println("indexOf() left-right:",+(s9.indexOf("you")));
   System.out.println("lastIndexOf() right-left:",+(s9.lastIndexOf("you")));
    //System.out.println("substring(start,end) :",+s1.substring(4,11));
   System.out.println("cancat() :",+(s1.cancat("you")));
    
   


}

}