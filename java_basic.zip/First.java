import java.lang.*;
class First
{
public static void main(String s[])
{
System.out.println("my first java program");
}
}
