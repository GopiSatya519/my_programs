import java.lang.*;
import java.util.*;
class transverAry
{
   void transver(int [] a,int n)
{
    int b[]=new int[n];
    for(int i=0;i<n;i++)
      b[i]=a[i];
    for(int i=0;i<n;i++)
    System.out.print(b[i]+" "); 
}
}
class FirstArray
{
public static void main(String args[])
{
   //int a[]=new int[n];
   int n;
   Scanner t=new Scanner(System.in);
   System.out.println("Enter n value");
   n=t.nextInt();
   int a[]=new int[n];
   System.out.println("enter values");
   for(int i=0;i<n;i++)
     {a[i]=t.nextInt();}
   transverAry b=new transverAry();
   b.transver(a,n); 
}
}