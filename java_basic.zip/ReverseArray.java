import java.lang.*;
class Reverse
{
  void reverse(int [] a)
{
  for(int i=a.length-1,j=0;i>0&&j<a.length;i--,j++)
   {
     int temp=a[i];
     a[i]=a[j];
     a[j]=temp;
     
   }
   System.out.println("After reverse of an array elements are:");
        for(int i=0;i<a.length;i++)
       {
        System.out.println(a[i]);
       }
   
}

}
class Duplicate
{
   void duplicate(int [] a)
{
    for(int i=0;i<a.length;i++)
     {
       for(int j=i+1;j<a.length;j++)
       {
         if(a[i]==a[j])
          {
            a[j]=-1;
           }   
     }
}  
    System.out.println("after deletion of duplicate elemets,array elements are:");
     for(int i=0;i<a.length;i++)
     {
     if(a[i]!=-1)
       {
       System.out.println(a[i]); 
       }
     
      }  
}
}
class ReverseArray
{
    public static void main(String args[])
    {
        int a[] = {1,2,1,4,2,6,4,8,9,9};
        System.out.println("Array elements are");
        for(int i=0;i<a.length;i++)
       {
        System.out.println(a[i]);
       }
        Reverse a1=new Reverse();
        a1.reverse(a);
        Duplicate d=new Duplicate();
        d.duplicate(a);

    }
}