import java.lang.*;
import java.util.*;
class Program1
{
    public static void main()
{
    System.out.println("Welcom to Cse Department");
}
}
