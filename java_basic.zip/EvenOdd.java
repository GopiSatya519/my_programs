import java.lang.*;
class Separation
{
   void even(int [] b)
{
   for(int i=0;i<b.length;i++)
  {
   if(b[i]%2==0)
  {
   System.out.println(b[i]);
   }
}

}
void odd(int [] b)
{
   for(int i=0;i<b.length;i++)
  {
   if(b[i]%2!=0)
  {
   System.out.println(b[i]);
   }
}
}
}

class EvenOdd
{
   public static void main(String a[])
  {
      int b[]=new int[20];
      for(int i=0;i<a.length;i++)
      {
       b[i]=Integer.parseInt(a[i]);
      }
   Separation p=new Separation();
   System.out.println("Even numbers are:");
   p.even(b);
   System.out.println("Odd numbers are:");
   p.odd(b);
}
}

