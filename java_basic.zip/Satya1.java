import java.lang.*;
import java.util.*;
class Satya
{
   
void show()
{
  System.out.println("hi");
}
}
class Satya1
{
   public static void main(String args[])
{
   Scanner s=new Scanner(System.in);
   Satya [] arr=new Satya[10];
   System.out.println("enter objects");
   for(int i=0;i<10;i++)
{
    arr[i]=s.nextLine();
}
}
}