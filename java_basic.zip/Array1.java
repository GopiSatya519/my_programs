import java.lang.*;
class Frequency
{
    void frequency(int [] b)
{ 
     int temp[]=new int[b.length];
     int visited=-1;
     for(int i=0;i<b.length;i++)
    {  
     int count=1;
      for(int j=i+1;j<b.length;j++)
     { 
      if(b[i]==b[j])
{
      count++;
      temp[j]=visited;
}
           
}
if(temp[i]!=visited)
{
   temp[i]=count;
}
}
for(int i=0;i<b.length;i++)
{
if(temp[i]!=visited)
{


 System.out.println(b[i]+" is "+temp[i]);
}
}
}
}
class Array1
{
   public static void main(String s[])
{
   int a[]={1,2,3,2,1,3,4,5,6,7,6,8,7,2};
   System.out.println("Array elements are:");
   for(int i=0;i<a.length;i++)
{
   System.out.println(a[i]);
}
   Frequency a1=new Frequency();
   a1.frequency(a);
   
}
}