import java.lang.*;
class Fibonocci
{
   void fibonocci(int n)
{
    int a=0,b=1,p=0;
    for(int i=1;i<=n;i++)
    {
       System.out.println(a);
       p=a+b;
       a=b;
       b=p;
     }
}
}
class Factorial
{
    void factorial(int n)
{
    int res=1;
    for(int i=1;i<=n;i++)
{
    res*=i;
}
    System.out.println(res);
}
}
class Armstrong
{
   void armstrong(int a)
{
    int temp=a,res=0,rem;
    while(temp!=0)
{
     rem=temp%10;
     res+=rem*rem*rem;
     temp=temp/10;
}
     if(a==res)
{
     System.out.println("Given number is Armstrong.");
}
else
{
     System.out.println("Given number is not a Armstrong.");
}
}

}
class Palindrome
{
    void palindrome(int n)
{
   int res=0,rem,temp=n;
   while(n!=0)
{
   rem=n%10;
   res=res*10+rem;
   n/=10;
}
if(res==temp)   
{
   System.out.println("Given number is palindrome.");
}
else
{
   System.out.println("Given number is not a palindrome.");
}
}

}
class Number
{
   public static void main(String s[])
{
   int a;
   a=Integer.parseInt(s[0]);
   Fibonocci f=new Fibonocci();
   System.out.println("Fibonocci series upto the  given number is ");
   f.fibonocci(a);
   Factorial f1=new Factorial();
   System.out.println("Factorial of a given number is ");
   f1.factorial(a);
   Armstrong a1=new Armstrong();
   a1.armstrong(a);
   Palindrome p=new Palindrome();
   p.palindrome(a);

} 

}