import java.lang.*;
class ForSwap
{
void swap1(int a,int b)
{
a=a+b;
b=a-b;
a=a-b;
display(a,b);
}
void swap2(int a,int b)
{
int c;
c=a;
a=b;
b=c;
display(a,b);
}
void display(int p,int q)
{
System.out.println("After Swapping the values of a and b:"+p+" " +q);
}
}
class Swap
{
public static void main(String t[])
{
int a=2;int b=3;
System.out.println("Before swapping of a and b without using 3rd variable:"+a+" " +b);
ForSwap s=new ForSwap();
s.swap1(a,b);
System.out.println("Before swapping of a and b with using 3rd variable:"+a+" " +b);
s.swap2(a,b);
}

}
