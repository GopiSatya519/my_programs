import java.lang.*;
import java.util.*;
class RandomNum
{
   void random1(double n)
{
   System.out.println("Square of random number"+n*n);
}
}
class RandomNumGen
{
   public static void main(String Args[])
{
   double n=Math.random();
   RandomNum a=new RandomNum();
   a.random1(n);
}

}