import java.lang.*;
class Range
{
void range(int a,int b)
{

for (int i=a;i<=b;i++)
{
 int count=0;
    for(int j=1;j<=i;j++)
    {
      if(i%j==0)
        count+=1;
     }
     display(i,count);
}
}
void display(int num,int c1)
{
    if(c1==2)
       System.out.println(num);
}
}
class Prime
{
public static void main(String s[])
{
int a,b;
a=Integer.parseInt(s[0]);
b=Integer.parseInt(s[1]);
Range t=new Range();
 System.out.println("Prime numbers in between range of "+a+" to "+b+" are: ");
t.range(a,b);

}
}
