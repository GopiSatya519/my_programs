import java.lang.*;
class TransverArray
{
    void transver(int [] b)
   {
    System.out.println("B[] array elements are");
    for(int i=0; i<b.length; i++)
   {
    System.out.println(b[i]);
    }
}
}
class Array
{
   public static void main(String s[])
  {
   int a[]={1,2,3,4,5,6,7,8,9,10};
   System.out.println("a[] array elements are ");
   for(int i=0; i<a.length; i++)
   {
    System.out.println(a[i]);
   }
    TransverArray a1=new TransverArray();
    a1.transver(a); 
  }
}