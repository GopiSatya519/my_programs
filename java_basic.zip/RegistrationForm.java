import java.lang.*;
import java.util.*;
class UserId
{
   void userId(String s)
 {
   if(s.length()==7&&s.charAt(0)=='S'&&s.charAt(1)=='1'&&s.charAt(2)=='7')
   {
      System.out.println(" user id is:"+s);  
   }
   else
   {
    System.out.println(" please enter valid user id ");
   }
 }
}
class ComboOfLastFirstName
{
    void combo(String last,String first)
{
     String name=last+first;
     System.out.println("name:"+name.toLowerCase());
}
}
class Password
{
    void password(String s)
{
     if(s.length()>7 && s.contains("_") && s.contains("@")  && s.contains("."))
{   //&& s.matches("%[a-zA-Z]%") && s.matches("%[0-9]%")
      System.out.println("password:"+s);     
}
else
{
     System.out.println("Invalid password");
}
}
}
class ReCheckPassword 
{
   void checkPassword(String password,String repassword)
{
   if(password.equals(repassword))
   {
    System.out.println("successfully matches two passwords");
   }
   else
   {
   System.out.println("passwords are not matchimg.please recheck the password");
   }
}
}
class PhoneNumber 
{
     void phoneNumber(String number)
{
     if(number.length()==10&&number.matches("^[0-9]$"))
{
     System.out.println("phone number:"+number);
     
     RandomNumber(number);
}
else
{
    System.out.println("pls enter correct phone num");
}
}
     void RandomNumber(String a)
{

     Random random=new Random();
     int index = random.nextInt(a.length());

    System.out.println("Random number from a phone number:"+ (a.charAt(index)));
}
}
class RegistrationForm
{
      public static void main(String args[])
{
     Scanner s = new Scanner(System.in);

     System.out.println("Enter user id:");

     String userid = s.nextLine();

     UserId a = new UserId();

     a.userId(userid);

     System.out.println("Enter your last name:");

     String lastname = s.nextLine();

     System.out.println("Enter your first name:");

     String firstname = s.nextLine();

     ComboOfLastFirstName b = new ComboOfLastFirstName();

     b.combo(lastname ,firstname );
 
     System.out.println("Password:");
  
     String password = s.nextLine();

     Password c=new Password();

     c.password(password);
 
     System.out.println("please re enter the Password:");

     String repassword=s.nextLine();
 
     ReCheckPassword d= new ReCheckPassword();

     d.checkPassword(password,repassword);

     System.out.println("Enter your phone number:");
   
     String number=s.nextLine();

     PhoneNumber f=new PhoneNumber();
     
     f.phoneNumber(number);

     
}
}