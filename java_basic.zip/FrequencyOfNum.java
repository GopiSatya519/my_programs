import java.lang.*;
import java.util.*;
class FrequencyCount
{
   void frequency(int [] a,int n)
{
  int k;
    for(int i=0;i<n;i++)
      {
     int count=0;
       if(a[i]!='\0')
        {  
           k=a[i];
        for(int j=0;j<n;j++)
        {
          if(k==a[j])
         {
           count++;
           a[j]='\0';
         }
     }
   System.out.println("frequency of a "+k+" is "+count);
}

}
}
}
class FrequencyOfNum
{
public static void main(String args[])
{
   int n;
   Scanner t=new Scanner(System.in);
   System.out.println("Enter n value");
   n=t.nextInt();
   int a[]=new int[n];
   System.out.println("enter values");
   for(int i=0;i<n;i++)
    {a[i]=t.nextInt();}
  FrequencyCount b=new FrequencyCount();
   b.frequency(a,n); 
}
}