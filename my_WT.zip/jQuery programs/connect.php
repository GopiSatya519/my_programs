<? php
  $name = $POST['name'];
  $num = $POST['num'];
  $village = $POST['village'];
  $mandal = $POST['mandal'];
  $dist = $POST['dist'];
  $vac = $POST['vac'];
  $conn = new mysqli('localhost','root','','covid');
  if($conn->connect_error)
  {
  	die('Connection Failed:'.$conn->connect_error);
  }
  else{
  	$stmt =$conn->prepare(insert into vaccination(name,num,village,mandal,dist,vac) values(?,?,?,?,?,?));
  	$stmt->bind_param("ssssss",$name,$num,$village,$mandal,$dist,$vac);
  	$stmt->execute();
  	echo "registration Successfully...";
  	$stmt->close();
  	$conn->close();

  }
?>