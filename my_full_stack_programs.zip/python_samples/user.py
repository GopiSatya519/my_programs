#! python3
from flask import *
app=Flask(__name__)
import requests
import json
@app.route("/exercise1")
def excercise1():
    rq=requests.get("https://reqres.in/api/users?page=2")
    temp=json.loads(rq.text)
    names=[]
    for txt in temp['data']:
        last_name=txt['last_name']
        first_name=txt['first_name']
        names.append({"first_name":first_name,"last_name":last_name})
        #names.append((first_name,last_name))
    print(names)
        
    return   render_template('names_tables.html',json_names=names)


   




if __name__=='__main__':
    print("hi satya")
    app.run(debug=True)