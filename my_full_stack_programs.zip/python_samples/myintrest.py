#! python3
from flask import *
import requests
import json
app=Flask(__name__)
@app.route('/table')
def table():
    t=requests.get("https://reqres.in/api/users?page=2")
    t1=json.loads(t.text)
    list=[]
    for data in t1["data"]:
        id=data["id"]
        email=data["email"]
        first_name=data["first_name"]
        last_name=data["last_name"]
        avatar=data["avatar"]
        list.append({"id":id,"email":email,"first_name":first_name,"last_name":last_name,"avatar":avatar})
    return render_template('tableofdata.html',list=list,t1=t1)

if __name__=='__main__':
    print("myintrests")
    app.run(debug=True)