#! python3
from flask import *
app=Flask(__name__)
@app.route('/login')
def login():
    return render_template('login.html')
@app.route('/success')
def success():
    name= request.args.get('name')
    password=request.args.get('password')
    return render_template('success.html',name=name,password=password)
    #return {'name':name}
@app.route('/hello')
def hello():
    return render_template('hello.html')
if __name__=='__main__':
    print("sai ram")
    app.run(debug=True)


