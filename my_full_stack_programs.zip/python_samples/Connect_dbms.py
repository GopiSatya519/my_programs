# !python3
from sqlite3.dbapi2 import Cursor
from flask import Flask
import sqlite3
import json
import traceback
app=Flask(__name__)

con=sqlite3.connect('students.db',check_same_thread=False)
def createTable():
    try:
        cursor=con.cursor()
        cursor.execute('create table if not exists students(id integer primary key,name text)')
        con.commit()
    except Exception as e:
        print(e)


@app.route('/addStudents/<int:id>/<name>')
def addStudents(id,name):
    try:
        with app.app_context():
            cursor=con.cursor()
            cursor.execute('insert into students(id,name) values(?,?)',(id,name))
            con.comit()
    except Exception as e:
        print(traceback.traceback.format_exc())
    return "success"


@app.route('/delete_student/<int:id>')
def deleteStudent(id):
    try:
        with app.app_context():
            cursor=con.cursor() #varchar
            cursor.execute('delete from students where id='+str(id))
            con.commit()
    except Exception as e:
        print(traceback.format_exc())  
    return "Success" 

@app.route('/update_student/<int:id>/<name>')
def updateStudent(id,name):
    try:
        with app.app_context():
            cursor=con.cursor() #varchar
            cursor.execute('update students set name='+name+' where id='+str(id))
            con.commit()
    except Exception as e:
        print(traceback.format_exc())  
    return "Success"             

@app.route('/students')
def getStudents():
    list=[]
    try:
        with app.app_context():
            cursor=con.cursor() #varchar
            rows=cursor.execute('select * from students')
            
            for row in rows:
                print(row[0])#id
                print(row[1]) #name
                list.append({'id':row[0],'name':row[1]})
        return render_template('user.html',users=list)
    except Exception as e:
        print(e)   
    
    return json.dumps(list)
    



if __name__ =='__main__':
    createTable()
    # addStudent(1,'Kohli')
    getStudents()
    app.run(debug=True)  

