def x():
    a=5
print(callable(x))    
