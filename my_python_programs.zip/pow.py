x=pow(4,4)
print(x)
