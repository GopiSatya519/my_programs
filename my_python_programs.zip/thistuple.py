thistuple=("cherry","banana")
print(thistuple)
