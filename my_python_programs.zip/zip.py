a=("satya","sunitha","prasanna")
b=("anitha","satya","bhavani")
x=zip(a,b)
print(tuple(x))
