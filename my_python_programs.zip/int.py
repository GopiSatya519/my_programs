x=1
y=222
z=48770
print(type(x))
print(type(y))
print(type(z))
