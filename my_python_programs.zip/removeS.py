thisset={"apple","banana","cherry"}
thisset.remove("banana")

print(thisset)
