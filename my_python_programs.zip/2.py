a=10
if a==10:
   print("a is equals to 10")
