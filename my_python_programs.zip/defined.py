def numbers(x,y):
    sum=x+y
    return sum
num1=13454
num2=55798967
print("the sum is:",numbers(num1,num2))
