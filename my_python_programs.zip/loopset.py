check if "banana"is present in this set:
thislist={"apple","banana","cherry"}
ptint("banana"in thislist)
