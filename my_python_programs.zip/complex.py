x=1.23
y=23.56
z=407.576
print(type(x))
print(type(y))
print(type(z))
