thistuple=("apple","banana","cherry")
thistuple[1]="orange"
print(thistuple)













