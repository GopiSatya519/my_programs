def function(x):
    return x*3
print(function(3))
print(function(5))
print(function(9))
