number=68
print(bin(number))
