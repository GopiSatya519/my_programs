def myfunc(n):
      return len(n)
x = map(myfunc('apple', 'banana', 'cherry'))
print(list(x))
