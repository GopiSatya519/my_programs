x=compile("print(44)","test","eval")
exec(x)
