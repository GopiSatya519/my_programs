x=chr(98)
print(x)
