a=("a","b","c","d","e")
x=slice(3)
print(a[x])
