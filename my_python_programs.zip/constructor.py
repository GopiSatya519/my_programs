thistuple=tuple(("banana","cherry","apple"))
print(thistuple)
