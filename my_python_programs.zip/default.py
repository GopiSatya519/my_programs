def function(country="norway"):
    print("i am from "+country)
function("sweden")
function("india")
function("frace")
function()
