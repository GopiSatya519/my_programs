for i in range(1,7):
    print(i,i**2,i**3,i**4)
