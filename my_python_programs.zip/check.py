check if "banana"is present in this set:
thisset={"apple","banana","cherry"}
ptint("banana"in thisset)
