thistuple=(1,2,33,3,33,4,4,5,4)
x=thistuple.count(4)
print(x)
