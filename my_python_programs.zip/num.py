x=2354657678
y=5.6433
z=6+7j
print(type(x))
print(type(y))
print(type(z))
