def nsquare(x,y):
    return(x*x+2*x*y+y*y)
print("the square of the sum of 2 and 3 is:",nsquare(2,3))
