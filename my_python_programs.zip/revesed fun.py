alpha=["a","b","c","d"]
beta=reversed(alpha)
for x in beta:
    print(x)
