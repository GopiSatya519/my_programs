thistuple=("apple","banana","cherry")
thistuple[3]="orange"
print(thistuple)
