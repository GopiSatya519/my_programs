num=int(input("Enter the number="))
for a in range(1,6):
    print (num * a)
    
