a=("apple","bamana","cherry")
b="hello print fun"
c=19
x=type(a)
y=type(b)
z=type(c)
print(x)
print(y)
print(z)
