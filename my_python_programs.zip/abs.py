integer=-20
print(abs(integer))
