def myfunction():
    print("i am satya")
myfunction()    
