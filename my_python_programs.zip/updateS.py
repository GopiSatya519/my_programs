thisset={"cherry","banana","cherry"}
thisset.update(["orange","mango"])
print(thisset)
