value=([20])
print(bool(value))


empty=()
print(empty,bool(empty))

test=True
print(bool(test))


test={}
print(bool(test))


test="mt string"
print(bool(test))

test=(0)
print(bool(test))





