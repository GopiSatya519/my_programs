def myfunc(x):
    return len(x)
x=map(myfunc,("cherry","banana"))
print(list(x))
