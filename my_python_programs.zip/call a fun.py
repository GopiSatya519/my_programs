def avgnumbers(x,y):
    print("avrage of",x,"and",y,"is",(x+y)/2)
avgnumbers(4,5)    
