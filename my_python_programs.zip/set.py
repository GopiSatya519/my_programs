thisset={"apple","banana","cherry"}
print(thisset)
