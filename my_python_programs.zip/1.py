num=3
if num>0:
 print(num,"is a positive number")
