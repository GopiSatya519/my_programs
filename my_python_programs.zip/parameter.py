def function(fname):
    print(fname+" rgukt(iit)")
function("satya")
function("nandhini")
function("katyayani")
