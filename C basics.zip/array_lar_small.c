#include<stdio.h>
main()
{
     int a[100],i,n,large=a[0],small=a[0],ele;
     printf("\n enter a no. of elements:");
     scanf("%d",&n);
     for(i=0;i<n;i++)
     {
          printf("\n enter a[%d]\t",i);
          scanf("%d",&a[i]);
          }
          printf("the given array is:");
          for(i=0;i<n;i++)
          {
          printf("%d\t",a[i]);
          }
          printf("\n enter element to search:");
          scanf("%d",&ele);
          for(i=0;i<n;i++)
          {
              if(a[i]==ele)
              {


                printf("\n element found is %d",ele);
              printf("\nthe given element position is %d",i+1);
              printf("\n the index of the element is %d",i);
              break;
          }
          }

          for(i=0;i<n;i++)
          {
          if(a[i]>large)
          large=a[i];
          printf("\nlarge=%d",large);
          break;
          }
          for(i=0;i<n;i++)
           {
           if(a[i]<small)
           small=a[i];
           printf("\n small:%d",small);
           break;
          }
     }




