#include<stdio.h>
main()
{
    int a,b;
    a=-3--3;
    b=-3--(-3);
    printf("%d,%d",&a,&b);


}
