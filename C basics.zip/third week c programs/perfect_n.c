#include<stdio.h>
main()
{
     int n,i,j,sum;
     printf("enter a value to get range of perfect numbers:");
     scanf("%d",&n);
     for(i=1;i<=n;i++)
     {
         sum=0;
         for(j=1;j<i;j++)
         {
            if(i%j==0)
            {
             sum+=j;
            }

         }
          if(sum==i)
          printf("\n %d",i);
     }

}
