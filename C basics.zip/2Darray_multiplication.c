#include<stdio.h>
main()
{
     int a[10][10],b[10][10],c[10][10],ar,ac,br,bc,i,j,k;
     printf("enter no. of rows and colons:");
     scanf("%d%d",&ar,&ac);
     printf("enter elements\n");
     for(i=0;i<ar;i++)
     {
         for(j=0;j<ac;j++)/////////
         {
         scanf("%d",&a[i][j]);
         }
     }
     printf("the a matrix:\n");
     for(i=0;i<ar;i++)
     {
         for(j=0;j<ac;j++)
         {
             printf("%d\t",a[i][j]);
         }
            printf("\n");
     }
     printf("Enter no.of rows and cols:");
     scanf("%d%d",&br,&bc);
     printf("enter elements:\n");
     for(i=0;i<br;i++)
     {
        for(j=0;j<bc;j++)
        {

        scanf("%d\t",&b[i][j]);
        }

     }
      printf("the b matrix\n");
      for(i=0;i<br;i++)
      {
          for(j=0;j<bc;j++)
          {
              printf("%d\t",b[i][j]);
          }
          printf("\n");
      }
     if(ac==br)
     {
     for(i=0;i<ar;i++)
     {
        for(j=0;j<bc;j++)
        {
            c[i][j]=0;
        for(k=0;k<ac;k++)
        {
           c[i][j]+=a[i][k]*b[k][j];
        }
        }
   } }
     printf("matrix c is\n");
     for(i=0;i<ar;i++)
     {
        for(j=0;j<bc;j++)
        {
          printf("%d\t",c[i][j]);
        }
       printf("\n");
     }


     }


