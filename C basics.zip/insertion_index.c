#include<stdio.h>
main()
{
    int a[100],n,i,ele,index;
    printf("enter a element:");
    scanf("%d",&n);
    for(i=0;i<n;i++)
    {
        printf("a[%d]=",i);
        scanf("%d",&a[i]);

    }
    printf("enter element:");
    scanf("%d",&ele);
    printf("enter index position:");
    scanf("%d",&index);
    if(index<n)
    {
         for(i=n;i>=1;i--)
         {
             a[i]=a[i-1];

         }
      a[index]=ele;
      printf("the array is :");
      for(i=0;i<=n;i++)
      {
          printf("%d\t",a[i]);
      }
    }

}
