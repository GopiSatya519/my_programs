#include<stdio.h>
#include<math.h>
int add(int ,int );
int mul(int ,int );
main()
{
     int a,b,c;
     printf("\nenter the values of a,b:");
     scanf("%d%d",&a,&b);
     c=add(a,b);
     printf("\nadding of a and b is c=%d",c);
     c=mul(a,c);
     printf("\n multiplication of a and c:%d",c);
     int d,f,g;
     printf("\nenter the values d and f:");
     scanf("%d%d",&d,&f);
     g=add(d,f);
     printf("sum is=%d",g);
}
int add(int p,int q)
{
    int k=p+q;
    return k;
}
int mul(int p,int q)
{
    int k=p*q;
    return k;


}
