#include<stdio.h>
main()
{
     int a,i,n,*ptr;
     printf("enter number of elements:");
     scanf("%d",&n);
     ptr=(int *)malloc(n*sizeof(int));
     printf("\nenter elements:");
     for(i=0;i<n;i++)
     {
         scanf("%d",ptr+i);
     }
     for(i=0;i<n;i++)
     {
        printf("\n the elements are:");
     }


}
