#include<stdio.h>
struct student{
      char name;
      int rollnum;
         struct DateOfBirth{
           int dd;
           int mm;
           int year;
         }dob;
}std;
main()
{
     printf("\n enter name:");
     scanf("%s",&std.name);
     printf("\nenter roll number:");
     scanf("%d",&std.rollnum);
     printf("\ndate of birth[dd mm yy] format:");
     scanf("%d %d %d",&std.dob.dd,&std.dob.mm,&std.dob.year);
     printf("\nname=%s,std.name);  /*std.rollnum,std.dob.dd,std.dob.mm,std.dob.year*/
    //\nroll number=%d\ndate=%d\nmonth=%d\nyear=%d"
}
