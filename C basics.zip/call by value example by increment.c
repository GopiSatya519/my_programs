#include<stdio.h>
main()
{
    int increment(int );
    int a,b;
    printf("enter a number:");
    scanf("%d",&a);
    printf("before swaping value is %d",a);
    b=increment(a);
    printf("\nafter swaping value is %d",b);
}
int increment(int x)
{
     int y;
     y=++x;
     return y;

}
