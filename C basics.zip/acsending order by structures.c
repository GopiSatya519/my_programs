#include<stdio.h>
main()
{
    struct students
    {
       int regid;
       char name[20];
        int cgpa;
        struct address
        {
            char village[20];
            char district[20];
            int phoneno;
        }a1[20];
    }s1[20];
    int n,i,j;
    char temp[20];
    printf("\nenter how many no.of students details:");
    scanf("%d",&n);
    for(i=0;i<n;i++)
    {
        printf("\nenter register id:");
        scanf("%d",&s1[i].regid);
        printf("\nenter name:");
        scanf("%s",s1[i].name);
        printf("\nenter CGPA:");
        scanf("%f",&s1[i].cgpa);
        printf("\nenter village:");
        scanf("%s",s1[i].a1[i].village);
        printf("\nenter district:");
        scanf("%s",s1[i].a1[i].district);
        printf("\nenter phone number:");
        scanf("%d",&s1[i].a1[i].phoneno);
  }
  for(i=0;i<n;i++)
  {
      for(j=i+1;j<n;j++)
      {
          if(s1[i].regid>s1[j].regid)
          {
              temp[i]=s1[i].regid;
              s1[j].regid=s1[j].regid;
              s1[i].regid=temp[i];

          }
      }
  }

    for(i=0;i<n;i++)
    {
        printf("%d\n",s1[i].name);
    }


}
