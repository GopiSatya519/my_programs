#include<stdio.h>
main()
{
    int a[10][10],i,j,row,col;
    printf("enter no.of rows:");
    scanf("%d",&row);
    printf("enter no. of col:");
    scanf("%d",&col);
    printf("enter elements:\n");
    for(i=0;i<row;i++)
    {
         for(j=0;j<col;j++)
         {

           scanf("\n%d",&a[i][j]);
         }
    }
    printf("the matrix is:\n");

        for(i=0;i<row;i++)
        {
          for(j=0;j<col;j++)
          {

                printf("%d\t",a[i][j]);
          }
         printf("\n");
         }
}
