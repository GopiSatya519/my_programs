#include<stdio.h>
main()
{
     int a[10][5][3],i,j,k,row1,row2,col;
     printf("enter row1 row2 col:");
     scanf("%d%d%d",&row1,&row2,&col);
     printf("enter elements:\n");
     for(i=0;i<row1;i++)
     {
         for(j=0;j<row2;j++)
         {
            for(k=0;k<col;k++)
            {
            scanf("%d",&a[i][j][k]);
            }

         }

     }
     printf("3D matrix:");
     for(i=0;i<row1;i++)
     {
         for(j=0;j<row2;j++)
         {
            for(k=0;k<col;k++)
            {
            printff("%d",a[i][j][k]);
            }

         }

     }



}
