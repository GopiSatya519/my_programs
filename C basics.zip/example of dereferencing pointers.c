#include<stdio.h>
main()
{
    int *ptr,var1,var2;
    ptr=&var1;
    *ptr=25;
    *ptr+=10;
    printf("var1 contains %d\n",var1);
    var2=*ptr;
    printf("var2 contains %d\n",var2);
    ptr=&var2;
    *ptr+=20;
    printf("now var2 contains %d\n",var2);




}
