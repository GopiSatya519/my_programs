#include<stdio.h>
int gcd(int ,int );
main()
{
     int a,b,result;
     printf("enter any two integer values to get gcd:");
     scanf("%d %d",&a,&b);
     result=gcd(a,b);
     printf("GCD value of above two numbers:%d",result);
}
int gcd(int a,int b)
{
    while(a!=b)
    {
        if(a>b)
        {
           return gcd(a-b,b);
        }
        else
        {
           return gcd(a,b-a);
        }
    }
    return a;
}
