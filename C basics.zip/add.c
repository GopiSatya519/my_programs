#include<stdio.h>
 main()
 {
    int a,b,c;
    printf("enter the value of a:",a);
    printf("enter the value of b:",b);
    c=a+b;
    printf("the result:",c);
}
