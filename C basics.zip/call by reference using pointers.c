#include<stdio.h>


void swapnumb(int *a,int *b)
{
     int temp=0;
     temp=*a;
     *a=*b;
     *b=temp;


}
main()
{
     int a=35,b=45;
     printf("before swapping\n");
     printf("%d %d",a,b);
     swapnumb(&a,&b);
     printf("\n after swapping");
     printf("\n a=%d",a);
     printf("\n b=%d",b);
}
