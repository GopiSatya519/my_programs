#include <stdio.h>
#include<string.h>

int main()
{
struct student
{
    char sname[30];
    int sid;
    int sage;
};
    struct student s[50]={{"Ramakrishna", 200,150.5},{"Naresh", 220,250.5}};

int i;
for(i=0;i<2;i++){
     printf("\n*****%d Student details******",i+1);
     printf("\n Student Name is: %s",s[i].sname);
     printf("\n Student Id is: %d",s[i].sid);
     printf("\n Student Age is: %d",s[i].sage);
 }
     return 0;
}
