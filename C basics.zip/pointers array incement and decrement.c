#include<stdio.h>
main()
{
    int a[10]={10,20,30,40};
    int *ptr;
    ptr=a;
    printf("the value is:%d\n",*ptr);
    ptr=ptr++;
    printf("the value %d\n",*ptr);
    printf("the value %d\n",*ptr++);
    printf("the value %d\n",*ptr+1);




}
