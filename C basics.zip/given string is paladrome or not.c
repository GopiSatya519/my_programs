#include<stdio.h>
#include<stdio.h>
main()
{
    char str[50],s[50];
    int l=0,j,i,x;
    printf("enter a string:");
    gets(str);
    strcpy(s,str);
    while(str[l]!='\0')
   {
       l++;
   }
    j=l-1;
    i=0;
    while(i<j)
    {
    char temp;
    temp=str[i];
    str[i]=str[j];
    str[j]=temp;
    i++;
    j--;
    }
    x=strcmp(s,str);
    if(x==0)
    {
      printf("given string is palandrome");

    }
    else
    {
       printf("given sring is not paladrome");
    }
}
