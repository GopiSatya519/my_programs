#include<stdio.h>
int main()
{
     int a,b,c,d;
     printf("enter the values:");
     scanf("%d,%d,%d",&a,&b,&c);

     d=a+b+c;
     printf("the result is :%d",d);

}
