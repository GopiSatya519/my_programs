#include<stdio.h>
main()
{
   int n;
   printf("enter a number");
   scanf("%d",&n);
   while(1)
   {
   printf("\n SATYA");
   if(n==-1)
   {
       break;
   }
   }
}
