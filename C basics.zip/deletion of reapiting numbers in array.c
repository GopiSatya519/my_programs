 #include<stdio.h>
 main()
 {
 int a[20 ],i,j,n;
 printf("\nenter number of elements:");
 scanf("%d",&n);
 printf("enter elements:\n");
 for(i=0;i<n;i++)
 {
 scanf("%d",&a[i]);
 }
 for(i=0;i<n;i++)
 {
  for(j=i+1;j<n;j++)
  {
     if(a[i]==a[j])
     {
        a[j]=a[j+1];
        n--;
     }
  }

 printf("%d ",a[i]);
 }



 }
