#include<stdio.h>
main()
{
     int a[20][20],n,i,j;
     printf("\nNAME:G.SATYA");
    printf("\nID NO:S170487");
     printf("\nenter n value:");
     scanf("%d",&n);
     for(i=0;i<=n;i++)
     {
         for(j=0;j<=n;j++)
         {
             if((i==0)||(i==n)||(j==0)||(j==n))
                {
                    printf("1\t");
                }

             else
             {
                 printf("0\t");
             }
         }
         printf("\n");
         }

     }




