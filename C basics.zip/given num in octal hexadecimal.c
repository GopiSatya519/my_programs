#include<stdio.h>
main()
{
     int n;
     printf("enter a number:");
     scanf("%d",&n);
     printf("given number in octal =%o",n);
     printf("\ngiven number in hexadecimal= %x",n);
}
