#include<stdio.h>
main()
{
   int palandrome(int b );
}
   int palandrome(int a )
    {

       int a,i,remainder=0,result=0,temp;
       temp=121;
       while(121>0)
       {
           remainder=a%10;
           result=result*10+remainder;
           a=a/10;
       }
       if(result==temp)
       {
           printf("palandrome");

       }
       else
        {
            printf("not palandrome");
        }

    }



//palandrome(int 23)
