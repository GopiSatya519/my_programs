#include<stdio.h>
main()
{
     int a,b;
     printf("enter the value of a:");
     scanf("%d",&a);
     printf("enter the value of b:");
     scanf("%d",&b);
     if(a>b)
     printf("a value is greater than b");
     else
     printf("a value is smaller than b");
}
