#include<stdio.h>
main()
{
     int var=5;
     printf("%d",var=++var==6);

}
