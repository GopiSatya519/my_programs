#include<stdio.h>
main()
{
    int a=1;
    while(a<=100)
 {
     printf("%c",177);
     a++;
 }
}
