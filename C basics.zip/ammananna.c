#include<stdio.h>
main()
{
     int i,j,k,l,count,n=30;
     for(i=1;i<=n;i++)
     {
          for(j=2;j<=n;j++)
          {
               for(k=1;k<=n;k++)
               {
               if(k%j==0)
               count++;
            }
            for(l=1;l<=2*i-1;l++)
            {
                if(count==2)
                printf("%d",l);
                }

          }
          printf("\n");


     }

}
