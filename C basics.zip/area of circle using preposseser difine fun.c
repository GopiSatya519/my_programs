#include<stdio.h>
#define pi 3.14
int main()
{
   float circlearea(int);
   int a;
   float result;
   printf("enter a area of the circle:");
   scanf("%d",&a);
   result=circlearea(a);
   printf("result=%f",result);
}
float circlearea(int x)
{
    float c;
    c=pi*x*x;
    return c;


}
