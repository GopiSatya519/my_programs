#include<stdio.h>
#include<string.h>
main()
{
    char a[5][10];
    int i;
    printf("enter string:\n");
    for(i=0;i<5;i++)
    {
     gets(a[i]);
    }
    printf("strings are:\n");
    for(i=0;i<5;i++)
    {
        puts(a[i]);
    }


}
