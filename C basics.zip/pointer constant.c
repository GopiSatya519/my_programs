#include<stdio.h>
int main(void)
{
    int var1 = 0;
    const int *ptr = &var1;
    *ptr = 1;
    printf("%d\n", *ptr2);
    return 0;
}
