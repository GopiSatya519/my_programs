#include<stdio.h>
main()
{
    int n,*ptr,i,max=0;
    printf("enter number of values:");
    scanf("%d",&n);
    ptr=(int*)malloc(n*sizeof(int));
    printf("\nenter elements:");
    for(i=0;i<n;i++)
    {
       scanf("%d",(ptr+i));

    }
    max=*ptr;
    for(i=0;i<n;i++)
    {
       if(*(ptr+i)>max)
       {
          max=*(ptr+i);
       }
    }
    printf("maximum number=%d",max);


}
