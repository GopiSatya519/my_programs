#include<stdio.h>
main()
{
   int x=2,y=3;
   add(x,y);
}
add( int a,int b)
{
    int c;
    c=a+b;
    printf("%d",c);

}
