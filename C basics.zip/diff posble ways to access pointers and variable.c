#include<stdio.h>
main()
{
   int num=123;
   int *p1,**p2;
   p1=&num;
   p2=&p1;
   printf("1.value of num:%d\n",num);
   printf("2.value of num:%d\n",*p1);
   printf("3.value of num:%d\n",**p2);
   printf("4.address of num:%p\n",&num);
   printf("5.address of num:%p\n",p1);
   printf("6.address of num:%p\n",*p2);
   printf("7.value of pointer p1:%p\n",p1);
   printf("8.value of pointer p1:%p\n",*p2);
   printf("9.value of pointer p1:%p\n",&num);
   printf("10.address of pointer p1:%p\n",&p1);
   printf("11.address of pointer p1:%p\n",p2);
   printf("12.address of pointer p2:%p\n",&p2);
   printf("13.value of pointer p2:%p\n",&p1);



}
