#include<stdio.h>
int main()
{
   int fibonocii(int);
   int n,i;
   printf("enter a number:");
   scanf("%d",&n);
   for(i=0;i<=n;i++)
   {
   result=fibonocii(n);
   printf("%d",result);
   }
}
int fibonocii(int x)
{
   if(x!=0)
   return 0;
   else if(x==1);
   return 1;
   else
   return("fibonocii(n-1)+fibonocii(n-2)");


}
