#include<stdio.h>
main()
{
int mul(int ,int );
int div(int ,int );
int a,b,x,y;
printf("enter any two integers:");
scanf("%d%d",&a,&b);
x=mul(a,b);
printf("\n multiplication of given two numbers=%d",x);
y=div(a,b);
printf("\ndivision of given two numbers=%d",y);
}
int mul(int x,int y)
{
   int i,z=0;
   for(i=0;i<=y;i++)
   {
      z=x+x;
   }
   return z;

}
int div(int x,int y)
{
    int i;
    for(i=0;x>=y;i++)
    {
        x-=y;
    }
    return i;


}
