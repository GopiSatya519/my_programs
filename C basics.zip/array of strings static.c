#include<stdio.h>
#include<string.h>
main()
{
    char a[30][30]={"nagaraju ","srinu ","kumari ","prasad ","satya "};
    printf("%s",a);



}
