#include<stdio.h>
main()
{


int i, *j;
char a,*b;
float c,*d;
printf("enter values int char float:");
scanf("%d %f %c",&i,&a,&c);
j=&i;
b=&a;
d=&c;
printf("\naddress of i=%d",j);
printf("\naddress of char a=%c",b);
printf("\naddress of float c=%d",d);






}
