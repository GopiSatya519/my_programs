#include<stdio.h>
main()
{
   int a;
   printf("enter int value:");
   scanf("%d",&a);
   float b,result;
   printf("enter float value:");
   scanf("%f",&b);
   void *ptr,*ptr1;
   ptr=&a;
   printf("%d\n",*(int*)ptr);
   ptr1=&b;
   printf("%f\n",*(float*)ptr1);
   result=*(int*)ptr**(float*)ptr1;
   printf("%f\n",result);



}
