#include<stdio.h>
main()
{
    int i,j,k,n;
    printf("enter no. of rows");
    scanf("%d",&n);
    for(i=1;i<n;i++)
    {
        for(j=i;j<=n;j++)
        {
        printf(" ");
        }
        for(k=1;k<=2*i-1;k++)
        {
            if(i==n&&k==n)
            {
                printf("s");

            }
            else
           {
            printf("*");
           }


        }

        printf("\n");

    }



      for(i=n;i>=1;i--)
       {
           for(j=i;j<=n;j++)
           {
            printf(" ");

           }
           for(k=1;k<=2*i-1;k++)
           {
              printf("*");
           }
           printf("\n");
       }
    }

