#include<stdio.h>
main()
{
   int i,a,sum=0;
   printf("enter a:\n");
   scanf("%d",&a);
   for(i=1;i<a;i++)
   {
       if(a%i==0)
        sum=sum+i;
   }
   if(sum=a)
    printf("perfect number");
   else
    printf("not perfect");
}
