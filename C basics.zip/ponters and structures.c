#include<stdio.h>
struct details
{
      int phone;
     int idno;
};
int main()
{
    struct details s,*ptr;
    ptr=&s;
    printf("\nenter a name:");
    scanf("%d",&s->phone);
    printf("\nenter id no:");
    scanf("%d",&s->idno);
    printf("name:%d",s->phone);
    printf("id no:%d",s->idno);
}
