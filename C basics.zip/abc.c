#include<stdio.h>

main()
{
    int a[4][5];
    printf("%d",a[0][0]);
}





