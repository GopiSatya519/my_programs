#include<stdio.h>
int main()
{
	int a[100];
	int i,j,n,count=1,max=1,maximumelement;
	printf("NAME:SATYA\n");
    printf("ID NO:S170487\n");
	printf("enter the number of elements:\n");
	scanf("%d",&n);
	printf("array elements are:\n");
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	for(i=0;i<n;i++)
	{
		for(j=i+1;j<n;j++)
		{
		   if(a[j]==a[i])
		   count++;
	    }
		if(count>max)
		{
		max=count;
		maximumelement=a[i];
	    }
	}
	printf("max=%d\n",maximumelement);
}
