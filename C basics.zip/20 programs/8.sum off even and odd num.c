 #include<stdio.h>
main()
{
    int a[20],i,n,j,evensum=0,oddsum=0;
    printf("\nNAME:G.SATYA");
    printf("\nID NO:S170487");
    printf("\nenter no of elements:");
    scanf("%d",&n);
    printf("\nenter elements:");
    for(i=0;i<n;i++)
    {
    scanf("%d",&a[i]);
    }
    for(i=0;i<n;i++)
    {
        if(a[i]%2==0)
       {
          evensum+=a[i];
       }
       else
       {
          oddsum+=a[i];
       }
       }
    printf("\neven num sum=%d",evensum);
    printf("\nodd num sum =%d",oddsum);

}
