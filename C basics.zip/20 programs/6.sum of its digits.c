#include<stdio.h>
main()
{
     int n,remainder,sum=0;
     printf("\nNAME:G.SATYA");
     printf("\nID NO:S170487");
     printf("\nenter a number to get sum of its digits:\n");
     scanf("%d",&n);
     while(n>0)
     {
         remainder=n%10;
         sum+=remainder;
         n=n/10;
     }
     printf("the sum its digits=%d",sum);
}
