#include<stdio.h>
main()
{
   int a[10],n,sum=0,i,k;
   printf("\nNAME:G.SATYA");
printf("\nID NO:S170487");
   printf("\nenter n value:");
   scanf("%d",&n);
   printf("\nenter k value for position:");
   scanf("%d",&k);
   printf("enter elements:\n");
   for(i=0;i<n;i++)
   {
   scanf("%d",&a[i]);
   }
   for(i=0;i<n;i++)
   {
       sum=a[i];
      a[i+1]=sum+a[i+1];
      printf("%d\t",a[i]);
   }
   printf("\nthe value of a %d position :%d",k,a[k-1]);



}
