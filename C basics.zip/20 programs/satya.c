#include<stdio.h>
main()
{
    int n,k,temp,fact=1,sum=0,remainder,j;
    printf("enter a number to get range of strong numbers:\n");
    scanf("%d",&n);
    for(k=1;k<=n;k++)
    {
    temp=k;
    while(k>0)
    {
       remainder=k%10;
       for(j=0;j<=remainder;j++)
       {
       fact=fact*j;
       }
       sum=sum+fact;
       }
    if(temp==sum)
       {
         printf("%d\t",temp);

       }

    }
}
