#include<stdio.h>
main()
{
   int a[10],b[10],c[20],i,k;
   printf("\nNAME:G.SATYA");
   printf("\nID NO:S170487");
   printf("\nenter a elements:\n");
   for(i=0;i<10;i++)
   {
   scanf("%d",&a[i]);
      c[i]=a[i];
    }
    printf("\na=%d\n",i);
    k=i;
    printf("enter b elements\n");
    for(i=0;i<10;i++)
    {
    scanf("%d",&b[i]);
    c[k]=b[i];
    k++;
    }
    printf("\na=%d\n",k);
    printf("c elements are:\n");
    for(i=0;i<k;i++)
    {
         printf("%d\t",c[i]);
    }



}
