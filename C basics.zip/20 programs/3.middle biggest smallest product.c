#include<stdio.h>
#include<stdlib.h>
main()
{
   int a,b,c,max,min,mid,product;
   printf("\nNAME:G.SATYA");
    printf("\nID NO:S170487");
   printf("\nenter any three numbers:");
   scanf("%d%d%d",&a,&b,&c);
   max=a;
   if(b>max)
    max=b;
    if(c>max)
    max=c;
    min=a;
   if(b<min)
    min=b;
   if(c<min)
    min=c;
   mid=(a+b+c)-abs(max+min);
   product=a*b*c;
   printf("\nmaximum number=%d",max);
   printf("\nminimum number=%d",min);
   printf("\nmiddle number=%d",mid);
   printf("\nproduct of three numbers=%d",product);
}
