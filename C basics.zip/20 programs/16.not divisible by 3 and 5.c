#include<stdio.h>
main()
{
    int i,n;
    printf("\nNAME:G.SATYA");
printf("\nID NO:S170487");
    printf("\nenter number elements to get numbers which is not divisible by 3 and 5:");
    scanf("%d",&n);
    for(i=0;i<n;i++)
    {
        if(i%3!=0&&i%5!=0)
        {
        printf("%d\n",i);
    }
    }

}
