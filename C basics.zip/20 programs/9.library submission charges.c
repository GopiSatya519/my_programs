#include<stdio.h>
main()
{
int a;
printf("\nNAME:G.SATYA");
printf("\nID NO:S170487");
printf("\nenter how many days u r late to submit:");
scanf("%d",&a);
if(a<=5)
{
printf("\n you have to pay 5 piasa");
}
else if(a<=10)
{
printf("\n you have to pay 1 rupee");
}
else if(a>10&&a<30)
{
    printf("you have to pay 5 rupees");
}
else
{
printf("\n your member ship will be canceled ");
}
}
