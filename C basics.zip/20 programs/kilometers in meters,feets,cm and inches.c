#include>stdio.h>
main()
{
    int a,b;
    float distance
    printf("enter a distance of place(in kilometers):");
    scanf("%d",&a);
    printf("enter a distance of another place(in kilometers)");
    sacnf("%d",&b);
    distance=b-a;





}
