#include<stdio.h>
main()
{
int a[10],max,min,i,n;
printf("\nNAME:G.SATYA");
printf("\nID NO:S170487");
printf("\nenter number of elements:");
scanf("%d",&n);
printf("\nenter elements:");
for(i=0;i<n;i++)
{
   scanf("%d\n",&a[i]);
}
max=a[0];
for(i=0;i<n;i++)
{
   if(a[i]>max)
   {
   max=a[i];
   }
}
min=a[0];
for(i=0;i<n;i++)
{
   if(min>a[i])
   {
   min=a[i];

   }
   }
printf("\nthe range between smallest and biggest %d & %d is:%d",min,max,max-min);

}
