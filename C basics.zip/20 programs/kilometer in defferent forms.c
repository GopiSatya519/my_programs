#include<stdio.h>
#include<math.h>
#include<stdlib.h>
main()
{
    float a,b;
    float distance;
    printf("\nNAME:G.SATYA");
    printf("\nID NO:S170487");
    printf("\n enter a distance of place(in kilometers):");
    scanf("%f",&a);
    printf("\nenter a distance of another place(in kilometers)");
    scanf("%f",&b);
    distance=abs(a-b);
    printf("\n%0.3f kilometers",distance);
    printf("\n distance in meters=%0.3f meters",distance*1000);
    printf("\n distance in centimeters=%0.3f cm",distance*100000);
    printf("\n distance in feet=%0.3f foot",distance*3280.84);
    printf("\n distance in inches=%0.3f inches",distance*39370.0787);





}
