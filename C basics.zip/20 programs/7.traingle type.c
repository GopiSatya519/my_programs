#include<stdio.h>
#include<math.h>
main()
{
int a,b,c;
printf("\nNAME:G.SATYA");
printf("\nID NO:S170487");
printf("\n enter a three sides of traingle:");
scanf("%d %d %d",&a,&b,&c);
if(a==b==c)
{
printf("\n it is a equilateral triangle");
}
else if(a==b||b==c||c==a)
{
printf("\n it is a isolate triangle");
}
else if(sqrt(a*a+b*b)==c||sqrt(b*b+c*c)==a||sqrt(c*c+a*a)==b)
{
printf("\n it is right angle triangle");

}
else
{
printf("it is scalen traingle");
}
}
