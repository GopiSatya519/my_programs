#include<stdio.h>
main()
{
int n,i,j,fact=1;
float result=0;
printf("\nNAME:G.SATYA");
printf("\nID NO:S170487");
printf("\nenter value to print a series upto given value:");
scanf("%d",&n);
for(i=1;i<=n;i++)
{
  for(j=i;j>=1;j--)
  {
      fact=fact*j;
  }


    result+=(float)i/fact;

}
printf("result=%f",result);
}
