#include<stdio.h>
main()
{
    int n,k,temp,sum=0,fact,remainder,j;
    printf("\nNAME:G.SATYA");
printf("\nID NO:S170487");
    printf("enter a number to get range of strong numbers:\n");
    scanf("%d",&n);
    for(k=1;k<=n;k++)
    {
    temp=k;
    sum=0;

    while(temp>0)
    {
         fact=1;
       remainder=temp%10;
       j=1;
       for(j=1;j<=remainder;j++)
       {
       fact=fact*j;
       }
       sum=sum+fact;
       k=k/10;
    }

     if(temp==sum)
         printf("%d\t",temp);


    }
}

