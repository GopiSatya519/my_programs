#include<stdio.h>
main()
{
    int a;
    printf("\nNAME:G.SATYA");
    printf("\nID NO:S170487");
    printf("\nenter a year to check its leap year or not:");
    scanf("%d",&a);
    if(a%4==0&&a%100!=0)
    printf("%d is leap year",a);
    else
    printf("%d not a leap year",a);




}
