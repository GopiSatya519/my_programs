#include<stdio.h>
main()
{
  int a,b;
  printf("\nNAME:G.SATYA");
printf("\nID NO:S170487");
  printf("\nenter percentage in main subject:");
  scanf("%d",&a);
  printf("\nenter percentage in subsidairy subject:");
  scanf("%d",&b);
  if(a>=55&&b>=45)
  {
      printf("\nyou are qualified");
  }
  else if(a<55&&a>45&&b>=55)
  {
  printf("\n qualified");
  }
  else if(b<=45&&a>=65)
  {
  printf("\nyou allowed to reappear in an examination in subsidairy to qualify");
  }
  else
  {
     printf("\nyou are failed");
  }


}
