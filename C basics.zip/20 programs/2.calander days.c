#include<stdio.h>
main()
{
     int year,totalyear,leapyear,totaldays,normalyear,n;
     printf("\nenter a year:\n");
     scanf("%d",&year);
     totalyear=year-1900;
     leapyear=totalyear/4;
     normalyear=totalyear-leapyear;
     totalyear=(normalyear*365)+(leapyear*366);
     n=totalyear%7;
     if(n==1)
     printf("monday");
     if(n==2)
     printf("tuesday");
     if(n==3)
     printf("wednesday");
     if(n==4)
     printf("thursday");
     if(n==5)
     printf("friday");
     if(n==6)
     printf("saturday");
     if(n==7)
     printf("sunday");

}
