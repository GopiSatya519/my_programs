#include<stdio.h>
int fact(int );
void beep();
main()
{
    int a,c;
    printf("enter a fact num:");
    scanf("%d",&a);
    c=fact(a);
    printf("\n factorial=%d",c);
    beep();
}
int fact(int x)
{
    int i,fact=1;
    for(i=1;i<=x;i++)
    {
        fact=fact*i;
    }
    return fact;
}
void beep()
{
    printf("\n heard beep sound now");
    printf("\a");
}
