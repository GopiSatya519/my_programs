#include<stdio.h>
main()
{
   char strlen(char);
   char struper();
   char a[]="satya";
   char b[]="prasad";
   strlen(a);
   //struper(a,b);
   }
   char strlen(char a)
   {
      int i;
      for(i=0;a[i]!='\0';i++);
      printf("\n%d",i);


   }
