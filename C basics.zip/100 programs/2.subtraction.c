#include<stdio.h>
main()
{
     int a,b,c;
     printf("\nenter a value:");
     scanf("%d",&a);
     printf("\nenter b value:");
     scanf("%d",&b);
     c=a-b;
     printf("subtraction=%d",c);


}
