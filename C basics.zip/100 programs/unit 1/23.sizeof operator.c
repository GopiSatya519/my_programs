#include<stdio.h>
main()
{
    short int a;
    float b,c;
     printf("\nenter a value:");
     scanf("%d",&a);
     printf("\nenter b value:");
     scanf("%d",&b);
     printf("\n memory in bytes:%d",sizeof(a));
     printf("\n memory in bytes:%d",sizeof(b));
}
