#include<stdio.h>
main()
{
    int a,b;
     printf("\nenter a value:");
     scanf("%d",&a);
     printf("\nenter b value:");
     scanf("%d",&b);
     a>b?printf("%d is biggest",a):printf("%d is smaller",a);
}
