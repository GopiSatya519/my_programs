#include<stdio.h>
main()
{
    int a,b;
     printf("\nenter a value:");
     scanf("%d",&a);
     printf("\nenter b value:");
     scanf("%d",&b);
     if(a<=b)
     printf("\n%d is less than or equal %d",a,b);
}
