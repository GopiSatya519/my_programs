#include<stdio.h>
main()
{
    int a,b;
     printf("\nenter a value:");
     scanf("%d",&a);
     printf("\nenter b value:");
     scanf("%d",&b);
     a++;
     b++;
     printf("\n a value:%d",a);
     printf("\n b value:%d",b);
}
