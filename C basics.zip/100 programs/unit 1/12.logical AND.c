#include<stdio.h>
main()
{
    int a,b,c;
     printf("\nenter a value:");
     scanf("%d",&a);
     printf("\nenter b value:");
     scanf("%d",&b);
     printf("\nenter c value:");
     scanf("%d",&c);
     if(a&&b<c)
     printf("\n%d is greater than %d %d",c,a,b);
}
