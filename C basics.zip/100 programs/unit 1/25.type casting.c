#include<stdio.h>
main()
{
    short int a;
    float b,c;
     printf("\nenter a value:");
     scanf("%d",&a);
     printf("\nenter b value:");
     scanf("%d",&b);
     c=(float)a;
     printf("\n type casting :%d",c);
}
