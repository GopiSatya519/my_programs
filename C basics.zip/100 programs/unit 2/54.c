#include<stdio.h>
main()
{
   int a[10],i;
   printf("\nenter array elements:");
   for(i=0;i<10;i++)
   {
   scanf("%d",&a[i]);

   }
   printf("\n elements are:");
   for(i=0;i<10;i++)
   {
   printf("%d\t",a[i]);
   }
}
