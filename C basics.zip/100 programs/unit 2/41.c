#include<stdio.h>]
main()
{
    int a,b,c,n,m,y;
    printf("enter any 3 num:");
    scanf("%d%d%d",&a,&b,&c);
    n=31;
    m=12;
    y=2020;
    if(a<=n&&b<=m&&c<=y)
    {
      a++;
      b++;

    }
    printf("%d-%d-%d",a,b,c);

}
