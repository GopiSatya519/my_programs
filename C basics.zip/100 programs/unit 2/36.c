#include<stdio.h>
main()
{
   printf("We are at first printf statement!!!\n") ;
   goto third ;
   printf("We are at second printf statement!!!\n") ;
   third:printf("We are at third printf statement!!!\n") ;
   printf("We are at last printf statement!!!\n") ;

}
