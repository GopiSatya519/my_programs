#include<stdio.h>
main(){
   int n = 0;
   printf("Even numbers upto 10\n");
   do
   {
      if( n%2 == 0)
         printf("%d\t", n) ;
      n++ ;
   }while( n <= 10 ) ;

   getch() ;
}
