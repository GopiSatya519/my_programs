#include<stdio.h>
main()
{
     int n,i;
     printf("enter a num:\n");
     scanf("%d",&n);
     for(i=1;i<=n;i++)
     {
         if(i%3==0&&i%5==0)
         {
            break;
         }

        printf("%d\n",i);
     }




}
