#include<stdio.h>
main()
{
    int i,size,flag=0,delitem,position;
    printf("enter a size of the array:");
    scanf("%d",&size);
    int a[size],temp[size-1];
    printf("enter array numbers");
    for(i=0;i<size;i++)
    {
      scanf("%d",&a[i]);

    }
    printf("enter an element to delete:");
    scanf("%d",&delitem);
    for(i=0;i<size;i++)
    {
       if(a[i]==delitem)
       {
          position=i;
          flag=1;

       }
    }
    if(flag==1)
    for(i=0;i<size-1;i++)
    {
      if(i<position)
      {
         temp[i]=a[i];
      }
      if(i>=position)
      {
          temp[i]=a[i+1];
      }
    }
      printf("array elements after deletion of %d number\n",delitem);
      for(i=0;i<size-1;i++)
      {
          printf("%d\n",temp[i]);
      }


    }





