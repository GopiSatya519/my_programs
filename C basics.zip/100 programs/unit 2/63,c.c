#include<stdio.h>
#include<conio.h>

void main(){
   int num1, num2, result ;
   int addition(int, int);
   printf("Enter any two integer numbers : ") ;
   scanf("%d%d", &num1, &num2);
   result = addition(num1, num2) ;
   printf("Sum = %d", result) ;
}
int addition(int a, int b)
{
   return (a+b) ;
}
