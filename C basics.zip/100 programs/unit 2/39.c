#include<stdio.h>
main()
{
     int i,count=0,j,n,k;
     printf("enter a number n to get prime number upto n:");
     scanf("%d",&k);
    for(i=1;i<=k;i++)
    {
       for(j=1;j<=i;j++)
     {
        if(i%j==0)
            {
            count++;
            }
    }

     if(count==2)
     {
     printf("%d ",i);
     }
     }
}





