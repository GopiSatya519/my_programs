#include<stdio.h>
main()
{
    int a,b,c,ch;
    printf("0 for add,1 for sub,2 for mul,3 for divi,4 for remainder\n");
    printf("enter number a:");
    scanf("%d",&a);
    printf("enter number b:");
    scanf("%d",&b);
    printf("enter u r choice;\n");
    scanf("%d",&ch);
    switch (ch)
    {
    case 0 :c=a+b;
             printf("addition %d",c);
             break;
    case 1 :c=a-b;
             printf("subtraction %d",c);
             break;
    case 2 :c=a*b;
             printf("multiplication %d",c);
             break;
    case 3 :c=a/b;
             printf("division %d",c);
             break;
    case 4 :c=a%b;
             printf("remainder %d",c);
             break;
    default:printf("this is invalid character");
    }

}
