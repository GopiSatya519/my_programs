#include<stdio.h>
main(){
   int num1, num2 ;
   void addition(int, int) ;
   printf("Enter any two integer numbers : ") ;
   scanf("%d%d", &num1, &num2);

   addition(num1, num2) ;
}
void addition(int a, int b)
{
   printf("Sum = %d", a+b ) ;
}
