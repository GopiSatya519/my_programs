#include<stdio.h>
main()
{
    int n,sum=0,temp,digit;
    printf("enter a number:");
    scanf("%d",&n);
    temp=n;
    while(n>0)
    {
    digit=n%10;
    sum+=digit*digit*digit;
    n/=10;
    }
    if(sum==temp)
    {


      printf("the num %d is armstrong number",temp);
    }
    else
    {
        printf("the num %d is not armstrong number",temp);
    }
}
