#include<stdio.h>
main()
{
     int n,i,j,sum;
     printf("enter a value to get range of perfect numbers:");
     scanf("%d",&n);
     for(i=1;i<=n;i++)
     {
         sum=0;
         for(j=1;j<i;j++)
         {
            if(i%j==0)
            {
             sum+=j;
            }

         }
          if(sum==i)
          printf("\n %d",i);
     }

}
n#include<stdio.h>
#include<stdio.h>
main()
{
     int i,count,j,n,k;
     printf("enter a number n to get prime number upto n:");
     scanf("%d",&k);
    for(i=1;i<=k;i++)
    {
       for(j=1;j<=i;j++)
     {
        if(i%j==0)
            {
            count++;
            }
            }

     if(count==2)
     {
     printf("%d ",i);
     }
     }
}





