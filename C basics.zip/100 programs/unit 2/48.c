#include<stdio.h>
main()
{
     int a;
     printf("enter a number:");
     scanf("%d",&a);
     if (a>0)
        printf("the given number is positive");
      else
        printf("the given number is negative");
}
