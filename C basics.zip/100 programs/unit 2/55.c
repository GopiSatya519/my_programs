#include<stdio.h>
main()
{
     int a[10][10],b[10][10],rows,col,i,j,c[10][10];
     printf("enter no. of rows:");
     scanf("%d",&rows);
     printf("enter no of colons:");
     scanf("%d",&col);
     printf("enter a array elements:\n");
     for(i=0;i<rows;i++)
     {
          for(j=0;j<col;j++)
          {

             scanf("%d",&a[i][j]);

          }
          }
     printf("enter b array elements\n");
     for(i=0;i<rows;i++)
     {
         for(j=0;j<col;j++)
         {
         scanf("%d",&b[i][j]);
         }
         }
    for(i=0;i<rows;i++)
    {
        for(j=0;j<col;j++)
        {
          c[i][j]=a[i][j]-b[i][j];

        }
        }
    printf("subtraction  of a and b matrix\n");
    {
        for(i=0;i<rows;i++)
        {
           for(j=0;j<col;j++)
           {
           printf("%d\t ",c[i][j]);

           }
           printf("\n");
        }
        }
}




