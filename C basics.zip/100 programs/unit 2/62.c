#include<stdio.h>
main(){
   int result ;
   int addition() ;


   result = addition() ;
   printf("Sum = %d", result);
}
int addition()
{
   int num1, num2 ;
   printf("Enter any two integer numbers : ") ;
   scanf("%d%d", &num1, &num2);
   return (num1+num2) ;
}
