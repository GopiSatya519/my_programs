#include<stdio.h>
main()
{
    float area;
    int radius=4;
    area=3.14*pow(radius,2);
    printf("%f",area);
}
