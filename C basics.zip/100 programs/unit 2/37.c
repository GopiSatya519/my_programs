#include<stdio.h>
main()
{
  int a=10,i;
  for(i=1;i<=10;i++)
  {
      printf("%d\t",i);
      if(i==6)
      break;
  }

}
