#include<stdio.h>
main()
{
     int a[100],n,i,pos,ele;
     printf("enter no. of elements:");
     scanf("%d",&n);

     for(i=0;i<n;i++)
     {
        printf(" a[%d]=",i);
        scanf("%d",&a[i]);

     }
     printf(" enter position:");
     scanf("%d",&pos);
     printf("enter element:");
     scanf("%d",&ele);
     if(pos<=n)
     {
        for(i=n;i>=pos;i--)
       {
           a[i]=a[i-1];

       }
         a[pos-1]=ele;
         printf("the array is:");
         for(i=0;i<=n;i++)
         {

             printf("%d\t",a[i]);
         }


     }
     else
        printf("insertion is not possible");



}
