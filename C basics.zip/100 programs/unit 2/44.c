#include<stdio.h>
main()
{
    int i,result=0;
    for(i=0;i<10;i++)
    result+=i;
    printf("sum of numbers upto 10 is %d",result);
}
