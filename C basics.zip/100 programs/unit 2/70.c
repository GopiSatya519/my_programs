#include<stdio.h>
#define PI 3.14

#define SQR(x) x*x

 main(){

   int radius, area ;
   printf("Enter the radius: ");
   scanf("%d",&radius);
   area = PI * SQR(radius) ;
   printf("area = %d",area);
   }
