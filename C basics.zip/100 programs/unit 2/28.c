#include<stdio.h>

main(){
   int n ;
   printf("Enter any integer number: ") ;
   scanf("%d", &n) ;
   if ( n%5 == 0 )
      printf("Given number is divisible by 5\n") ;
}
