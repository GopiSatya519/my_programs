#include<stdio.h>
 main()
{
     char a[10];
     int b;
     char class[10];
     printf("\nenter u r name:");
     scanf("%s",a);
     printf("\nenter u r roll number:");
     scanf("%d",&b);
     printf("\nenter u r class");
     scanf("%s",class);
     printf("name:%s",a);
     printf("\nrool number %d",b);
     printf("\n class=%s",class);



}
