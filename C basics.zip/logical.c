#include<stdio.h>
main()
{
     int a=29,c;
     c=a>>3;
     printf("%d",c);
}
