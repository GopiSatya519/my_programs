#include<stdio.h>
main()
{
    int i;
    for(i=1;i<=10;i++)
    {
        printf("i=%d/n",i);
    }
}
