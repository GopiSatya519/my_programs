#include<stdio.h>
main()
{
     int a[20];
     int j,k,m,n;
     printf("enter a  numbers into array:\n");
     scanf("%d",&n);
     for(m=0;m<n;m++)
     {
         scanf("%d\n",&a[m]);
     }
     for(m=0;m<n;m++)
     {
     for(j=m+1;j<n;j++)
     {
         if(a[m]==a[j])
         {
             for(k=j;k<n;k++)
             {
                 a[k]=a[k+1];

             }
             n--;
         }


     }
     }



     printf("the elements are:");
     for(m=0;m<n;m++)
     {

         printf("%d\n",a[m]);
     }

}
