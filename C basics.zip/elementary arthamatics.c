#include<stdio.h>
#include<stdlib.h>
main()
{
     int i,j,n=1,d,e,a,count=0,count1=0;
     while(n<=11)
     {
     i=rand()%10;
     j=rand()%10;
     d=rand()%4;
     if(d==1)
    {

     printf("%d+%d=",i,j);

                a=i+j;
                scanf("%d",&e);
                if(a==e)
                {
                    printf("good\n");
                    count++;


                }
                else
                   {
                    printf("wrong\n");
                    count1++;
                    continue;
                   }

     }
     else if(d==2)
     {

         printf("%d-%d=",i,j);
         a=i-j;
         scanf("%d",&e);
         if(a==e)
         {
             printf("excellent\n");
             count++;


         }
         else
         {
             printf("try again:\n");
             count1++;
             continue;

         }

     }

     else if(d==3)

     {


         printf("%d*%d=",i,j);
         a=i*j;
         scanf("%d",&e);
         if(a==e)
         {
             printf("excellent...superr\n");
             count++;
             break;

         }
         else
         {
             printf("oohh.....let's try another\n");
             continue;
     }
}
n++;
}
printf("correct answers %d\n",count);
printf("wrong answers %d\n",count1);
}
