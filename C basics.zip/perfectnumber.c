#include<stdio.h>
main()
{
    int n,i,sum=0;
    printf("enter the value n:");
    scanf("%d",&n);
    for(i=1;i<n;i++)
    {
         if(n%i==0)
        sum=sum+i;
    }
         if(sum==n)
         printf("the given %d is perfect number",n);

         else
         printf("the given %d  is not a perfect number",n);



}
