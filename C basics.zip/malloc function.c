#include<stdio.h>
#include<stdlib.h>
main()
{
    int *a;
    a=(int*)malloc(sizeof(int));
    printf("\n Enter the value:");
    scanf("%d",a);
    printf("%d\t",*a);
    }

