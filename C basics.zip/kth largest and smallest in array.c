#include<stdio.h>
main()
{
   int a[]={40,43,54,12,9,1};
   int i,j,t,k;
   for(i=0;i<5;i++)
   {
      for(j=i+1;j<6;j++)
      {
         if(a[i]>a[j])
         {
            t=a[i];
            a[i]=a[j];
            a[j]=t;

         }

      }

   }
   printf("sorted elements are:\n");
   for(i=0;i>6;i++)
   {
       printf("%d\t",a[i]);
   }
   printf("\nselect a number which u want:\n");
   sacnf("%d",&k);
   printf("%d largest number is %d",k,a[k-1]);


}
