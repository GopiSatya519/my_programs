#include<stdio.h>
main()
{
    int i,j,k,n,c=80;
    printf("enter n no. of rows and colons value:");
    scanf("%d",&n);
    for(i=1;i<=5;i++)
    {
       for(j=i;j<=c/2-i;j++)
       {
       printf("  ");
       }

       for(k=1;k<=2*i-1;k++)
       {
       printf("*");
       }
       printf("\n");
    }

}
