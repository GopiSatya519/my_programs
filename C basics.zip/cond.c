#include<stdio.h>
main()
{
    int a;
    printf("enter the value a:");
    scanf("%d",&a);
    a%2==0?printf("the num is even"):printf("the num is odd");


}
