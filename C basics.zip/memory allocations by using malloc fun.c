#include<stdio.h>
#include<stdlib.h>
main()
{
     int *ptr,n,i,sum=0;
     printf("\nenter n value:");
     scanf("%d",&n);
     ptr=(int *)malloc(n*sizeof(int));
     if(ptr==NULL)
     {
       printf("\nmemory is not allocate");
       exit(0);
     }
     printf("\nenter elements:");
     for(i=0;i<n;i++)
     {
         scanf("%d",ptr+i);
         sum+=*(ptr+i);

     }
     printf("\nsum =%d",sum);
     free(ptr);



}
