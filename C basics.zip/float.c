#include<stdio.h>
main()
{
    float a[10];
    int i;
    printf("enter the elements:");
    for(i=0;i<5;i++)
    {

        scanf("%f",&a[i]);
    }
    for(i=0;i<5;i++)
    {

        printf("%f",a[i]);
    }

}
