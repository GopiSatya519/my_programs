#include"myfile.h"
main()
{
    int c;
     c=add(10,20);
     printf("%d\n",c);
     printf("%d\n",sub(20,2));
     printf("%d\n",mul(20,100));
     printf("%d\n",fact(5));


}
