#include<stdio.h>
int add(int a,int b)
{ 
return a+b;
}
int sub(int a, int b)
{
return a-b;
}
int mul(int a, int b)
{
return a*b;
}
int fact(int n)
{ 
return n*fact(n-1);
}
int max(int a,int b)
{
if(a>b)
return a;
else
return b;
}
int min(int a,int b)
{
if(a<b)
return a;
else
return b;
}
int read(int a[],int n)
{
int i;
for(i=0;i<n;i++)
{
scanf("%d ",&a[i]);
}
}
int display(int a[i],n)
{ 
for(i=0;i<n;i++)
{ 
printf("%d ",a[i]);
}}
int sorting(a[],n)
{
int i;
for(i=0;i<n;i++)
{for(j=i+1;j<n;j++)
{ if(a[i]>a[j])
{
a[i]=a[j];
}
printf("%d\t",a[i]);

