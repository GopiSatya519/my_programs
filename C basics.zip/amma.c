#include<stdio.h>
main()
{
    int a,b,c;
    printf("enter a,b values:");
    scanf("%d%d",&a,&b);
    c=a/b;
    printf("result:%d",c);

}
