#include<stdio.h>
#include<string.h>
main()
{
    char a[20];
    int vowels=0,consonants=0,digits=0,i,space=0;
    printf("enter a string:");
    gets(a);
    //scanf("%s",a);
    for(i=0;a[i]!='\0';i++)
    {

     if(a[i]=='a'||a[i]=='e'||a[i]=='i'||a[i]=='o'||a[i]=='u')
      {
       vowels++;
      }
      else if(a[i]>='a'&&a[i]<='z')
       {
          consonants++;
       }
       else if(a[i]>='0'&&a[i]<='9')
       {
           digits++;
       }
     }
     printf("number of vowels:%d\n",vowels);
     printf("number of consonants:%d\n",consonants);
     printf("number of digits:%d\n",digits);
}
