#include<stdio.h>
int main()
{
   FILE * fp1;
   int ch;
   fp1=fopen("satya.txt","r");
   while((ch=fgetc(fp1))!=EOF)
   {
        printf("%c",ch);
   }

}
