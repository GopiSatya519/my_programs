#include<stdio.h>
main()
{
     int a[100],n,i,pos;
     printf("enter no. of elements:");
     scanf("%d",&n);

     for(i=0;i<n;i++)
     {
        printf(" a[%d]=",i);
        scanf("%d",&a[i]);

     }
     printf(" enter position:");
     scanf("%d",&pos);
     if(pos<=n)
     {
          for(i=pos-1;i<n-1;i++)
           {
               a[i]=a[i+1];

           }
           printf("array is:");
          for(i=0;i<=n;i++)
          {
             printf("%d\t",a[i]);

          }
          }
      else
       {
           printf("deletion not possible");
       }
     }
