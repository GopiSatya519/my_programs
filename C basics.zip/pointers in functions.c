#include<stdio.h>

void add(int *studentmarks)
{
int i;
for(i=0;i<4;i++)
*studentmarks+=10;
}
int main( )
{
int j;
int marks[4]={25,56,78,98,90};
add(marks);
for(j=0;j<4;j++)
printf("marks[%d]=%d\n",j,marks[j]);
}
