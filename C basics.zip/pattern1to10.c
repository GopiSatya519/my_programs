#include<stdio.h>
main()
{
  int i,j,k,n,l=1;
  printf("enter n value:");
  scanf("%d",&n);
  for(i=1;i<=n;i++)
  {
      for(j=i;j<=n;j++)
      {
      printf(" ");
      }
      for(k=1;k<=2*i-1;k++)
      {
         if(k%2==0)
         printf(" ");
         else
         printf("%d",l++);
      }
      printf("\n");
      }
}
