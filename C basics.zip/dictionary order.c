#include<stdio.h>
main()
{
      char str[25][25],temp[25];
      int i,j,n;
      printf("enter number of strings u want to enter:");
      scanf("%d",&n);
      for(i=0;i<=n;i++)
      {
         gets(str[i]);
      }
      for(i=0;i<=n;i++)
     {
       for(j=i+1;j<=n;j++)
          {
               if(strcmp(str[i],str[j])>0)
               {
                    strcpy(temp,str[i]);
                    strcpy(str[i],str[j]);
                    strcpy(str[j],temp);
                    }

          }
     }
      printf("\n the order of string:");
      for(i=0;i<=n;i++)
      {
          puts(str[i]);

      }
}
