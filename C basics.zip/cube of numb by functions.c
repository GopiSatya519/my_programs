#include<stdio.h>
#include<math.h>
main()
{
    int cube(int);
    int b,a;
    printf("enter a number:");
    scanf("%d",&a);
    b=cube(a);
    printf("cube of the number %d is %d",a,b);


}
int cube(c)
{
    int d;
    d=pow(c,3);
    return d;


}

