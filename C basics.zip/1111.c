#include<stdio.h>
 main()
{
      float a,b,c,d;
      printf("enter a value:");
      scanf("%f",&a);
      printf("enter b value:");
      scanf("%f",&b);
      printf("enter c value:");
      scanf("%f",&c);
      d=(a*b)/c;
      printf("the result is:%f",d);

}
