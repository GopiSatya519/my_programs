#include<stdio.h>
main()
{
    int i,num,fac=1;
    printf("enter a number to get factorial value:");
    scanf("%d",&num);
    if(num<0)
    {
        printf("sorry..we don't have factorials for negative values");
        }
    else if(num==0)
    {
        printf("0! value is 1");
    }
    else if(num>0)
      {
        for(i=1;i<=num;i++)
       {
       fac=fac*i;
       }
       printf("the factorial value is:%d",fac);
      }
}
