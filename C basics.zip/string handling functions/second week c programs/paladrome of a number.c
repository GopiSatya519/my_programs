#include<stdio.h>
main()
{
    int n,result=0,temp,remainder;
    printf("enter the number to check whether it is palindrome or not :");
    scanf("%d",&n);
    temp=n;
    while(n>0)
    {
         remainder=n%10;
         result=result*10+remainder;
         n=n/10;
    }
    if(temp==result)
    printf("%d is palindrome number",temp);
    else
    printf("%d is not palindrome number",temp);
}
