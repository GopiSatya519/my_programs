#include<stdio.h>
main()
{
     int n,i,count=0;
     printf("enter number to check it is prime or not:");
     scanf("%d",&n);
     for(i=1;i<=n;i++)
     {
         if(n%i==0)
         count++;
    }
     if(count==2)
     printf("the given %d is prime number",n);
     else
     printf("the given %d is not prime number",n);

}
