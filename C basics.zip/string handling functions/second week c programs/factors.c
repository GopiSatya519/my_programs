#include<stdio.h>
main()
{
    int a,i;
    printf("enter a number to get factors:");
    scanf("%d",&a);
    for(i=1;i<=a;i++)
    {
       if(a%i==0)
       printf("\n%d",i);
    }



}
