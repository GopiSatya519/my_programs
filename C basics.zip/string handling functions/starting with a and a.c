#include<stdio.h>
main()
{
    char a[50][50];
    int n,i;
    printf("enter number of strings:");
    scanf("%d",&n);
    printf("enter the strings:\n");
    for(i=0;i<=n;i++)
    {
    gets(a[i]);
    }
    for(i=0;i<=n;i++)
    {
        if(a[i][0]=='A'||a[i][0]=='C'||a[i][0]=='a'||a[i][0]=='c')
        printf("result=%s\n",a[i]);
    }




}
