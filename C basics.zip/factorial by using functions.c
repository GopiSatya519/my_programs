#include<stdio.h>
int fact(int);
main()
{
    int n,s;
    printf("enter a num:");
    scanf("%d",&n);
    s=fact(n);
    printf("factorial=%d",s);


}
int fact(int n)
{
    if(n==0)
    return 1;
    else
    return n*fact(n-1);


}
