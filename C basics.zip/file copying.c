#include<stdio.h>
int main()
{
     FILE *fp1,*fp2;
     int ch;
     fp1=fopen("satya.txt","r");
     fp2=fopen("satya1.txt","w");
     while((ch=fgetc(fp1))!=EOF);
     {
        fputc("fp2","ch");

     }
}
