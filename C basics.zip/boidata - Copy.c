#include<stdio.h>
main()
{
    printf("name:G.satya\n");
    printf("d.o.d:19-01-2002\n");
    printf("village:pydikonda\n");
    printf("district:eastgodavari\n");


}
