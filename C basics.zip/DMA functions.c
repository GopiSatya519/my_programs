#include<stdio.h>
#include<stdlib.h>
main()
{
   int *ptr1;
   int *ptr2;
   int i,n;
   printf("\nenter n value:");
   scanf("%d",&n);
   ptr1=(int*)malloc(n*sizeof(ptr1));
   ptr2=(int*)calloc(n,sizeof(ptr2));
   if(ptr1==NULL||ptr2==NULL)
   {
   printf("\n memory does not allocate");
   }
   else
   {
       printf("\n memory successfully allocated");

       printf("\nenter elements");
       for(i=0;i<n;i++)
       {
           ptr2[i]=i+1;
       }
       printf("\nelements");
       for(i=0;i<n;i++)
       {
          printf("%d\t",ptr2[i]);
       }
        free(ptr2);

}
printf("\n ptr2 memory is free");
ptr1=realloc(ptr1,n*sizeof(int));
     for(i=5;i<n;i++)
       {
           ptr1[i]=i+1;
       }
       for(i=5;i<n;i++)
       {
          printf("%d\t",ptr1[i]);
       }
       free(ptr1);


}
