#include<stdio.h>
main()
{
     int a[20];
     int i,j,k,m,n,s;
     printf("enter a  numbers into array:\n");
     scanf("%d",&n);
     for(m=0;m<n;m++)
     {
         scanf("%d\n",&a[i]);
     }
     for(i=0;a[i]<n;i++)
     {
     for(j=i+1;a[j]<n;j++)
     {
         if(a[i]==a[j])
         {
             for(k=j;a[k]<n;k++)
             {
                 a[k]=a[k+1];

             }
             n--;
         }


     }
     }



     printf("the elements are:");
     for(i=0;i<n;i++)
     {

         printf("%d\n",a[i]);
     }






}
