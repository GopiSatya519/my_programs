#include<stdio.h>
main()
{
     int a[5],i,sum=0,n,product=1;
     float avg;
     printf("enter a no. of elements:");
     scanf("%d",&n);
     for(i=0;i<n;i++)
     {
        printf("enter a[%d]=",i);
        scanf("%d",&a[i]);
        sum=sum+a[i];
        product=product*a[i];


     }
     printf("sum of the numbers:%d\n",sum);
     printf("product of the numbers:%d\n",product);
     avg=(float)sum/n;
     printf("average values of array elements %f",avg);



}
