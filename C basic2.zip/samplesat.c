#include<stdio.h>
main()
{
    int a=5,c=2,d=a,n=6;
    float ans;
    ans=(10.2/a)+(2*a+(3c+4))/((a*d)/(12/n));
    printf("%f",ans);

}
