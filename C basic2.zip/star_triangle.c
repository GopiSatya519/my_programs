#include<stdio.h>
main()
{
   int i,j,n,l=1;
   printf("enter the n value:");
   scanf("%d",&n);
   for(i=1;i<=n;i++)
   {
       for(j=1;j<=i;j++)
       {
           printf("%d ",l++);
       }
      printf("\n");
    }

}
