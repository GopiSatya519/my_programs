#include<stdio.h>
#include<string.h>
main()
{
    char a[50];
    int i;
    printf("enter any string:");
    scanf("%s",a);
    for(i=0;i!='\0';i++)
    {
        if(a[i]>='a'&&a[i]<='z')
        {
            a[i]=a[i]-32;
            printf("%c",a[i]);
        }
        else if(a[i]>='A'&&a[i]<='Z')
        {
            a[i]=a[i]-32;
             printf("%c",a[i]);
        }


    }



}
