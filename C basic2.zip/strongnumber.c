#include<stdio.h>
main()
{
    int a1,a2,rem,i,j,sum=0,fact,temp;
    printf("enter a two numbers:\n");
    scanf("%d %d",&a1,&a2);
    for(i=a1;i<=a2;i++)
    {
     temp=i;
     sum=0;
     while(temp>0)
     {

         j=1;
         fact=1;
         rem=temp%10;
         while(j<=rem)
         {
             fact=fact*j;
             j++;
         }
         sum=sum+fact;
         temp=temp/10;
     }
     if(sum==temp)
       printf("%d\n",temp);

    }
}
