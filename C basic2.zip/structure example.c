#include<stdio.h>
struct student
{
     char name[20];
     int id;
     int age;
     }s;
main()
{
    struct student s;
    strcpy(s.name,"satya");
    s.id=170487;
    s.age=17;
    printf("\n student name:%s",s.name);
    printf("\n student id num:%d",s.id);
    printf("\n stident age:%d",s.age);

}
