#include<stdio.h>
main()
{
   int a=56;
   printf("%d",a<<11);

}
