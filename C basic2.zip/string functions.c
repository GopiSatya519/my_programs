#include<stdio.h>
#include<stdlib.h>

 void length(char str1[])
 {
 int len,i;
     for(i=0;str1[i]!='\0';i++)
     {
         len++;
     }

 }
 void append(char str1[],char str2[])
 {
    int len1,len2,i;
    len1=length(str1);
    len2=length(str2);
    for(i=len1;i<len1+len2;i++)
    {
        str1[i]=str2[i-len1];
    }
    str1='\0';
 }
 void compare(char str1[],char str2[])
 {
    int len1,len2,i,count=0;
    len1=length(str1);
    len2=length(str2);
    if(len1!=len2)
    return 1;
    for(i=0;i<len1;i++)
    {
       if(str2[i]==str2[i])
       {
           count++;
       }
    }
    if(count==len1)
    return 0;
 }
void copy(char str1[],char str2[]])
{
     len1=length(str2);
     for(i=0;i<len1;i++)
     {
         str1[i]=str2[i]
     }
     str1[i]='\0';

}
main()
{
    char str1[20],str[2];
f      int choice;
      while(i)
      {
      printf("\n 1.length\n2.append\n3.compare\n4.copy\n5.exit\n")
      printf("\nenter u r choice");
      scanf("%d",&choice);
      switch(choice)
      {
         case 1:
         printf("enter a string:");
         scanf("%s",str1);
         printf("\n length=%d",length(str1));
          break;
          case 2:
          printf("enter two strings:");
          scanf("%s%s",str1,str2);
          append(str1[],str2);
          printf("\nappending string=%s",str1);
          break;
          case 3;
          printf("enter two stringS:");
          scanf("%s%s",&str1,&str2);
          if(compare(str1,str2)>0)
          {
             printf("\nthey are not equal:");
          }
          else
          printf("\n they are not equal");
          break;
          case 4:
          printf("enter two strings:");
          scanf("%s%s",str1,str2);
          copy(str2,str1);
          printf("\nafter copy:")
          printf("%s",str2);
          break;
          case 5:
          exit(0);

      }

}}
