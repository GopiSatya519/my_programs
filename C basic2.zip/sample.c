#include<stdio.h>
main()
{
  char arr[] ={10,20,30};
  char *p = arr;
  *(++p);
  printf(" %d", *p);
}
