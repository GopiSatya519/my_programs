#include<stdio.h>
#include<string.h>
main()
{
     char a[]="SATYA";
     char b[]="gopi";
     int i,j,k;
     i=strcmp(b,a);
     printf(" 1.%d",i);
     j=strchr(a,'a');
     printf("\n2.%d",j);
     strlwr(a);
     printf("\n3.%s",a);
     strupr(b);
     printf("\n4.%d",b);
     strrev(a);
     printf("\n5.%s",a);
     strcat(a,b);
     printf("\n6.%s",a);
     k=strlen(a);
     printf("\n%d",k);
     strcpy(a,b);
     printf("\n%s %s",a,b);



}
