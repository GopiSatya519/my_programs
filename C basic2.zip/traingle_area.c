#include<stdio.h>
main()
{
     float a,b,c,s,area;
     printf("enter the given three sides of a traingle:");
     scanf("%f%f%f",&a,&b,&c);
     s=a+b+c/2;
     area=sqrt(s*(s-a)*(s-b)*(s-c));
     printf("the area of traingle %f",area);

}
