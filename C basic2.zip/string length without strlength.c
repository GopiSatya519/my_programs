#include<stdio.h>
//#include<string.h>
main()
{
   char a[]="satya is good girl";
   int i;
   for(i=0;a[i]!='\0';i++);
   printf("%d",i);



}
