#include<stdio.h>
main()
{
    int i,k,n;
    printf("how many rows and column for square:");
    scanf("%d",&n);
    for(i=1;i<=n-2;i++)
    {
        for(k=1;k<=n;k++)
        {
        printf("*");
        }
    printf("\n");
    }
}
