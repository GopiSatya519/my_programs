#include<stdio.h>
main()
{
    int var1=100;
    float var2=20.34;
    void *vptr;
    vptr=&var1;
    printf("var1 contains %d\n",*(int*)vptr);
    vptr=&var2;
    printf("var2 contains %f\n",*(float*)vptr);




}
