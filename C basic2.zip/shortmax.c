#include<stdio.h>
#include<limits.h>
main()
{
    printf("the min value of short:%d\n",SHRT_MAX);
}
