#include<stdio.h>
main()
{
     int n,i,sum=0;
     printf("enter an value:");
     scanf("%d",&n);
     for(i=1;i<=n;i++)
     {
         sum=sum+i;
     }

      printf("the sum of first %d num is=%d",n,sum);

}
