#include<stdio.h>
main( )
{
printf ( "\nI am in main" ) ;
argentina( );
}
argentina( )
{
printf ( "\nI am in argentina" ) ;
}

