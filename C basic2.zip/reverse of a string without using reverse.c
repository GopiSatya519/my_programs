#include<stdio.h>
#include<string.h>
main()
{


        char a[]={"satya"};
        int i,j,temp,l;
        l=5;
        for(i=0;i<l;i++)
        {
            temp=a[i];
            for(j=l-1;j>i;j--)
            {
                a[i]=a[j];
                a[j]=temp;
                break;


            }
        }


        printf("%s",a);





}
