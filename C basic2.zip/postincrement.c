#include<stdio.h>
main()
{
     int a=10,b;
     b=++a;
     printf("the values of a and b:%d,%d",a,b);
 }
