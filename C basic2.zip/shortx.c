#include<stdio.h>
main()
{
    unsigned short x=33;
    printf("%u",x);
    printf("%d",x);
}
