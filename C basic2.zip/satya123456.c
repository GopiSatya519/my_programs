#include<stdio.h>
const int max=5;
void add(int *studentmarks)
{
int i;
for(i=0;i<max;i++)
*studentmarks+=1;
}
int main( )
{
int j;
int marks[5]={25,56,78,98,90};
add(marks);
for(j=0;j<max;j++)
printf("marks[%d]=%d\n",j,marks[j]);
}
