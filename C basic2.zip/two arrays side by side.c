#include<stdio.h>
main()
{
    int a[10][10],b[10][10],rows,col,i,j;
    printf("enter number of rows:\n");
    scanf("%d",&rows);
    printf("enter number of cols:\n");
    scanf("%d",&col);
    printf("enter umber elements in 1st array:\n");
    for(i=0;i<rows;i++)
    {
       for(j=0;j<col;j++)
       {
       scanf("%d",&a[i][j]);
       }


    }
    printf("the array elements are:\n");
     for(i=0;i<rows;i++)
    {
       for(j=0;j<col;j++)
       {
       printf("%d\t",a[i][j]);

       }
       printf("\n");
       }



    printf("enter umber elements in 2nd array:\n");
    for(i=0;i<rows;i++)
    {
       for(j=0;j<col;j++)
       {
       scanf("%d",&b[i][j]);
       }


    }
    printf("the array elements are:\n");
     for(i=0;i<rows;i++)
    {
       for(j=0;j<col;j++)
       {
       printf("%d\t",b[i][j]);

       }
       printf("\n");
       }
    printf("side by side of above two arrays:\n");
    for(i=0;i<rows;i++)
    {
        for(j=0;j<col;j++)
    {

                printf("%d\t",a[i][j]);
    }

        printf(" &  ");

      for(j=0;j<col;j++)
        {
            printf("%d\t",b[i][j]);

        }

        printf("\n");
    }

}

