#include<stdio.h>
main()
{
    int a=10,b=15;
    int *p1,*p2;
    p1=&a;
    p2=&b;
    printf("%d",(p2-p1));
}
