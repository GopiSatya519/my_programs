#include<stdio.h>
main()
{
      char s;
      printf("the value of s:%d\n",sizeof(float));
}
