#include<stdio.h>
main( )
{
    char a[]="SAtyA";
    char b[]="srinu";
    //int x;
    //strcpy(a,b);
    printf("%s",strlwr(a));
}
