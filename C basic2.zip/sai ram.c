#include<stdio.h>
main()
{
     printf("sai ram");

}
