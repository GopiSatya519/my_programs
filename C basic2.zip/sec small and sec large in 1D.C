#include<stdio.h>
main()
{
   int a[10],i,n,fsmall,temp,ssmall;
   printf("enter no. of elements:");
   scanf("%d",&n);
   for(i=0;i<n;i++)
   {
       printf("a[%d]=",i);
       scanf("%d",&a[i]);
    }
    fsmall=a[0];
    ssmall=a[1];
    if(fsmall>ssmall)
    {
      temp=a[0];
      fsmall=ssmall;
      a[0]=temp;

    }
    for(i=2;i<n;i++)
    {
        if(a[i]<fsmall)
        {
            fsmall=a[i];
            ssmall=fsmall;
        }
    }
    printf("first small=%d\n",fsmall);
    printf("second small=%d\n",ssmall);
}
