#include<stdio.h>
main()
{
    void prime();

    prime();

}
void prime()
 {
     int a,i,count=0;
    printf("enter a value:");
    scanf("%d",&a);
    for(i=1;i<a;i++)
    {
        if(a%i==0)
        {
        count++;
        }

    }
    if(count==1)
    {
     printf("the given number is prime");
    }
    else
    {
        printf("not a prime");
    }
}
