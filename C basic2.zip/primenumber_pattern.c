#include<stdio.h>
main()
{
    int i,k,n,count,j;
    printf("enter n value:");
    scanf("%d",&n);
    for(i=1;i<=n;i++)
    {

        for(k=1;k>=n;k++)
        {
            count=0;
            for(j=1;j<=k;j++)
            {

            if(k%j==0)
            {
            count++;
            }
            if(count==2)
            {
            printf("%d",k);
            }
            }
            printf("\n");

        }


    }



}
