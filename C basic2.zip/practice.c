#include<stdio.h>
main( )
{
int i = 3, *j;
j=&i;
char a='a',*b;
b=&a;
float c=43.2,*d;
d=&c;

printf("\nvalue of i=%d",i);
printf("\naddress of i=%d",&i);
printf("\naddress of i=%d",j);
printf("\nvalue of j=%d",*j);
printf("\naddress of j=%d",&j);
printf("\naddress of char a=%d",&a);
printf("\nvalue of char a=%c",*b);
printf("\nvalue of float c=%f",*d);
printf("\nvalue of float c=%f",c);
printf("\naddress of float c=%d",&c);
}
