#include<stdio.h>
#include<string.h>
main()
{
   char source[]="srinu";
   char target[20];
   strcpy(target,source);
   printf("\nname=%s",source);
   printf("\n%s is a good father",target);


}
