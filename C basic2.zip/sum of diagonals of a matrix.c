#include<stdio.h>
main()
{
 int a[10][10],i,j,row,col,sum=0;
    printf("enter no.of rows:");
    scanf("%d",&row);
    printf("enter no. of col:");
    scanf("%d",&col);
    if(row==col)
    {
    printf("enter elements:\n");
    for(i=0;i<row;i++)
    {
         for(j=0;j<col;j++)
         {

           scanf("\n%d",&a[i][j]);
         }
    }
    printf("sum of diagonals of a matrix ");
    {
       for(i=0;i<row;i++)
       {
       for(j=0;j<col;j++)
       {
           if(i==j)
           {
             sum+=a[i][j];

           }

       }
       }
       printf("diagonal sum of matrix is=%d",sum);


    }
    }
    else
    {
        printf("sorry ....number of rows and colons must be equal");
    }





}
