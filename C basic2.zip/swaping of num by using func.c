#include<stdio.h>
main()
{
    int swap(int ,int );
    int a,b;
    printf("enter two numbers to swaping:");
    scanf("%d%d",&a,&b);
    swap(a,b);

}
int swap(int x,int y)
{
    int temp=0;
    temp=y;
    y=x;
    x=temp;
    printf("a=%d",x);
    printf("\nb=%d",y);

}








