#include<stdio.h>
#include<string.h>
main()
{
    char a[]="satya is good girl";
    printf("sring length %d",strlen(a));


}
