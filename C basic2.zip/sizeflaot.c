#include<stdio.h>
main()
{
     float a;
     printf("the size of float:%d bytes",sizeof(float));

}
