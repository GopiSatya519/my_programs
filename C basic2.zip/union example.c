#include<stdio.h>
union car
{
  char name[50];
  float price;
};
int main()
{
  union car car1={"Honda",20000};
  printf("%s\n",car1.name);
  printf("%f",car1.price);
  return 0;
}
