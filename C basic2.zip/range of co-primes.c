#include<stdio.h>
int gcd(int ,int );
main()
{
     int a,b,result,i,j;
     printf("enter any two integer values to get gcd:");
     scanf("%d %d",&a,&b);
     for(i=a;i<=b;i++)
     {
         for(j=i+1;j<=b;j++)
         {
             if(gcd(i,j)==1)
             {
                 printf("(%d,%d)\n",i,j);
                 printf("(%d,%d)\n",j,i);
             }
         }
     }

     }
int gcd(int a,int b)
{
    while(a!=b)
    {
        if(a>b)
        {
           return gcd(a-b,b);
        }
        else
        {
           return gcd(a,b-a);

        }



    }
    return a;



}
