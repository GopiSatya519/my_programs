#include<stdio.h>
#include<limits.h>
main()
{
      printf("the max value of unsigned short:%d\n",USHRT_MAX);
}
