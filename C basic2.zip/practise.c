#include<stdio.h>
main()
{
    int row,i,j,k;
    printf("enter no. of rows:");
    scanf("%d",&row);
    for(i=1;i<row;i++)
    {

       for(j=i;j<=row;j++)
       {
       printf(" ");
       }
       for(k=1;k<=2*i-1;k++)
        {
       printf("*");

       }
    printf("\n");
    }
    for(i=row;i>=1;i--)
    {
        for(j=i;j<=row;j++)
        {
            printf(" ");
         }
         for(k=1;k<=2*i-1;k++)
         {
            printf("*");
         }

         printf("\n");
    }

    }






