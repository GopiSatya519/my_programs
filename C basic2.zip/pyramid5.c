#include<stdio.h>
main()
{
    int i,j,k,n;
    printf("enter no. of rows");
    scanf("%d",&n);
    for(i=1;i<=n;i++)
    {
        for(j=i;j<=n;j++)
        {
        printf(" ");
        }
        for(k=1;k<=2*i-1;k++)
        {
            if(k==3)
            {
                printf("5");

            }
            else
            printf("*");


        }

        printf("\n");

    }


}
