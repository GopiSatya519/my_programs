#include<stdio.h>
main()
{
 unsigned short x=-4;
     printf("%u",x);
}
