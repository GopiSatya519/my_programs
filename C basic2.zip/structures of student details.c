#include<stdio.h>
struct address
{
     char village[20];
     char mandal[20];
    int phoneno;
};
struct student{
  int regid;
  char name[10];
  float cgpa;
  struct address a1[10];
}s1[10];
main()
{
    int i;
    float max;
    for(i=0;i<3;i++)
    {
        printf("\nenter register id:");
        scanf("%d",&s1[i].regid);
        printf("\nenter name:");
        scanf("%s",s1[i].name);
        printf("\nenter CGPA:");
        scanf("%f",&s1[i].cgpa);
        printf("\nenter village:");
        scanf("%s",s1[i].a1[i].village);
        printf("\nenter mandal:");
        scanf("%s",s1[i].a1[i].mandal);
        //printf("\nenter phone number:");
        //scanf("%d",s1[i].a1[i].phoneno);
  }
  max=s1[0].cgpa;
  for(i=0;i<3;i++)
  {
      if(max<s1[i].cgpa)
      {
          max=s1[i].cgpa;

      }

  }
   printf("\nmax=%f",max);
}
