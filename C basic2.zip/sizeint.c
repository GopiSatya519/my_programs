#include<stdio.h>
main()
{
      int a=10;
      printf("the size of integer:%d bytes",sizeof(int));


}
