#include<stdio.h>
main()
{
    int a=10,b;
    b=++a + --a;
    printf("the values a and b:%d %d",a,b);


}
