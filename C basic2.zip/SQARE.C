#include<stdio.h>
#include<math.h>
int main()
 {
  int num;
  int ivar;
  float fvar;
  printf("enter a number:");
  scanf("%d",&num);
  fvar=sqrt(num);
  ivar=fvar;
  if(ivar==fvar)
  {
   printf("the given number is perfect sqare");
  }
 else
 {
   printf("the given number is not perfect sqare");
 }
   return 0;
   }

