#include<stdio.h>
#include<string.h>
main()
{
    char s[][]={{"satya"},{"archana"},{"chandhu"},{"anitha"}};
    int i=0;
    if(s[i][i]=='a'||'c')
    {
       printf("%s",s);
    }



}
