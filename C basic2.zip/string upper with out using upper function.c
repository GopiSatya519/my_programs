#include<stdio.h>
#include<string.h>

main()
{
    char a[]="SATYA";
    int i;
    for(i=0;a[i]!='\0';i++)
    {
        a[i]=a[i]+32;
        printf("%c",a[i]);

    }




}
