#include<stdio.h>
int main()
{
   char a[20]="FFLLLFFLFE";
   int count=0;
   int x=0;
   int y=0;
   int i=0;
   while(a[i]!='\0')
   {

       while(a[i]!='F')
       {
          count++;
          count=count%2;
          i++;
       }
       if(a[i]=='L'&&count==0)
       {
           x++;
           i++;
       }
       else if(a[i]=='F'&&count==1)
       {
          y--;
          i++;

       }
       else if(a[i]=='E')
        {
         break;
       }

   }
     printf("(%d,%d)",x,y);


}
