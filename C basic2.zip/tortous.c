#include<stdio.h>
main()
{
   char a[20]="LFFFFLE";
   int x=0,y=0,i=0,angle=0,x1=0,y1=0;
   while(a[i]!='\0')
   {
    while(a[i]=='L')
    {
        printf("%d ",angle);
        angle=angle+90;
        i++;

    }
    printf("%c ",a[i]);
    if(a[i]=='F'&&angle==0)
    {
        x++;
        i++;

    }
    else if(a[i]=='F'&&angle==180)
    {
        x1--;
        i++;
    }
    else if(a[i]=='F'&&angle==90)
    {
        y++;
        i++;

    }
    else if(a[i]=='F'&&angle==270)
    {
        y1--;
        i++;
    }
    else{

        break;
    }
    }
    //if(angle==0&&angle==)
    printf("(%d,%d)",x,y1);

}
