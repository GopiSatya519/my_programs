#include<stdio.h>
int display(int ,int);
int display2(int);
main()
{
     int i,n;;
     printf("enter a number:\n");
     scanf("%d",&n);
     printf("\nthe num from 1 t0 n is:");
     display(1,n);
     printf("\nthe num from n to 1 is:");
     display2(n);
}
int display(int i,int n)
{
    if(i==n+1)
    return;
    else
    {
       printf("%d\t",i);
       display(i+1,n);
    }


}
int display2(int n)
{
    if(n==0)
    return;
    else
    {
    printf("%d\t",n);
    display2(n-1);
    }


}
