#include<stdio.h>
main()
{
    int a[10][20],row,col,sum=0,i,j;
    printf("enter number of elements:\n");
    scanf("%d%d",&row,&col);
    printf("\n enter elements:");
    for(i=0;i<row;i++)
    {
       for(j=0;j<col;j++)
       {
           scanf("%d",&a[i][j]);
       }
    }
        for(i=0;i<row;i++)
    {
       for(j=0;j<col;j++)
       {
           printf("%d\t  ",a[i][j]);
       }
       printf("\n");
    }
    for(i=0;i<row;i++)
    {
        for(j=0;j<col;j++)
     {
       if(a[i]==a[j])
       {
        sum=sum+a[i][j];
       }
     }
    }
    printf("sum=%d",sum);

}
