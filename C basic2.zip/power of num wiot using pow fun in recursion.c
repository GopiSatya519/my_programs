#include<stdio.h>
int power(int ,int);
main()
{
    int base,expo,result;
    printf("enter a base and exponent:");
    scanf("%d %d",&base,&expo);
    result=power(base,expo);
    printf("result=%d",result);
}
int power(int a,int b)
{
     if(b==0)
     return 1;
     else
     return a*power(a,b-1);


}
