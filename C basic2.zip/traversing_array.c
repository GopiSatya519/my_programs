#include<stdio.h>
main()
{
   int a[10][10],i,j,row,col;
   printf("enter no. of rows and colons:");
   scanf("%d%d",&row,&col);
   printf("enter elements of a array:\n");
   for(i=0;i<row;i++)
   {
      for(j=0;j<col;j++)
      {
         scanf("%d",&a[i][j]);

      }

   }
   printf("given matrixs is\n");
   for(i=0;i<row;i++)
    {
      for(j=0;j<col;j++)
      {
          printf("%d\t",a[i][j]);
      }
      printf("\n");
    }
    printf("the transport matrix is\n");
    for(i=0;i<col;i++)
    {
       for(j=0;j<row;j++)
      {
        printf("%d\t",a[j][i]);
      }

      printf("\n");
    }
}
