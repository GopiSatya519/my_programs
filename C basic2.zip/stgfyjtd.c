#include<stdio.h>
main()
{
    int i;
    for(i=0;i<=100;i++)
    {
    i=+1;
    printf("result=%d",i);
    }

}
