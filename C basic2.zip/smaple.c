#include<stdio.h>
main()
{
      int i=1,n;
      printf("enter n value for square:");
      scanf("%d,&n");
      while(i>=n)
      {
          printf("*");
          i++;
      }
      printf("\n");


}
