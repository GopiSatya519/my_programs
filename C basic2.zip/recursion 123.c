#include<stdio.h>
int fun(int a)
{
   while(a>0)
   {
      a--;
      printf("\n %d",a);
      fun(a=a-1);
      printf("\n %d",a);
   }
}
int main()
{

  fun(6);}
