#include<stdio.h>
#include<string.h>
main()
{
     char a[]="satya";
     char b[]=" gopi ";
     strcat(b,a);
     printf("full name %s",b);



}
