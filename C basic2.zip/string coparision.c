#include<stdio.h>
#include<string.h>
#include<conio.h>
main()
{
    char a[]="satya";
    char b[]="gopisrinu";
    int i,j,k;
    i=strcmp(a,"satya");
    j=strcmp(a,b);
    k=strcmp(b,"gopisrinu");
    printf("%d %d %d",i,j,k);
    //printf("\n%s",strrev(b));



}
