#include<stdio.h>
#include<math.h>
main()
{
    int a,i,count,n,j;
    printf("enter a number:");
    scanf("%d",&a);
    if(a==2)
    {
    printf(" 2 is prime number");

    }
    else if(a<0)
    {
    printf("sorry  negative numbers are not a prime num");

    }
    else if(a>0)
    {

        //printf("value of n=%d",n);

        for(i=3;i<a;i++)

    {
       count=0;
         if(n%i==0)
         {
         break;
         }
         else
         {
             printf("\nprime num");
         }

    }
    }




}
